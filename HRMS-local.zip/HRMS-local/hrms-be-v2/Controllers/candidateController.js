
const Candidate = require('../Models/candidate');
const moment = require('moment');
const HR = require('../Models/hr');
const jobRoleQuestions = require('../data/jobRoleQuestions');
const JobDetails = require('../Models/JobDetails');


exports.getCandidateDetailsByHash = async (req, res) => {
  try {
    const hash = req.hash;


    const user = await Candidate.findOne({ hash });

    if (user) {

      return res.status(200).json({
        code: 200,
        name: user.name,
        role: user.role,
      });
    }


    return res.status(200).json({
      code: 404,
      message: 'Candidate user not found.',
    });

  } catch (err) {
    res.status(200).json({ code: 500, error: err.message });
  }
};
exports.getCandidate = async (req, res) => {
  try {
    const hash = req.hash;
    const user = await Candidate.findOne({ hash });

    if (user) {

      return res.status(200).json({
        code: 200,
        profile:true
      });
    }


    return res.status(200).json({
      code: 404,
      message: 'Candidate user not found.',
    });

  } catch (err) {
    res.status(200).json({ code: 500, error: err.message });
  }
};

exports.uploadResume = async (req, res) => {
  const { filename, contentType, data } = req.body;

  if (!filename || !contentType || !data) {
    return res.status(200).json({ code: 400, error: 'All fields are required' });
  }

  try {
    const hash = req.hash;
    const candidate = await Candidate.findOne({ hash });

    if (!candidate) {
      return res.status(200).json({ code: 404, error: 'Candidate not found or invalid hash' });
    }

    
    const newFile = {
      filename,
      contentType,
      data,
    };

    
    candidate.files.push(newFile);

    
    candidate.candidate_Status = 'PRESENT';

    
    await candidate.save();

    
    res.status(201).json({
      code: 201,
      message: 'File uploaded successfully and status updated to PRESENT',
      file: newFile,
    });
  } catch (error) {
    res.status(200).json({ code: 500, error:error.message });
  }
};


exports.uploadKYC = async (req, res) => {
  const { filename, contentType, data } = req.body;

  if (!filename || !contentType || !data) {
    return res.status(200).json({ code: 400, error: 'All fields are required' });
  }

  try {
    const hash = req.hash;

    const candidate = await Candidate.findOne({ hash });

    if (!candidate) {
      return res.status(200).json({ code: 404, error: 'Candidate not found or invalid hash' });
    }

    const newFile = new File({
      filename,
      contentType,
      data,
    });
    await newFile.save();
    res.status(201).json({
      code: 201,
      message: 'File uploaded successfully',
      file: newFile,
    });
  } catch (error) {
    res.status(200).json({ code: 500, error: error.message });
  }
};


function updateTimeline(candidate) {
  const currentDate = new Date();
  let candidateDate = candidate.walkin_date;

  
  if (!(candidateDate instanceof Date)) {
    candidateDate = new Date(candidateDate); 
  }

  if (candidateDate.toDateString() === currentDate.toDateString()) {
    candidate.timeline = 'TODAY';
  } else if (candidateDate > currentDate) {
    candidate.timeline = 'UPCOMING';
  } else {
    candidate.timeline = 'PREVIOUS';
  }
}


exports.getAllCandidates = async (req, res) => {
  try {
    const hr_id = req.hr_id;

    
    let candidates = await Candidate.find({ hr_id: hr_id })
      .select('-hash -_id -files._id -__v -updatedAt -createdAt');
    
    candidates = candidates.map(candidate => {
      updateTimeline(candidate);
      return candidate;
    });

    res.status(200).json({
      code: 200,
      success: true,
      data: candidates,
    });
  } catch (error) {
    res.status(500).json({
      code: 500,
      success: false,
      message: error.message,
    });
  }
};


exports.updateCandidateStatus = async (req, res) => {
  const hash = req.hash;

  if (!hash) {
    return res.status(200).json({
      code: 400,
      message: 'Hash is required.',
    });
  }

  try {
    const user = await HR.findOne({ hash });
    if (!user || user.role !== 'hr') {
      return res.status(200).json({
        code: 403,
        message: 'Only HR can update candidate status.',
      });
    }

    const { candidate_Status, job_Status, timeline, description, candidate_id, walkin_date } = req.body;

    if (!candidate_Status || !job_Status || !timeline || !candidate_id) {
      return res.status(200).json({
        code: 400,
        message: 'Please provide hash, candidate_Status, job_Status, candidate_id, and timeline.',
      });
    }

    const validStatuses = {
      TODAY: {
        candidate: ['PRESENT', 'ABSENT', 'RE-SCHEDULED', 'WAITING'],
        job: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
      },
      UPCOMING: {
        candidate: ['WAITING', 'RE-SCHEDULED'],
        job: ['IN_PROGRESS'],
      },
      PREVIOUS: {
        candidate: ['PRESENT', 'ABSENT'],
        job: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
      },
    };

    if (!validStatuses[timeline]) {
      return res.status(200).json({
        code: 400,
        message: 'Invalid timeline provided.',
      });
    }

    const { candidate: validCandidateStatuses, job: validJobStatuses } = validStatuses[timeline];

    if (!validCandidateStatuses.includes(candidate_Status)) {
      return res.status(200).json({
        code: 400,
        message: `The candidate status you provided is not valid for the ${timeline} timeline. Please check and try again.`,
      });
    }
    
    if (!validJobStatuses.includes(job_Status)) {
      return res.status(200).json({
        code: 400,
        message: `The job status you provided is not valid for the ${timeline} timeline. Please check and try again.`,
      });
    }
    

    const candidate = await Candidate.findOne({ candidate_id });

    if (!candidate) {
      return res.status(200).json({
        code: 404,
        message: 'No candidate found with the provided candidate ID.',
      });
    }

    if (candidate.candidate_Status === 'ABSENT') {
      return res.status(200).json({
        code: 400,
        message: 'Status cannot be changed when the candidate is ABSENT.',
      });
    }

    let jobStatusDescription = description || 'Status updated.';

    if (job_Status === 'REJECTED') {
      jobStatusDescription = description || 'Candidate has been rejected. No further details provided.';
    } else {
      switch (job_Status) {
        case 'SCHEDULED':
          jobStatusDescription = 'Interview is scheduled.';
          break;
        case 'RE-SCHEDULED':
          jobStatusDescription = 'Interview is re-scheduled.';
          break;
        case 'COMPLETED':
          jobStatusDescription = 'Interview completed.';
          break;
        case 'HIRED':
          jobStatusDescription = 'Candidate has been hired.';
          break;
        case 'SELECTED':
          jobStatusDescription = 'Candidate has been selected for the role.';
          break;
        case 'IN_PROGRESS':
          jobStatusDescription = 'The recruitment process is in progress.';
          break;
      }
    }

    if ((timeline === 'UPCOMING' || timeline === 'TODAY') && candidate_Status === 'RE-SCHEDULED' && job_Status === 'IN_PROGRESS') {
      candidate.invited = true;

      await candidate.save();

      if (!walkin_date) {
        return res.status(200).json({
          code: 400,
          message: 'Please provide a walkin_date when re-scheduling the interview.',
        });
      }

      const currentDate = new Date();
      const selectedDate = new Date(walkin_date);

      if (selectedDate <= currentDate) {
        return res.status(200).json({
          code: 400,
          message: 'The re-scheduled interview date must be in the future and cannot be today or in the past.',
        });
      }

      candidate.scheduled_date = selectedDate;
      candidate.walkin_date = selectedDate;
      candidate.candidate_Status = 'RE-SCHEDULED';
    }

    if (candidate.job_Status === 'REJECTED' && job_Status !== 'REJECTED') {
      return res.status(200).json({
        code: 400,
        message: 'The job status cannot be changed after the candidate is rejected.',
      });
    }

    candidate.job_Status = job_Status;
    candidate.description = jobStatusDescription;

    await candidate.save();

    return res.status(200).json({
      message: 'Candidate status updated successfully.',
    });
  } catch (error) {
    return res.status(200).json({
      code: 500,
      message: error.message,
    });
  }
};


exports.getHRDashboardOverview = async (req, res) => {
  try {
    const hash = req.hash;

    const { timeline, month } = req.body;

    const user = await HR.findOne({ hash });
    if (!user || user.role !== 'hr') {
      return res.status(200).json({
        code: 403,
        message: 'Only HR can access this data.',
      });
    }


    let candidateQuery = {};
    let totalCandidates = 0;


    if (timeline === 'UPCOMING') {
      candidateQuery = { walkin_date: { $gt: newwalkin_date() } };
    } else if (timeline === 'TODAY') {
      candidateQuery = { walkin_date: { $gte: moment().startOf('day').toDate(), $lte: moment().endOf('day').toDate() } };
    } else if (timeline === 'PREVIOUS') {
      candidateQuery = { walkin_date: { $lt: moment().startOf('month').toDate() } };
    }


    totalCandidates = await Candidate.countDocuments(candidateQuery);


    const startOfMonth = moment().startOf('month').toDate();
    const endOfMonth = moment().endOf('month').toDate();
    const hiresThisMonthQuery = {
      job_Status: 'HIRED',
      walkin_date: { $gte: startOfMonth, $lte: endOfMonth },
    };

    const hiresThisMonth = await Candidate.countDocuments(hiresThisMonthQuery);


    let hiresInSelectedMonth = 0;
    let totalCandidatesMonthWise = {};


    if (month) {
      const startOfSelectedMonth = moment(month, 'MM').startOf('month').toDate();
      const endOfSelectedMonth = moment(month, 'MM').endOf('month').toDate();
      hiresInSelectedMonth = await Candidate.countDocuments({
        job_Status: 'HIRED',
        walkin_date: { $gte: startOfSelectedMonth, $lte: endOfSelectedMonth },
      });


      totalCandidatesMonthWise = await Candidate.aggregate([
        {
          $match: {
            walkin_date: { $gte: startOfSelectedMonth, $lte: endOfSelectedMonth },
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
          },
        },
      ]);
    }


    if (!month) {
      totalCandidatesMonthWise = await Candidate.aggregate([
        {
          $match: {
            walkin_date: { $gte: startOfMonth, $lte: endOfMonth },
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
          },
        },
      ]);
    }


    res.status(200).json({
      totalCandidates,
      totalCandidatesMonthWise: totalCandidatesMonthWise.length ? totalCandidatesMonthWise[0].total : 0,
      hiresThisMonth,
      hiresInSelectedMonth,
    });

  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};
exports.updateJobRoles = async (req, res) => {
  const candidate_id = req.candidate_id; // Assuming candidate_id is already coming in the request
  const { job_id, job_title } = req.body; // Getting job_id and job_title from request body
  
  try {
    // Ensure job_id and job_title are provided
    if (!job_id || !job_title) {
      return res.status(400).json({ code: 400, message: 'job_id and job_title are required.' });
    }

    // Find candidate by candidate_id
    const candidate = await Candidate.findOne({ candidate_id });

    if (!candidate) {
      return res.status(404).json({ code: 404, message: 'Candidate not found' });
    }

    // Check if job_role with job_id already exists
    const existingJobRole = candidate.job_role.find(role => role.job_id === job_id);

    if (existingJobRole) {
      // If it exists, update the job_title
      existingJobRole.job_title = job_title;
    } else {
      // If it doesn't exist, push a new job role to the job_role array
      candidate.job_role.push({ job_id, job_title });
    }

    // Save the updated candidate to the database
    await candidate.save();

    // Return success response
    res.status(200).json({ code: 200, message: 'Job roles updated successfully', candidate });
    
  } catch (error) {
    // Return error if something goes wrong
    return res.status(500).json({ code: 500, error: error.message });
  }
};



exports.getJobRoles = async (req, res) => {
  try {

    const jobRoles = await JobDetails.find().select('job_id title');

    const jobRolesArray = jobRoles.map(job => ({
      job_id: job.job_id,
      title: job.title
    }));

    return res.status(200).json({
      available_job_roles: jobRolesArray
    });
  } catch (error) {

    return res.status(200).json({ code: 500, error:error.message });
  }
};


exports.updateCameraPermission = async (req, res) => {
  try {
    const hash = req.hash;
    const user = await Candidate.findOne({ hash });
    if (!user) {
      return res.status(200).json({ code: 404, message: 'User not found' });
    }
    const { cameraPermission } = req.body;
    if (typeof cameraPermission !== 'boolean') {
      return res.status(200).json({code:400, error: 'Camera permission must be a boolean' });
    }

    const candidate = await Candidate.findByIdAndUpdate(
      user._id,
      { cameraPermission },
      { new: true, runValidators: true }
    );


    if (!candidate) {
      return res.status(200).json({ code:404, error: 'Candidate not found' });
    }


    res.status(200).json(candidate);
  } catch (error) {
    res.status(200).json({ code:500, error: error.message });
  }
};


exports.getJobRoleQuestions = async (req, res) => {
  try {
    const hash = req.hash;
    const user = await Candidate.findOne({ hash });
    if (!user) {
      return res.status(200).json({ code: 404, message: 'User not found' });
    }
    const { job_role } = req.body;


    if (!job_role) {
      return res.status(200).send({ code:400, message: 'Job role is required' });
    }


    const questions = jobRoleQuestions[job_role];


    if (!questions) {
      return res.status(200).send({ code:400, message: 'Invalid job role' });
    }


    return res.status(200).send({ questions });

  } catch (error) {

    return res.status(200).json({ code: 500, error:error.message });
  }
};


exports.candidateDelete = async (req, res) => {
  try {
    const hash = req.hash;
    const hr = await HR.findOne({ hash });
    if (!hr) {
      return res.status(200).json({ code: 404, error: 'HR not found' });
    }
    
    const { candidateId } = req.body;

    
    const candidate = await Candidate.findOne({ candidate_id: candidateId });

    if (!candidate) {
      return res.status(200).json({ code: 404, error: 'Candidate not found' });
    }

    
    if (candidate.deleteFlag === true) {
      return res.status(200).json({ code: 400, error: 'Candidate already marked as deleted' });
    }

    
    await Candidate.findOneAndUpdate(
      { candidate_id: candidateId },
      { deleteFlag: true }
    );

    return res.status(200).json({
      code: 200,
      message: 'Candidate marked as deleted successfully.',
    });
  } catch (error) {
    return res.status(200).json({ code: 500, error: 'Internal Server Error' });
  }
};

exports.getCandidateDetails = async (req, res) => {
  try {
    const candidateId = req.candidate_id; 
    
    const candidate = await Candidate.find({candidate_id:candidateId});
    if (!candidate) {
      return res.status(200).json({ code:404, message: 'Candidate not found' });
    }
    res.status(200).json(candidate);
  } catch (error) {
    console.error(error.message);
    res.status(200).json({code:500, error:error.message});
  }
};



const formatDOB = (dob) => {
  const [day, month, year] = dob.split('/').map(val => parseInt(val, 10));
  return new Date(year, month - 1, day); 
};



exports.updateCandidate = async (req, res) => {
  try {
    const candidate_id = req.candidate_id;  
    const { email, address, dob, skills, linkedin, github, education, experiences } = req.body;

    const formattedDOB = dob ? formatDOB(dob) : null;
    
    const candidate = await Candidate.findOne({ candidate_id: candidate_id });

    if (!candidate) {
      return res.status(200).json({ code: 404, message: 'Candidate not found' });
    }

    candidate.email = email || candidate.email;
    candidate.address = address || candidate.address;
    candidate.dob = formattedDOB || candidate.dob;
    candidate.skills = skills || candidate.skills;
    candidate.linkedin = linkedin || candidate.linkedin;
    candidate.github = github || candidate.github;

    
    if (education && education.length > 0) {
      candidate.education = education.map(edu => ({
        qualification: edu.qualification || 'Not Specified',
        institution: edu.institution || 'Not Specified',
        passingYear: edu.passingYear || new Date().getFullYear(),
        marks: edu.marks || 'Not Specified',
      }));
    }

    
    if (experiences && experiences.length > 0) {
      candidate.experiences = experiences.map(exp => ({
        company: exp.company || 'Not Provided',
        role: exp.role || 'Not Provided',
        fromDate: exp.fromDate ? new Date(exp.fromDate) : null,
        toDate: exp.toDate ? new Date(exp.toDate) : null,
        skillsUsed: exp.skillsUsed || 'Not Provided',
      }));
    }

    
    candidate.profile = true;

    
    await candidate.save();

    return res.status(200).json({ message: 'Candidate updated successfully!', candidate });
  } catch (error) {
    console.error('Error updating candidate:', error.message);
    return res.status(200).json({ code: 500, message: 'Error updating candidate', error: error.message });
  }
};


exports.checkUpdateCandidate = async (req, res) => {
  try {
    const candidate_id = req.candidate_id;

    if (profile === undefined) {
      return res.status(400).json({ code: 400, message: 'Profile status is required.' });
    }

    const candidate = await Candidate.findOne({ candidate_id: candidate_id });
    if (!candidate) {
      return res.status(404).json({ code: 404, message: 'Candidate not found' });
    }

    
    candidate.profile = profile;
    
    
    await candidate.save();

    
    res.status(200).json({ profile: candidate.profile, message: 'Profile updated successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
};
