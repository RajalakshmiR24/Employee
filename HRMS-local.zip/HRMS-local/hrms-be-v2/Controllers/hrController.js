const express = require('express');
const fileUpload = require('express-fileupload');
const moment = require('moment');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

const Candidate = require('../Models/candidate');
const HR = require('../Models/hr');
const JobDetails = require('../Models/JobDetails');


const app = express();
app.use(fileUpload());


const jobStatusDescription = (jobStatus) => {
  switch (jobStatus) {
    case 'SCHEDULED':
      return 'The candidate has been scheduled for the interview.';
    case 'RE-SCHEDULED':
      return 'The interview has been re-scheduled.';
    case 'COMPLETED':
      return 'The job has been completed.';
    case 'HIRED':
      return 'The candidate has been hired.';
    case 'SELECTED':
      return 'The candidate has been selected.';
    case 'REJECTED':
      return 'The candidate has been rejected.';
    case 'IN_PROGRESS':
      return 'The candidate is in progress.';
    default:
      return 'Status updated.';
  }
};


exports.getHRDetailsByHash = async (req, res) => {
  try {

    const name = req.name;
    const role = req.role;
    const position = req.position;

    if (!name || !role || !position) {
      return res.status(400).json({
        code: 400,
        message: 'Name, role, and position are required.',
      });
    }

    return res.status(200).json({
      code: 200,
      name: name,
      role: role,
      position: position
    });

  } catch (err) {

    res.status(500).json({ code: 500, message: err.message });
  }
};

exports.handleExcelUpload = async (req, res) => {
  try {
    const hr_id = req.hr_id;
    let { excelData } = req.body;


    let results = { successCount: 0, errors: [] };
    let isExcelData = Array.isArray(excelData);

    if (isExcelData) {
      for (let record of excelData) {
        let { name, phone_number, job_role, candidate_Status, job_Status, walkin_date, files } = record;

        let parsedDate;


        if (walkin_date === 'NA' || !moment(walkin_date, 'DD-MM-YYYY', true).isValid()) {
          results.errors.push({
            record,
            error: `Invalid walkin date ${walkin_date}.`,
          });
          continue;
        } else {
          parsedDate = moment(walkin_date, 'DD-MM-YYYY').toDate();
        }

        let currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);


        let timeline;
        if (parsedDate.getTime() === currentDate.getTime()) {
          timeline = 'TODAY';
        } else if (parsedDate.getTime() > currentDate.getTime()) {
          timeline = 'UPCOMING';
        } else {
          timeline = 'PREVIOUS';
        }

        if (timeline === 'TODAY') {
          results.errors.push({
            record,
            error: 'Records with TODAY\'s date are not allowed to be saved.',
          });
          continue;
        }

        if (timeline === 'UPCOMING') {
          if (!candidate_Status) {
            candidate_Status = 'WAITING';
          }

          if (!job_Status) {
            job_Status = 'IN_PROGRESS';
          }
        }

        if (timeline === 'PREVIOUS') {
          if (!candidate_Status) {
            results.errors.push({
              record,
              error: 'Skipping record: Candidate status is required for PREVIOUS date.',
            });
            continue;
          }
          if (candidate_Status === 'PRESENT') {
            if (!job_Status) {
              results.errors.push({
                record,
                error: 'Job status is required when candidate status is PRESENT for PREVIOUS date.',
              });
              continue;
            }
          }

          if (candidate_Status === 'ABSENT') {
            job_Status = 'REJECTED';
            record.job_Status = job_Status;
            record.job_Status_Description = 'Candidate was absent; status set to REJECTED';
          }
        }

        const validStatuses = {
          TODAY: {
            candidate: ['PRESENT', 'ABSENT', 'RE-SCHEDULED', 'WAITING'],
            job: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
          },
          UPCOMING: {
            candidate: ['WAITING', 'RE-SCHEDULED'],
            job: ['IN_PROGRESS'],
          },
          PREVIOUS: {
            candidate: ['PRESENT', 'ABSENT'],
            job: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
          },
        };

        if (!validStatuses[timeline]) {
          return res.status(200).json({
            code: 400,
            message: 'Invalid timeline provided.',
          });
        }

        const { candidate: validCandidateStatuses, job: validJobStatuses } = validStatuses[timeline];

        if (!validCandidateStatuses.includes(candidate_Status)) {
          results.errors.push({
            record,
            error: `The candidate status ${candidate_Status} is not valid for the ${timeline} timeline.`,
          });
          continue;
        }

        if (job_Status && !validJobStatuses.includes(job_Status)) {
          results.errors.push({
            record,
            error: `The job status ${job_Status} is not valid for the ${timeline} timeline.`,
          });
          continue;
        }




        if (timeline === 'PREVIOUS') {
          if (!candidate_Status) {
            results.errors.push({
              record,
              error: 'Skipping record: Candidate status is required for PREVIOUS date.',
            });
            continue;
          }
          if (candidate_Status === 'PRESENT') {
            if (!job_Status) {
              results.errors.push({
                record,
                error: 'Job status is required when candidate status is PRESENT for PREVIOUS date.',
              });
              continue;
            }
          }

          if (candidate_Status === 'ABSENT') {
            job_Status = 'REJECTED';
            record.job_Status = job_Status;
            record.job_Status_Description = 'Candidate was absent; status set to REJECTED';
          }
        }

        try {
          let existingCandidate = await Candidate.findOne({ phone_number: phone_number });

          if (existingCandidate) {
            results.errors.push({
              record,
              error: `A candidate with the phone number ${phone_number} already exists.`,
            });
            continue;
          }

          let hashedPhoneNumber = crypto.createHash('sha256').update(phone_number.toString()).digest('hex');

          let newCandidate = new Candidate({
            name,
            phone_number,
            hash: hashedPhoneNumber,
            job_role,
            candidate_Status,
            job_Status,
            description: jobStatusDescription(job_Status),
            walkin_date: parsedDate,
            scheduled_date: parsedDate,
            timeline: timeline,
            invited: true,
            hr_id: hr_id
          });

          if (files && files.length > 0) {
            newCandidate.files = files.map(file => {
              file.file_id = file.file_id || uuidv4();
              return file;
            });
          }

          await newCandidate.save();
          results.successCount += 1;

        } catch (dbError) {
          results.errors.push({
            record,
            error: `Database error: ${dbError.message}`,
          });
        }
      }
    } else {
      return res.status(200).json({
        code: 400,
        message: 'Invalid data format. Please provide either form data or excel data.',
      });
    }

    res.status(201).json({
      message: "Data processing complete.",
      successCount: results.successCount,
      errors: results.errors,
    });

  } catch (error) {
    res.status(200).json({
      code: 500,
      message: error.message
    });
  }
};

exports.createHRDetails = async (req, res) => {
  try {
    const { phone_number, name, email, position, organization_name, organization_address, organization_contact, organization_website } = req.body;
    const { hash } = req;
    const existingHRWithHash = await HR.findOne({ hash });
    if (!existingHRWithHash) {
      return res.status(200).json({
        message: 'Invalid hash. No HR found.',
      });
    }

    if (existingHRWithHash.position !== "ZustPe_HR") {
      return res.status(200).json({
        message: 'Only an HR with position "ZustPe_HR" can create new HRs.',
      });
    }
    const [existingHR, existingCandidateEmail, existingHRPhone, existingCandidatePhone] = await Promise.all([
      HR.findOne({ email }),
      HR.findOne({ email }),
      Candidate.findOne({ email }),
      HR.findOne({ phone_number }),
      Candidate.findOne({ phone_number }),
    ]);

    if (existingHR) {
      return res.status(200).json({ code: 400, message: 'Email already exists in HR.' });
    }
    if (existingCandidateEmail) {
      return res.status(200).json({ code: 400, message: 'Email already exists in Candidate.' });
    }
    if (existingHRPhone) {
      return res.status(200).json({ code: 400, message: 'Phone number already exists in HR.' });
    }
    if (existingCandidatePhone) {
      return res.status(200).json({ code: 400, message: 'Phone number already exists in Candidate.' });
    }
    const hashedPhoneNumber = crypto.createHash('sha256').update(phone_number).digest('hex');
    const newHR = new HR({
      phone_number,
      hash: hashedPhoneNumber,
      name,
      email,
      position,
      organization_name,
      organization_address,
      organization_contact,
      organization_website,
      status: 'active',
    });


    await newHR.save();


    res.status(201).json({
      message: 'HR details created successfully.',
      hr: newHR,
    });
  } catch (error) {
    res.status(200).json({ code: 500, message: error.message });
  }
};



exports.uploadCandidateResume = async (req, res) => {
  const hash = req.hash;

  const { filename, contentType, data, candidate_id } = req.body;


  if (!filename || !contentType || !data || !hash || !candidate_id) {
    return res.status(200).json({ code: 400, error: 'All fields are required' });
  }

  try {

    const Hr = await HR.findOne({ hash });
    if (!Hr) {
      return res.status(200).json({ code: 404, error: 'HR not found or invalid hash' });
    }


    const candidate = await Candidate.findOne({ candidate_id });
    if (!candidate) {
      return res.status(200).json({ code: 404, error: 'Candidate not found' });
    }


    const newFile = {
      filename,
      contentType,
      data,
      file_id: uuidv4(),
    };


    candidate.files.push(newFile);


    await candidate.save();


    res.status(201).json({
      code: 201,
      message: 'File uploaded successfully',
      file: newFile,
    });
  } catch (error) {
    res.status(200).json({ code: 500, error: error.message });
  }
};

exports.getJobRolesAndStatuses = async (req, res) => {
  try {
    const hr_id = req.hr_id;

    const jobRoles = await JobDetails.find({ hr_id: hr_id }).select('job_id title');

    const jobRolesArray = jobRoles.map(job => ({
      job_id: job.job_id,
      title: job.title
    }));


    const candidateStatuses = Candidate.schema.path('candidate_Status').enumValues;
    const jobStatuses = Candidate.schema.path('job_Status').enumValues;


    const enums = {
      available_job_roles: jobRolesArray,
      available_candidate_statuses: candidateStatuses,
      available_job_statuses: jobStatuses,
    };


    return res.status(200).json({
      success: true,
      message: 'Enums and job roles fetched successfully.',
      data: enums,
    });

  } catch (error) {

    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};


exports.uploadFormResume = async (req, res) => {
  const hr_id = req.hr_id;
  const { filename, contentType, data, name, phone_number, walkin_date, job_role, candidate_Status, job_Status } = req.body;

  if (!filename || !contentType || !data || !phone_number || !name || !walkin_date || !job_role || !candidate_Status || !job_Status) {
    return res.status(200).json({ code: 400, error: 'All fields are required' });
  }

  const inputDate = new Date(walkin_date);
  const currentDate = new Date();

  if (inputDate.setHours(0, 0, 0, 0) <= currentDate.setHours(0, 0, 0, 0)) {
    return res.status(200).json({ code: 400, error: 'Date should be in the future' });
  }


  const hashedPhoneNumber = crypto.createHash('sha256').update(phone_number).digest('hex');

  try {
    const candidateExist = await Candidate.findOne({ phone_number: phone_number });
    if (candidateExist) {
      return res.status(200).json({ code: 400, error: 'Phone number already exists in Candidate data.' });
    }

    const hrExist = await HR.findOne({ phone_number: phone_number });
    if (hrExist) {
      return res.status(200).json({ code: 400, error: 'Phone number already exists in HR schema' });
    }

    let timeline = 'PREVIOUS';
    const parsedDate = new Date(walkin_date);

    let dateDifference = currentDate.getTime() - parsedDate.getTime();

    if (dateDifference === 0) {
      timeline = 'TODAY';
    } else if (dateDifference > 0) {
      timeline = 'PREVIOUS';
    } else {
      timeline = 'UPCOMING';
    }

    if (timeline === 'TODAY') {
      return res.status(200).json({ code: 400, error: 'Creating candidates for today or with "TODAY" timeline is not allowed.' });
    }

    const candidate = new Candidate({
      hash: hashedPhoneNumber,
      name,
      phone_number,
      walkin_date,
      job_role,
      candidate_Status,
      job_Status,
      timeline,
      invited: true,
      hr_id: hr_id,
      files: [{
        filename,
        contentType,
        data,
      }]
    });

    await candidate.save();

    res.status(201).json({
      code: 201,
      message: 'New candidate created and file uploaded successfully',
    });
  } catch (error) {
    console.log(error.message);

    res.status(200).json({ code: 500, error: error.message });
  }
};

exports.getJobDetailsEnums = async (req, res) => {
  const hash = req.hash
  try {

    const enums = {
      jobOpeningStatus: JobDetails.schema.path('jobOpeningStatus').enumValues,
      jobType: JobDetails.schema.path('jobType').enumValues,
      workExp: JobDetails.schema.path('workExp').enumValues,
      industry: JobDetails.schema.path('industry').enumValues,
      departmentName: JobDetails.schema.path('departmentName').enumValues,
    };


    const hrList = await HR.find({ hash }, 'name hr_id departmentName');


    const hiringManagers = hrList.map(hr => ({
      hr_id: hr.hr_id,
      name: hr.name,
      department: hr.departmentName,
    }));


    enums.hiringManagers = hiringManagers;

    return res.status(200).json({
      success: true,
      message: 'Enums fetched successfully',
      data: enums,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

exports.getAllHR = async (req, res) => {
  try {
    const hr_id = req.hr_id;
    const existingHRWithHash = await HR.findOne({ hr_id });

    if (!existingHRWithHash) {
      return res.status(200).json({
        code: 400,
        message: 'Invalid hash. No HR found.',
      });
    }


    if (existingHRWithHash.position !== "ZustPe_HR") {
      return res.status(200).json({
        code: 400,
        message: 'Only an HR with position "ZustPe_HR" can create view HRs.',
      });
    }
    const hrRecords = await HR.find({ position: { $ne: 'ZustPe_HR' } }).select('-hash -_id -files._id -__v -updatedAt -createdAt');

    if (hrRecords.length === 0) {
      return res.status(200).json({ code: 400, message: 'No HR records found' });
    }
    return res.status(200).json(hrRecords);
  } catch (error) {
    console.error(error);
    return res.status(200).json({ code: 500, message: error.message });
  }
};


exports.createJobRole = async (req, res) => {
  try {
    const hr_id = req.hr_id;
    console.log("Received HR ID:", hr_id);

    const {
      postingTitle,
      title,
      departmentName,
      hiringManager,
      numOfPositions,
      targetDate,
      dateOpened,
      jobOpeningStatus,
      jobType,
      industry,
      workExp,
      salary,
      requiredSkills,
      address,
      notes,
    } = req.body;

    console.log("Received job role data:", {
      postingTitle,
      title,
      departmentName,
      hiringManager,
      numOfPositions,
      targetDate,
      dateOpened,
      jobOpeningStatus,
      jobType,
      industry,
      workExp,
      salary,
      requiredSkills,
      address,
      notes,
    });


    console.log("Checking for existing posting title...");
    const existingPosting = await JobDetails.findOne({
      hr_id: hr_id,
      postingTitle: postingTitle,
    });

    console.log("Existing posting title check result:", existingPosting);

    if (existingPosting) {
      console.log("Posting title is already taken by this HR.");
      return res.status(400).json({
        code: 400,
        error: 'Posting Title must be unique for this HR.',
      });
    }


    const newJobDetail = new JobDetails({
      postingTitle,
      title,
      departmentName,
      hiringManager,
      numOfPositions,
      targetDate,
      dateOpened,
      jobOpeningStatus,
      jobType,
      industry,
      workExp,
      salary,
      requiredSkills,
      address,
      notes,
      hr_id: hr_id,
    });
    console.log("New job detail object created:", newJobDetail);


    console.log("Saving new job detail to the database...");
    await newJobDetail.save();
    console.log("New job detail saved successfully.");

    return res.status(201).json({
      success: true,
      message: 'Job Details created successfully.',
    });
  } catch (error) {
    console.error('Error creating job details:', error.message);
    return res.status(500).json({
      code: 500,
      error: error.message,
    });
  }
};


exports.updateStatusToSuspended = async (req, res) => {
  try {
    const { hr_id } = req.body;  // Extract hr_id from the request body
    const shr_id = req.hr_id;  // Assuming `req.hr_id` is the ID of the currently authenticated HR

    // Find the existing HR using shr_id
    const existingHRWithHash = await HR.findOne({ hr_id: shr_id });

    if (!existingHRWithHash) {
      return res.status(200).json({
        message: 'Invalid hash. No HR found.',
      });
    }

    if (existingHRWithHash.position !== "ZustPe_HR") {
      return res.status(200).json({
        message: 'Only an HR with position "ZustPe_HR" can create new HRs.',
      });
    }

    // Proceed to update the HR status using the hr_id from the request
    const updatedHR = await HR.findOneAndUpdate(
      { hr_id },  // Use the hr_id from the body to find the HR
      { status: 'suspended' },
      { new: true }  // Return the updated HR document
    );

    if (!updatedHR) {
      return res.status(200).json({ code: 404, message: 'HR not found' });
    }

    return res.status(200).json({
      code: 200,
      message: 'HR status updated to suspended',
      data: updatedHR
    });
  } catch (err) {
    console.error(err.message);
    return res.status(500).json({ code: 500, message: 'Server error', error: err.message });
  }
};
























































