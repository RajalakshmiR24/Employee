const Token = require('../Models/token');
const Candidate = require('../Models/candidate');
const HR = require('../Models/hr');
const { v4: uuidv4 } = require('uuid');


const login = (req, res, next) => {
  console.log('-----------------------------');
  console.log('/Start login handler');
  next();
};

const logout = (req, res, next) => {
  console.log('-----------------------------');
  console.log('/end logout handler');
  const issuer = process.env.OIDC_ISSUER_AUTH;
  const logoutUrl = `${issuer}/account/session/end`;
  res.redirect(logoutUrl);

  next();
};


const authenticate = (err, req, res, next) => {
  if (err) {
    console.error('Authentication error:', err.message);
    return res.status(200).send('Authentication failed. Please try again.');
  }
  console.log("Authentication")
  next();

};


const verifySession = (req, res, next) => {

  try {
    if (req.details && req.details.Auth_token && req.details.Role) {
      return res.status(200).json({
        code: 200,
        hrmstoken: req.details.Auth_token,
        role: req.details.Role

      });
    } else {
      return res.status(200).json({ code: 400, error: "Token or hash not found." });
    }
  } catch (error) {
    return res.status(200).json({ code: 500, error: error.message });
  }
};



const saveUserSession = async (req, tokenSet, userinfo, cameraPermission, invited) => {
  try {
    const { phone_number, hash, name, sub, role } = userinfo;
    const { access_token, expires_at, id_token, refresh_token, scope, token_type } = tokenSet;

    const walkin_date = new Date().toISOString().split('T')[0];

    const [existingHR, existingCandidate] = await Promise.all([
      HR.findOne({ hash }),
      Candidate.findOne({ hash })
    ]);

    
    if (existingHR) {
      await HR.updateOne({ hash }, { $set: { name } });

      const newTokenSession = new Token({
        userhash: hash,
        access_token,
        refresh_token,
        expires_at,
        id_token,
        token_type,
        scope,
        role: 'hr',
      });

      await newTokenSession.save();
      return 'hr';
    }

    
    if (existingCandidate) {
      await Candidate.updateOne({ hash }, { $set: { name } });

      const newTokenSession = new Token({
        userhash: hash,
        access_token,
        refresh_token,
        expires_at,
        id_token,
        token_type,
        scope,
        role: 'candidate',
      });

      await newTokenSession.save();
      return 'candidate';
    }

    
    const candidateStatus = invited === true ? 'PRESENT' : 'WAITING';

    if (!existingCandidate) {
      const newCandidate = new Candidate({
        phone_number,
        hash,
        name,
        role: 'candidate',
        sub,
        timeline: 'TODAY', 
        walkin_date,
        candidate_Status: candidateStatus,
        job_role: [{ job_id: uuidv4(), job_title: 'others' }], 
        job_Status: 'IN_PROGRESS', 
        cameraPermission,
        invited: true, 
      });

      await newCandidate.save();

      const newTokenSession = new Token({
        userhash: hash,
        access_token,
        refresh_token,
        expires_at,
        id_token,
        token_type,
        scope,
        role: 'candidate',
      });
      await newTokenSession.save();

      return 'candidate';
    }

    
    if (role === 'candidate') {
      const newCandidate = new Candidate({
        phone_number,
        hash,
        name,
        role: 'candidate',
        sub,
        timeline: 'TODAY', 
        walkin_date,
        candidate_Status: candidateStatus,
        job_role: [{ job_id: uuidv4(), job_title: 'others' }], 
        job_Status: 'IN_PROGRESS', 
        cameraPermission,
        invited: true, 
      });

      await newCandidate.save();

      const newTokenSession = new Token({
        userhash: hash,
        access_token,
        refresh_token,
        expires_at,
        id_token,
        token_type,
        scope,
        role: 'candidate',
      });
      await newTokenSession.save();
    }

    
    if (role === 'hr') {
      const newTokenSession = new Token({
        userhash: hash,
        access_token,
        refresh_token,
        expires_at,
        id_token,
        token_type,
        scope,
        role,
      });
      await newTokenSession.save();
    }

  } catch (err) {
    console.error('Error saving user session:', err.message);
  }
};



module.exports = {
  login,
  logout,
  authenticate,
  verifySession,
  saveUserSession,

};
