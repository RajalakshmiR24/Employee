const JobDetails = require("../../Models/JobDetails");

exports.getAllJobDetails = async (req, res) => {
    try {
        const hr_id = req.hr_id;
        const jobDetails = await JobDetails.find({ hr_id: hr_id }).select('-hash -_id -files._id -__v -updatedAt -createdAt');;
        if (!jobDetails || jobDetails.length === 0) {
            return res.status(200).json({
                code: 400,
                error: 'No job details found',
            });
        }

        return res.status(200).json({
            code: 200, data: jobDetails,
        });
    } catch (error) {
        console.error('Error fetching job details:', error);
        return res.status(200).json({
            code: 500, error: error.message,
        });
    }
};

exports.getAllJob = async (req, res) => {
    try {
        const jobDetails = await JobDetails.find().select('-hash -_id -files._id -__v -updatedAt -createdAt');;
        if (!jobDetails || jobDetails.length === 0) {
            return res.status(200).json({
                code: 400,
                message: 'No job details found',
            });
        }

        return res.status(200).json({
            code: 200, data: jobDetails,
        });
    } catch (error) {
        console.error('Error fetching job details:', error);
        return res.status(200).json({
            code: 500, error: error.message,
        });
    }
};

exports.getJobById = async (req, res) => {
    try {
        const { jobId } = req.body;  // Assume the jobId is being passed in the request body
        const jobDetails = await JobDetails.find({job_id:jobId}).select('-hash -_id -files._id -__v -updatedAt -createdAt -hr_id -hiringManager.hr_id');

        if (!jobDetails) {
            return res.status(200).json({
                code: 400,
                message: 'Job not found',
            });
        }

        return res.status(200).json({
            code: 200, 
            data: jobDetails,
        });
    } catch (error) {
        console.error('Error fetching job details by jobId:', error);
        return res.status(500).json({
            code: 500, 
            error: error.message,
        });
    }
};
