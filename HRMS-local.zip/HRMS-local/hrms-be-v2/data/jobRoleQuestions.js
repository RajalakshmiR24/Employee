

const jobRoleQuestions = {
  'Video Editor': [
    'What video editing software are you most comfortable with?',
    'Can you describe your process for editing a video?',
    'How do you handle tight deadlines in video production?'
  ],
  'AWS': [
    'What is your experience with AWS services?',
    'How would you optimize cost while using AWS for cloud computing?',
    'Describe a time when you had to troubleshoot an AWS-related issue.'
  ],
  'UI/UX': [
    'What is your approach to user-centered design?',
    'How do you conduct usability testing?',
    'Can you give an example of a project where your design improved the user experience?'
  ],
  'Software Tester': [
    'What types of testing do you have experience with?',
    'How do you prioritize bugs in your testing process?',
    'Can you describe a challenging bug you found and how you resolved it?'
  ],
  'MERN Stack Developer': [
    'How do you approach building a full-stack web application using the MERN stack?',
    'What tools do you use to manage your backend and database in a MERN application?',
    'How do you ensure the security of your MERN stack applications?'
  ],
  'Graphic Designer': [
    'What is your design process when creating graphics?',
    'Which design software are you most comfortable with?',
    'How do you ensure your designs align with the client’s branding?'
  ],
  'HR Recruiter': [
    'What strategies do you use to source candidates for difficult-to-fill roles?',
    'How do you assess a candidate’s cultural fit within a company?',
    'Can you describe your process for conducting interviews?'
  ],
  'Operations Associate': [
    'How do you manage logistics and resources in an operations role?',
    'Can you give an example of a process improvement you implemented?',
    'What tools do you use to track operational performance?'
  ],
  'Compliance Auditor': [
    'What is your approach to ensuring regulatory compliance?',
    'How do you manage risk during an audit?',
    'Describe a time when you identified a compliance issue and how you handled it.'
  ],
  'Accountant': [
    'What accounting software are you familiar with?',
    'How do you ensure financial accuracy in your reports?',
    'Can you explain your experience with tax preparation or audits?'
  ],
  'Finance Analyst': [
    'How do you analyze financial data to provide insights?',
    'What tools do you use for financial modeling?',
    'Can you explain a situation where your financial analysis directly impacted business decisions?'
  ],
  'Flutter Developer': [
    'What experience do you have with Flutter for mobile app development?',
    'How do you handle state management in Flutter?',
    'What is your process for debugging a Flutter application?'
  ],
  'Marketing Specialist': [
    'How do you measure the effectiveness of a marketing campaign?',
    'What channels do you prioritize in digital marketing?',
    'Can you describe a successful marketing campaign you worked on?'
  ],
  'Pre-Sales Executive': [
    'What is your approach to understanding a client’s needs during pre-sales?',
    'How do you manage objections from clients?',
    'Describe a situation where you successfully closed a deal through pre-sales activities.'
  ],
  'Client Handling Manager': [
    'How do you manage client relationships and expectations?',
    'Can you provide an example of how you resolved a conflict with a client?',
    'What strategies do you use to ensure client satisfaction and retention?'
  ],
  'Sales Executive': [
    'How do you approach cold calling and lead generation?',
    'Can you describe a time when you successfully closed a large deal?',
    'What strategies do you use to overcome sales objections?'
  ],
  'others': [
    'What experience do you have in this role?',
    'What challenges have you faced in this field?',
    'What do you believe is essential for success in this job?'
  ]
};

module.exports = jobRoleQuestions;
