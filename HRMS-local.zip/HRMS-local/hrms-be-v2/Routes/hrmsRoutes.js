const express = require('express');
const hrmsrouter = express.Router();

const hrRouter = require('./hrRoutes');
const candidateRouter = require('./candidateRoutes');
const authRouter = require('./authRoutes');

hrmsrouter.use('/auth', authRouter);
hrmsrouter.use('/candidate', candidateRouter);
hrmsrouter.use('/hr', hrRouter);

module.exports = hrmsrouter;
