
const express = require('express');
const passport = require('passport');
const authController = require('../Controllers/authController');
const commoncontroller = require('../Controllers/Common/commonController'); 

const authRouter = express.Router();

authRouter.get('/start',
  authController.login,
  passport.authenticate('oidc', {
    scope: "openid refresh_token",
  }),
  authController.authenticate 
);

authRouter.get('/logout',
  authController.logout,
  passport.authenticate('oidc', {
    scope: "openid refresh_token",
  }),
);

authRouter.post('/verify', 
  passport.authenticate('oidc'), 
  (req, res, next) => {
    next();
  },
  authController.verifySession
);

authRouter.post('/jobs', commoncontroller.getAllJob);
authRouter.post('/job-details', commoncontroller.getJobById);


module.exports = authRouter;
