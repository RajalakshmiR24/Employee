const express = require('express');
const fileUpload = require('express-fileupload');  
const candidateController = require('../Controllers/candidateController');
const hrController = require('../Controllers/hrController'); 
const commoncontroller = require('../Controllers/Common/commonController'); 

const {verifyToken, findRoleByHash, HRmiddleware} = require('../Middlewares/auth');

const hrRouter = express.Router();

hrRouter.use(fileUpload());
hrRouter.use(verifyToken);
hrRouter.use(HRmiddleware);

// hrRouter.use(findRoleByHash);
hrRouter.post('/create-hr', hrController.createHRDetails);

hrRouter.post('/name', hrController.getHRDetailsByHash);
hrRouter.post('/overview', candidateController.getHRDashboardOverview);
hrRouter.post('/all-candidates', candidateController.getAllCandidates);

hrRouter.post('/del', candidateController.candidateDelete);
hrRouter.post('/create-jobrole', hrController.createJobRole);
hrRouter.post('/all-jobdetails', hrController.getJobDetailsEnums);
hrRouter.post('/get-allhr', hrController.getAllHR);
hrRouter.post('/delete-hr', hrController.updateStatusToSuspended);

hrRouter.post('/get-all-jobs', commoncontroller.getAllJobDetails);


hrRouter.post('/candidate-status', candidateController.updateCandidateStatus);
hrRouter.post('/upload-excel',hrController.handleExcelUpload);
hrRouter.post('/upload-resume',hrController.uploadCandidateResume);
hrRouter.post('/roles-status',hrController.getJobRolesAndStatuses);
hrRouter.post('/upload-formresume',hrController.uploadFormResume);

module.exports = hrRouter;
