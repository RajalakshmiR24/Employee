const express = require('express');
const candidateRoutes = express.Router();
const candidateController = require('../Controllers/candidateController');
const {verifyToken, checkCandidateEligibility,Candidatemiddleware, findRoleByHash, CandidateProfileCheck} = require('../Middlewares/auth');



candidateRoutes.use(verifyToken);
candidateRoutes.use(Candidatemiddleware);

// candidateRoutes.use(findRoleByHash);

candidateRoutes.use(checkCandidateEligibility);

candidateRoutes.post('/name',candidateController.getCandidateDetailsByHash);
candidateRoutes.post('/candy',CandidateProfileCheck,candidateController.getCandidate);

candidateRoutes.post('/upload-resume',candidateController.uploadResume);
candidateRoutes.post('/upload-kyc',candidateController.uploadKYC);
candidateRoutes.post('/get-job-roles', candidateController.getJobRoles);
candidateRoutes.post('/profile', candidateController.getCandidateDetails);

candidateRoutes.post('/update-profile', candidateController.updateCandidate);

candidateRoutes.post('/update-job-role',candidateController.updateJobRoles);


candidateRoutes.patch('/cameraPermission',candidateController.updateCameraPermission);
candidateRoutes.post('/get-job-role-questions',candidateController.getJobRoleQuestions);



module.exports = candidateRoutes;
