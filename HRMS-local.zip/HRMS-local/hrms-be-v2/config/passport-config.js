

const passport = require('passport');
const { Strategy } = require('openid-client');
const { saveUserSession } = require('../Controllers/authController');

const configurePassport = (client) => {
  passport.serializeUser((user, done) => {
    // console.log('user', user);

    done(null, user);
  });

  passport.deserializeUser((user, done) => {
    // console.log('user', user);

    done(null, user);
  });

  passport.use('oidc', new Strategy({ client, passReqToCallback: true }, async (req, tokenSet, userinfo, done) => {
    try {
      // console.log("tokenSet", tokenSet);
      // console.log("userinfo", userinfo);
      const role = await saveUserSession(req, tokenSet, userinfo);

      req.session.tokenSet = tokenSet;
      req.session.userinfo = userinfo;
      console.log(role);



      const userClaims = tokenSet.claims();

      const data = {
        Auth_token: tokenSet.access_token,
        Role: role
        
      };

      req.details = data;

      return done(null, userClaims, data);
    } catch (err) {
      console.error("Error during Passport OIDC authentication:", err);
      return done(err);
    }
  }));
};

module.exports = configurePassport;
