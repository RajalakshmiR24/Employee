const Candidate = require('../Models/candidate');
const HR = require('../Models/hr');
const Token = require('../Models/token');
const axios = require('axios');

const verifyToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(200).json({ code: 400, message: 'Token is required.' });
  }


  try {
    const storedToken = await Token.findOne({ access_token: token });

    if (!storedToken) {
      return res.status(200).json({ code: 404, message: 'Token not found in database.' });
    }
    if (storedToken.used) {
      return res.status(200).json({ code: 403, message: 'This token has already been used and is no longer valid.' });
    }
    storedToken.used = true;
    await storedToken.save();
    let user = await Token.findOne({ userhash: storedToken.userhash })

    if (!user) {
      return res.status(200).json({ code: 401, message: "User not found." });
    }
    const role = storedToken.role || user.role;

    if (role === 'hr' || role === 'candidate') {
      req.user = user;
      req.role = role;


      const oidcIssuer = process.env.OIDC_ISSUER_AUTH;
      const externalUrl = `${oidcIssuer}/account/me`;

      try {
        const externalResponse = await axios.get(externalUrl, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });



        req.hash = externalResponse.data.hash;
        req.externalData = externalResponse.data;

        next();

      } catch (error) {
        return res.status(200).json({ code: 500, error: error.message });
      }

    } else {
      return res.status(200).json({ code: 403, message: 'Access denied. Only HR and CANDIDATE roles are allowed.' });
    }

  } catch (error) {
    return res.status(200).json({ code: 500, error: error.message });
  }
};

const checkCandidateEligibility = async (req, res, next) => {
  try {
    const hash = req.hash;

    if (!hash) {
      return res.status(200).json({
        code: 400,
        message: "Phone number not provided.",
      });
    }

    const candidate = await Candidate.findOne({ hash: hash });

    if (!candidate) {
      return res.status(200).json({
        code: 400,
        message: "Candidate not found.",
      });
    }

    req.jobRole = candidate.job_role;

    if (candidate.invited === false) {
      return res.status(200).json({
        code: 400,
        message: "You're not invited by any HR, please contact HR.",
      });
    }

    const lastInterviewDate = new Date(candidate.walkin_date);
    if (isNaN(lastInterviewDate)) {
      return res.status(200).json({
        code: 400,
        message: "Invalid last interview date.",
      });
    }

    const currentDate = new Date();
    const sixMonthsLater = new Date(lastInterviewDate);
    sixMonthsLater.setMonth(sixMonthsLater.getMonth() + 6);

    const candidateWalkinDate = new Date(candidate.walkin_date);
    if (isNaN(candidateWalkinDate)) {
      return res.status(200).json({
        code: 400,
        message: "Invalid walk-in date.",
      });
    }

    const candidateInterviewDate = candidateWalkinDate.setHours(0, 0, 0, 0);
    const todayDate = new Date().setHours(0, 0, 0, 0);

    if (candidateInterviewDate === todayDate) {
      return next();
    }

    if (candidate.job_Status === "IN_PROGRESS") {
      return res.status(200).json({
        code: 200,
        message: `Not eligible for today's interview, please wait until ${candidate.walkin_date.toLocaleDateString()}.`,
      });
    }

    const diffInTime = sixMonthsLater - currentDate;
    const diffInMonths = Math.floor(diffInTime / (1000 * 3600 * 24 * 30));
    const remainingDaysInMonth = Math.floor((diffInTime % (1000 * 3600 * 24 * 30)) / (1000 * 3600 * 24));

    if (currentDate < sixMonthsLater) {
      return res.status(200).json({
        code: 400,
        message: `You are "${candidate.description}" for the role of "${candidate.job_role}". Not eligible for interview, please wait ${diffInMonths} months and ${remainingDaysInMonth} days until ${sixMonthsLater.toLocaleDateString()}.`,
        waitMonths: diffInMonths,
        waitDays: remainingDaysInMonth,
      });
    }

    return res.status(200).json({
      code: 200,
      message: `You are "${candidate.description}" for the role of "${candidate.job_role}". Not eligible for today's interview, please wait ${diffInMonths} months and ${remainingDaysInMonth} days until ${sixMonthsLater.toLocaleDateString()}.`,
    });

  } catch (error) {
    return res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};

const findRoleByHash = async (req, res, next) => {
  const userHash = req.headers['user-hash'];

  if (!userHash) {
    return res.status(200).json({ code: 400, error: 'User hash is required.' });
  }

  try {

    let user = await HR.findOne({ hash: userHash }) ||
      await Candidate.findOne({ hash: userHash });

    if (!user) {
      return res.status(200).json({ code: 404, error: 'User not found.' });
    }


    req.hash = user.hash;


    next();
  } catch (error) {
    console.error('Error:', error.message);
    return res.status(200).json({ code: 500, error: error.message });
  }
};

const HRmiddleware = async (req, res, next) => {
  const hash = req.hash;


  if (!hash) {
    return res.status(400).json({
      code: 400,
      message: 'Hash is required.',
    });
  }


  try {
    const user = await HR.findOne({ hash });


    if (!user) {
      return res.status(404).json({
        code: 404,
        message: 'User not found.',
      });
    }

    req.hr_id = user.hr_id;
    req.name = user.name;
    req.role = user.role;
    req.position = user.position;
    
    next();
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({
      code: 500,
      error: error.message,
    });
  }
};

const Candidatemiddleware = async (req, res, next) => {
  const hash = req.hash;

  if (!hash) {
    return res.status(200).json({
      code: 400,
      message: 'Hash is required.',
    });
  }

  try {
    
    // Find the user by hash
    const users = await Candidate.find({ hash: hash });


    if (users.length === 0) {
      return res.status(200).json({
        code: 404,
        message: 'User not found.',
      });
    }

    const user = users[0];  // Access the first user from the array

    req.candidate_id = user.candidate_id;
    req.name = user.name;
    req.role = user.role;
    req._id = user._id;

    next();
  } catch (error) {
    console.error("Error occurred during user retrieval:", error.message);
    return res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};

const CandidateProfileCheck = async (req, res, next) => {
  const candidate_id = req.candidate_id;

  if (!candidate_id) {
    return res.status(200).json({
      code: 400,
      message: 'Candidate ID is required.',
    });
  }

  try {
    const candidate = await Candidate.findOne({ candidate_id: candidate_id });

    if (!candidate) {
      return res.status(200).json({
        profile: false,
        message: "Need to fill all information",
        code: 404,
      });
    }

    if (candidate.profile === true) {
      return next();  // Pass control to the next middleware if profile is true
    } else {
      return res.status(200).json({
        profile: false,
        message: "Need to fill all information",
        code: 200,
      });
    }
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({
      code: 500,
      error: error.message,
    });
  }
};


module.exports = { verifyToken, checkCandidateEligibility, findRoleByHash, HRmiddleware, Candidatemiddleware, CandidateProfileCheck};
