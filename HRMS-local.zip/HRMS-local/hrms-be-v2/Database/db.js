const mongoose = require("mongoose");
const HR = require("../Models/hr"); 
const Candidate = require("../Models/candidate"); 
const crypto = require("crypto");

const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URL, {
            serverSelectionTimeoutMS: 30000,
            socketTimeoutMS: 45000
        });
        mongoose.set('strictPopulate', false); 
        console.log("MongoDB Connected");
        await checkAndCreateHR();
        
    } catch (error) {
        console.error("Database connection error:", error.message);
    }
}


const checkAndCreateHR = async () => {
    try {
        const hrCount = await HR.countDocuments();

        if (hrCount === 0) {
            // Get the environment variables
            const phone_number = process.env.HR_PHONE_NUMBER;
            const name = process.env.HR_NAME;
            const email = process.env.HR_EMAIL;
            const position = process.env.HR_POSITION;
            const organization_name = process.env.HR_ORG_NAME;
            const organization_address = process.env.HR_ORG_ADDRESS;
            const organization_contact_phone = process.env.HR_ORG_CONTACT_PHONE;
            const organization_contact_email = process.env.HR_ORG_CONTACT_EMAIL;
            const status = process.env.HR_STATUS;
            const join_date = process.env.HR_JOIN_DATE || new Date();  // Use current date if not specified in .env
            const organization_website = process.env.HR_ORG_WEBSITE;  // Add this to get the website from environment

            // Check if the HR email already exists
            const existingHR = await HR.findOne({ email });
            if (existingHR) {
                console.log("HR with this email already exists.");
                return;
            }

            // Check if the candidate email already exists
            const existingCandidateEmail = await Candidate.findOne({ email });
            if (existingCandidateEmail) {
                console.log("Email already exists in Candidate collection.");
                return;
            }

            // Check if the HR phone number already exists
            const existingHRPhone = await HR.findOne({ phone_number });
            if (existingHRPhone) {
                console.log("Phone number already exists in HR collection.");
                return;
            }

            // Check if the candidate phone number already exists
            const existingCandidatePhone = await Candidate.findOne({ phone_number });
            if (existingCandidatePhone) {
                console.log("Phone number already exists in Candidate collection.");
                return;
            }

            // Create hash from phone number
            const hash = crypto.createHash('sha256')
                               .update(phone_number)
                               .digest('hex');  

            // Create the new HR record
            const newHR = new HR({
                phone_number,
                hash,
                name,
                email,
                position,
                organization_name,
                organization_address,
                organization_contact: {
                    phone_number: organization_contact_phone,
                    email: organization_contact_email,
                },
                organization_website,  // Include the website here
                status,
                join_date,
            });

            // Save the new HR record
            await newHR.save();
            console.log("HR created successfully.");
        } else {
            console.log("HR already exists.");
        }
    } catch (error) {
        console.error("Error while checking and creating HR: ", error);
    }
};

module.exports = connectDB;
