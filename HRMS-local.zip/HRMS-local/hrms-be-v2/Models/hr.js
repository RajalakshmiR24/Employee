const { Schema, model } = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
const urlRegex = /^(https?:\/\/)?([\w\d\-_]+\.)+[a-z]{2,6}(\/[\w\d\-_.]*)*\/?$/;  // Regex for validating URL

const htmlTagRegex = /<[^>]*>/g; 

const hrSchema = new Schema({
  hr_id: {
    type: String,
    default: uuidv4,
    unique: true,
  },
  phone_number: {
    type: String,
    required: [true, 'Phone number is required'],
    trim: true,
    minlength: [10, 'Phone number must be at least 10 digits'],
    maxlength: [15, 'Phone number cannot exceed 15 digits'],
    match: [/^[6-9][0-9]{9}$/, 'Phone number must start with 6, 7, 8, or 9 and contain only digits'],
  },
  hash: {
    type: String,
    required: [true, 'Hash is required'],
    match: [/^[^<]*$/, 'Hash cannot contain HTML tags'], 
  },
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    minlength: [3, 'Name must be at least 3 characters'],
    maxlength: [100, 'Name cannot exceed 100 characters'],
    match: [/^[A-Za-z\s]+$/, 'Name must only contain alphabets and spaces and cannot start with spaces'],
    match: [/^[^<]*$/, 'Name cannot contain HTML tags'], 
  },
  role: {
    type: String,
    enum: ['candidate', 'hr'],
    default: 'hr',
    required: [true, 'Role is required'],
  },
  email: {
    type: String,
    required: true,
    unique: true,
    minlength: [6, 'Email must be at least 6 characters long'],
    maxlength: [255, 'Email cannot be longer than 255 characters'],
    match: [emailRegex, 'Please enter a valid professional email address'],
    match: [/^[^<]*$/, 'Email cannot contain HTML tags'], 
  },
  position: {
    type: String,
    required: true,
  },
  organization_name: {
    type: String,
    required: [true, 'Organization name is required'],
    trim: true,
    minlength: [3, 'Organization name must be at least 3 characters'],
    maxlength: [255, 'Organization name cannot exceed 255 characters'],
    match: [/^[A-Za-z0-9\s&,-]+$/, 'Organization name must contain only letters, numbers, spaces, and special characters like &, -'],
  },
  organization_id: {
    type: String,
    default: uuidv4,  // Unique ID for each organization
    unique: true,
  },
  organization_address: {
    type: String,
    required: [true, 'Organization address is required'],
    trim: true,
    minlength: [5, 'Organization address must be at least 5 characters'],
    maxlength: [500, 'Organization address cannot exceed 500 characters'],
  },
  organization_contact: {
    phone_number: {
      type: String,
      match: [/^[6-9][0-9]{9}$/, 'Phone number must start with 6, 7, 8, or 9 and contain only digits'],
    },
    email: {
      type: String,
      match: [emailRegex, 'Please enter a valid email address for the organization'],
    },
  },
  organization_website: {
    type: String,
    required: [true, 'Organization website is required'],
    match: [urlRegex, 'Please enter a valid website URL'],
    trim: true,
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'on_leave', 'suspended'],
    default: 'active',
    required: true,
  },
  join_date: {
    type: Date,
    default: Date.now,
  },
}, { timestamps: true });

const HR = model('HR', hrSchema);

module.exports = HR;
