const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const departments = [
    'HR', 'Engineering', 'Sales', 'Marketing', 'Finance', 'Customer Support',
    'Operations', 'Product', 'Legal', 'IT', 'R&D', 'Business Development',
    'Supply Chain', 'Quality Assurance', 'Admin', 'Healthcare', 'Design',
    'Logistics', 'Training and Development', 'Compliance', 'Public Relations',
    'Technology', 'Others'
];

const jobDetailsSchema = new mongoose.Schema({
    job_id: {
        type: String,
        default: uuidv4,
        unique:true,
        match: [/^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$/, 'Invalid UUID format']
    },
    postingTitle: {
        type: String,
        required: [true, 'Posting title is required'],
        match: [/^[a-zA-Z0-9\s,.'-]{3,100}$/, 'Invalid posting title format'],
        minlength: 3,
        maxlength: 100,
    },
    title: {
        type: String,
        required: [true, 'Job title is required'],
        match: [/^[a-zA-Z\s]{3,50}$/, 'Invalid job title format'],
        minlength: 3,
        maxlength: 50,
    },
    departmentName: {
        type: String,
        enum: departments,
        required: [true, 'Department name is required'],
    },
    hiringManager: {
        name: {
            type: String,
            required: [true, 'Hiring manager name is required'],
        },
        hr_id: {
            type: String, 
            ref: 'HR',
            required: [true, 'Hiring manager ID is required'],
        }
    },
    
    numOfPositions: {
        type: Number,
        required: [true, 'Number of positions is required'],
        min: [1, 'At least one position is required'],
        max: [1000, 'Maximum number of positions is 1000'],
    },
    targetDate: {
        type: Date,
        required: [true, 'Target date is required'],
    },
    dateOpened: {
        type: Date,
        required: [true, 'Date opened is required'],
    },
    jobOpeningStatus: {
        type: String,
        enum: ['Open', 'Closed', 'Pending'],
        default: 'Open',
    },
    jobType: {
        type: String,
        enum: ['Full-time', 'Part-time', 'Contract', 'Temporary'],
        default: 'Full-time',
    },
    industry: {
        type: String,
        enum: ['Technology', 'Finance', 'Healthcare', 'Education', 'Retail', 'Manufacturing', 'Construction', 'Government', 'Others'],
        required: [true, 'Industry is required'],
    },
    workExp: {
        type: String,
        match: [/^\d{1,2}-\d{1,2} years$/, 'Invalid format for workExp'],
        validate: {
            validator: function (value) {
                const sanitizedValue = value.trim().replace(' years', '');
                const [min, max] = sanitizedValue.split('-').map(Number);
                console.log('Sanitized workExp value:', sanitizedValue);
                console.log('Parsed values:', min, max);
                return min >= 0 && max <= 30 && min <= max;
            },
            message: 'Experience range must be between 0-30 years, and min should not exceed max.'
        },
        default: '0-2 years'
    },

    salary: {
        type: String,
        match: [/^\d{1,7}-\d{1,7}$/, 'Invalid salary format. Salary should be in "min-max" format (e.g., "75000-95000").'],
        validate: {
            validator: function (value) {
                const [minSalary, maxSalary] = value.split('-').map(Number);
                return minSalary >= 0 && maxSalary > minSalary;
            },
            message: 'Salary range must have positive values and min should not exceed max.',
        },
    },

    requiredSkills: {
        type: [String],
        required: [true, 'Required skills are required'],
        minlength: 1,
        maxlength: 40,
    },
    address: {
        city: {
            type: String,
            required: [true, 'City is required'],
            match: [/^[a-zA-Z\s]{2,50}$/, 'Invalid city name format'],
            minlength: 2,
            maxlength: 50,
        },
        state: {
            type: String,
            required: [true, 'State is required'],
            match: [/^[a-zA-Z\s]{2,50}$/, 'Invalid state name format'],
            minlength: 2,
            maxlength: 50,
        },
        country: {
            type: String,
            required: [true, 'Country is required'],
            match: [/^[a-zA-Z\s]{2,50}$/, 'Invalid country name format'],
            minlength: 2,
            maxlength: 50,
        },
        zip: {
            type: String,
            required: [true, 'Zip code is required'],
        },
    },
    notes: {
        jobDescription: {
            type: String,
            required: [true, 'Job description is required'],
            minlength: 20,
            maxlength: 5000,
        },
        requirements: {
            type: String,
            required: [true, 'Requirements are required'],
            minlength: 20,
            maxlength: 5000,
        },
        benefits: {
            type: String,
            minlength: 5,
            maxlength: 1000,
        },
    },
    hr_id:{
        type:String
      },

}, { timestamps: true });



const JobDetails = mongoose.model('JobDetails', jobDetailsSchema);

module.exports = JobDetails;
