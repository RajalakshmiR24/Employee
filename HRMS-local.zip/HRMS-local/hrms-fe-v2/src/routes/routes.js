import { createBrowserRouter, Navigate } from "react-router-dom";

import CandidateLayout from "../layout/CandidateLayout";
import HRLayout from "../layout/HRLayout";

import NotFound from "../common/NotFound";
import Landing from "../common/Landing";
import Auth from "../auth/Auth";
import CandidateDashboard from "../pages/Candidate_Pages/CandidateDashboard";

import Candidate from "../pages/Candidate_Pages/Candidate";
import VerificationPage from "../pages/Candidate_Pages/VerificationPage";

import HRDashboard from "../pages/HR_Pages/HRDashboard";
import CandidateList from "../pages/HR_Pages/CandidateList";
import SearchRole from "../components/SearchBox/SearchRole";
import JobRoleForm from "../components/Form/jobRoleForm"

import TermsAndConditions from "../components/SearchBox/TermsAndConditions";

import ProtectedRoute from "./ProtectedRoute";
import Task from "../pages/Candidate_Pages/Task";
import TaskLayout from "../layout/TaskLayout";
import Home from "../pages/PublicSite/Home";
import PublicSitecareer from "../layout/PublicSite_career";
import JobDetails from "../pages/PublicSite/JobDetails";
import HRList from "../pages/HR_Pages/HRList";
import JobList from "../pages/HR_Pages/JobList";
import ProfilePage from "../pages/Candidate_Pages/ProfilePage";
import CandidateProfileForm from "../components/Form/CandidateProfileForm";

const candidateRoutes = [
  { index: true, element: <CandidateDashboard /> },
  { path: "profile", element: <ProfilePage /> },
  { path: "candidate-form", element: <CandidateProfileForm /> },
  { path: "selectrole", element: <SearchRole /> },
  { path: "welcome", element: <Candidate /> },
  { path: "terms", element: <TermsAndConditions /> },
];

const PublicSiteRoutes = [
  { index: true, element: <Home /> },
  { path:"job-details/:jobtitle", element: <JobDetails /> },
];

const hrRoutes = [
  { index: true, element: <HRDashboard /> },
  { path: "candidate-list", element: <CandidateList /> },
  { path: "hr-list", element: <HRList /> },
  { path: "job-list", element: <JobList /> },
  {path: "add-job-role", element: <JobRoleForm/>}
];

const candidateRole = "candidate";
const hrRole = "hr";

export default createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/hrms/careers" />,
  },
  {
    path: "/hrms",
    element: <Landing />,
  },
  
  {
    path: "/hrms/auth-start",
    element: <Auth />,
  },
  {
    path: "/hrms/status",
    element: (
      <ProtectedRoute role={candidateRole}>
        <VerificationPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/hrms/careers",
    element: <PublicSitecareer />,
    children: PublicSiteRoutes,
  },
  {
    path: "/hrms/candidate",
    element: (
      <ProtectedRoute role={candidateRole}>
        <CandidateLayout />
      </ProtectedRoute>
    ),
    children: candidateRoutes,
  },
  {
    path: "/hrms/hr",
    element: (
      <ProtectedRoute role={hrRole}>
        <HRLayout />
      </ProtectedRoute>
    ),
    children: hrRoutes,
  },
  {
    path: "/hrms/candidate-task",
    element: (
      <ProtectedRoute role={candidateRole}>
        <TaskLayout />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <Task /> },
    ],
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);
