import React from "react";
import { Navigate } from "react-router-dom";

const isAuthenticated = () => {
  const hrmstoken = localStorage.getItem("hrmstoken");
  // const hrmstoken = localStorage.getItem("user-hash");
  
  return hrmstoken;
};

const ProtectedRoute = ({ children }) => {
  if (!isAuthenticated()) {
    localStorage.removeItem("hrmstoken");
    return <Navigate to="/hrms" />;
  }

  return <div>{children}</div>;
};

export default ProtectedRoute;
