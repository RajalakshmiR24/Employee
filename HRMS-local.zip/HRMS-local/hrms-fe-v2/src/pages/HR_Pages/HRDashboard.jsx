
import React from 'react'
import HRDashboardOverview from '../../components/Card/HRDashboardOverview'

const HRDashboard = () => {
  return (
    <div>
      <HRDashboardOverview />     
    </div>
  )
}

export default HRDashboard
