import React, { useEffect, useState } from 'react';
import axiosInstance from "../../utils/axiosInstance";
import theme from '../../style/theme';
import { useNavigate } from 'react-router-dom';

const JobList = () => {
  const [jobDetails, setJobDetails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedJob, setSelectedJob] = useState(null); // Store the selected job for the detailed view

  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        setLoading(true);
        const response = await axiosInstance.post('/api/hrms/hr/get-all-jobs');

        if (response.data.code === 200) {
          setJobDetails(response.data.data);
        } else {
          setError(response.data.message);
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchJobDetails();
  }, []);
  const navigate = useNavigate();

  const handleAddJobRole = () => {
    navigate('/hrms/hr/add-job-role');
  };

  const handleViewJob = (job) => {
    setSelectedJob(job);
  };

  if (loading) {
    return <div>Loading job details...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div style={{ padding: '20px' }}>
      <button
        onClick={() => handleAddJobRole()}
        style={{
          backgroundColor: theme.colors.primary,
          color: theme.colors.secondary,
          padding: '10px 16px',
          fontSize: '16px',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer',
          margin: '5px',
          fontFamily: theme.typography.fontFamily,
          transition: 'background-color 0.3s',
        }}
      >
        Add Job role
      </button>
      <h1 style={{ ...theme.card.header }}>Job List</h1>


      <div>
        <table style={theme.table.table}>
          <thead>
            <tr>
              <th style={theme.table.th}>#</th>
              <th style={theme.table.th}>Title</th>
              <th style={theme.table.th}>Department</th>
              <th style={theme.table.th}>Location</th>
              <th style={theme.table.th}>Salary</th>
              <th style={theme.table.th}>Posted By</th>
              <th style={theme.table.th}>Target Date</th>
              <th style={theme.table.th}>Actions</th>
            </tr>
          </thead>
          {jobDetails.length === 0 ? (
            <p>No job details available.</p>
          ) : (
            <tbody>
              {jobDetails.map((job, index) => (
                <tr key={index} style={{ cursor: 'pointer' }}>
                  <td style={theme.table.td}>{index + 1}</td>
                  <td style={theme.table.td}>{job.title}</td>
                  <td style={theme.table.td}>{job.departmentName}</td>
                  <td style={theme.table.td}>
                    {job.address ? `${job.address.city}, ${job.address.state}` : "N/A"}
                  </td>
                  <td style={theme.table.td}>
                    ₹{job.salary.split('-')[0]} - ₹{job.salary.split('-')[1]}
                  </td>
                  <td style={theme.table.td}>
                    {job.hiringManager ? job.hiringManager.name : "N/A"}
                  </td>
                  <td style={theme.table.td}>{new Date(job.targetDate).toLocaleDateString()}</td>
                  <td style={theme.table.td}>
                    <button
                      onClick={() => handleViewJob(job)}
                      style={{
                        padding: '5px 10px',
                        backgroundColor: theme.colors.primary,
                        color: '#fff',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                      }}
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          )}
        </table>
      </div>


      {selectedJob && (
        <div style={{ marginTop: '20px', padding: '20px', border: '1px solid #ccc' }}>
          <h2>Job Details</h2>
          <p><strong>Title:</strong> {selectedJob.title}</p>
          <p><strong>Department:</strong> {selectedJob.departmentName}</p>
          <p><strong>Location:</strong> {selectedJob.address ? `${selectedJob.address.city}, ${selectedJob.address.state}` : "N/A"}</p>
          <p><strong>Salary:</strong> ₹{selectedJob.salary.split('-')[0]} - ₹{selectedJob.salary.split('-')[1]}</p>
          <p><strong>Hiring Manager:</strong> {selectedJob.hiringManager ? selectedJob.hiringManager.name : "N/A"}</p>
          <p><strong>Target Date:</strong> {new Date(selectedJob.targetDate).toLocaleDateString()}</p>
          <p><strong>Job Description:</strong> {selectedJob.notes.jobDescription}</p>
          <p><strong>Requirements:</strong> {selectedJob.notes.requirements}</p>
          <p><strong>Benefits:</strong> {selectedJob.notes.benefits}</p>
          <p><strong>Industry:</strong> {selectedJob.industry}</p>
          <p><strong>Work Experience:</strong> {selectedJob.workExp}</p>
          <p><strong>Required Skills:</strong> {selectedJob.requiredSkills.join(', ')}</p>
          <p><strong>Job Type:</strong> {selectedJob.jobType}</p>
          <p><strong>Status:</strong> {selectedJob.jobOpeningStatus}</p>
        </div>
      )}
    </div>
  )
}


export default JobList;
