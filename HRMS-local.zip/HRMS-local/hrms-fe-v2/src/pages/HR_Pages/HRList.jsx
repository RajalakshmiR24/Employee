import React, { useState, useEffect } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import theme from '../../style/theme';
import { FaEdit, FaTrash } from 'react-icons/fa';

const HRList = () => {
  const [hrRecords, setHrRecords] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchHRRecords = async () => {
      try {
        const response = await axiosInstance.post('/api/hrms/hr/get-allhr');
        setHrRecords(response.data);
      } catch (err) {
        setError('Failed to fetch HR records');
        console.error(err);
      }
    };

    fetchHRRecords();
  }, []);

  const handleEdit = (hrId) => {
    console.log('Edit HR record with ID:', hrId);
  };



const handleDelete = async (hr_id) => {
  try {
   
   const response= await axiosInstance.post(`/api/hrms/hr/delete-hr`,{hr_id});
   console.log(hr_id, "delete_hrId");
   
  alert(response.data.message)
  } catch (err) {
    alert(err);
  }
};


  const formatWebsite = (website) => {
    if (website && !website.startsWith('http://') && !website.startsWith('https://')) {
      return `https://${website}`;
    }
    return website;
  };

  if (error) {
    return (
      <div style={{ ...theme.card.container }}>
        <p style={{ color: theme.colors.textPrimary }}>{error}</p>
      </div>
    );
  }

  return (
    <div>
      <h1 style={{ ...theme.card.header }}>HR Records</h1>
      <div>
        <table style={{ ...theme.table.table }}>
          <thead>
            <tr style={{ ...theme.table.trHover }}>
              <th style={{ ...theme.table.th }}>#</th>
              <th style={{ ...theme.table.th }}>Name</th>
              <th style={{ ...theme.table.th }}>Email</th>
              <th style={{ ...theme.table.th }}>Phone Number</th>
              <th style={{ ...theme.table.th }}>Position</th>
              <th style={{ ...theme.table.th }}>Org Name</th>
              <th style={{ ...theme.table.th }}>Org Address</th>
              <th style={{ ...theme.table.th }}>Org Website</th>
              <th style={{ ...theme.table.th }}>Status</th>

              <th style={{ ...theme.table.th }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {hrRecords.length > 0 ? (
              hrRecords.map((hr, index) => (
                <tr
                  key={hr.hr_id}
                  style={{
                    ...theme.table.trHover,
                  }}
                >
                  <td style={{ ...theme.table.td }}>{index + 1}</td>
                  <td style={{ ...theme.table.td }}>{hr.name}</td>
                  <td style={{ ...theme.table.td }}>{hr.email}</td>
                  <td style={{ ...theme.table.td }}>{hr.phone_number}</td>
                  <td style={{ ...theme.table.td }}>{hr.position}</td>
                  <td style={{ ...theme.table.td }}>{hr.organization_name}</td>
                  <td style={{ ...theme.table.td }}>{hr.organization_address}</td>
                  <td style={{ ...theme.table.td }}>
                    <a href={formatWebsite(hr.organization_website)} target="_blank" rel="noopener noreferrer">
                      {hr.organization_website}
                    </a>
                  </td>
                  <td style={{ ...theme.table.td }}>{hr.status}</td>

                  <td style={{ ...theme.table.td }}>
                    <div
                      style={{
                        display: 'flex',
                        gap: '10px',
                        alignItems: 'center',
                      }}
                    >
                      <button
                        onClick={() => handleEdit(hr.hr_id)}
                        style={{
                          ...theme.select.select,
                          backgroundColor: '#3498db',
                          color: '#fff',
                          padding: '8px',
                          borderRadius: '4px',
                        }}
                      >
                        <FaEdit style={{ fontSize: '16px' }} />
                      </button>
                      <button
                        onClick={() => handleDelete(hr.hr_id)}
                        style={{
                          ...theme.select.select,
                          backgroundColor: '#e74c3c',
                          color: '#fff',
                          padding: '8px',
                          borderRadius: '4px',
                        }}
                      >
                        <FaTrash style={{ fontSize: '16px' }} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="9" style={{ ...theme.table.td }}>
                  No HR records found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default HRList;
