import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import axiosInstance from '../../utils/axiosInstance'; 

const Home = () => {
  const [jobDetails, setJobDetails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate(); 

  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        const response = await axiosInstance.post('/api/hrms/auth/jobs'); 
        if (response.data.code === 200) {
          setJobDetails(response.data.data);  
        } else {
          setError('No job details found');
        }
      } catch (err) {
        setError('Error fetching job details');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchJobDetails();
  }, []);

  const handleCardClick = (jobId, jobTitle) => {
    navigate(`/hrms/careers/job-details/${jobTitle}`, { state: { jobId } }); // Passing jobId to the next page
  };

  if (loading) {
    return <div style={{ textAlign: 'center', fontSize: '18px', padding: '50px' }}>Loading...</div>;
  }

  if (error) {
    return <div style={{ textAlign: 'center', fontSize: '18px', padding: '50px' }}>{error}</div>;
  }

  return (
    <div style={{ padding: '20px' }}>
      <div className="job-list" style={gridStyle.container}>
        {jobDetails.length > 0 ? (
          jobDetails.map((job, index) => (
            <div
              className="job-card"
              key={index}
              onClick={() => handleCardClick(job.job_id, job.title)} 
              style={cardStyle.container} 
            >
              <h3 style={cardStyle.header}>{job.title || 'Job Title Not Available'}</h3> {/* Fallback title */}
              <p style={cardStyle.body}>{job.notes?.jobDescription || 'No job description available.'}</p>
              <div className="job-meta" style={cardStyle.meta}>
                <span>{job.address?.city}, {job.address?.state}</span>
                <span>{job.salary}</span>
              </div>
              <div className="job-meta" style={cardStyle.meta}>
                <span>Job Type: {job.jobType}</span>
                <span>Experience: {job.workExp}</span>
                <span>Industry: {job.industry}</span>
              </div>
            </div>
          ))
        ) : (
          <div>No job details available</div>
        )}
      </div>
    </div>
  );
};

const gridStyle = {
  container: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', 
    gap: '20px',
    justifyItems: 'center',
  }
};

const cardStyle = {
  container: {
    backgroundColor: '#ffffff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    border: '1px solid #f1f1f1',
  },
  header: {
    fontSize: '20px',
    fontWeight: '600',
    color: '#333',
    marginBottom: '10px',
  },
  body: {
    fontSize: '16px',
    color: '#555',
    marginBottom: '10px',
  },
  meta: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '14px',
    color: '#777',
    marginTop: '10px',
  },
};

export default Home;
