import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom'; 
import axiosInstance from '../../utils/axiosInstance';

const JobDetails = () => {
  const location = useLocation(); 
  const { jobId } = location.state || {}; 
  
  const [jobDetails, setJobDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchJobDetails = async () => {
      if (!jobId) {
        setError('Job ID not found');
        setLoading(false);
        return;
      }
      
      try {
        const response = await axiosInstance.post('/api/hrms/auth/job-details', { jobId }); 
        if (response.data.code === 200 && response.data.data.length > 0) {
          setJobDetails(response.data.data[0]); 
        } else {
          setError('Job not found');
        }
      } catch (err) {
        setError('Error fetching job details');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchJobDetails();
  }, [jobId]); 

  const handleApplyClick = () => {
    const apiUrl = process.env.REACT_APP_HRMS_SERVER || window.location.origin;
    window.open(`${apiUrl}/api/hrms/auth/start`, "_self");
  };

  if (loading) {
    return <div style={{ textAlign: 'center', fontSize: '18px', padding: '50px' }}>Loading job details...</div>;
  }

  if (error) {
    return <div style={{ textAlign: 'center', fontSize: '18px', padding: '50px' }}>{error}</div>;
  }

  if (!jobDetails) {
    return <div style={{ textAlign: 'center', fontSize: '18px', padding: '50px' }}>No job details available.</div>;
  }

  return (
    <div style={{ display: 'flex', padding: '20px', gap: '20px' }}>
      {/* Left Column */}
      <div style={{ flex: 1, padding: '20px', borderRight: '2px solid #ccc' }}>
        <h2>{jobDetails.title}</h2>
        <p>{jobDetails.notes?.jobDescription || 'No job description available.'}</p>

        <div className="job-meta">
          <h3>Job Location</h3>
          <p>{jobDetails.address.city}, {jobDetails.address.state}</p>
        </div>

        <div className="job-meta">
          <h3>Job Details</h3>
          <p><strong>Salary:</strong> ₹{jobDetails.salary}</p>
          <p><strong>Job Type:</strong> {jobDetails.jobType}</p>
          <p><strong>Experience Required:</strong> {jobDetails.workExp}</p>
          <p><strong>Industry:</strong> {jobDetails.industry}</p>
        </div>
      </div>

      {/* Right Column */}
      <div style={{ flex: 1, padding: '20px' }}>
        <div>
          <h3>Notes</h3>
          <div>
            <h4>Job Description</h4>
            <p>{jobDetails.notes?.jobDescription || 'No description available.'}</p>
          </div>
          <div>
            <h4>Requirements</h4>
            <p>{jobDetails.notes?.requirements || 'No requirements listed.'}</p>
          </div>
          <div>
            <h4>Benefits</h4>
            <p>{jobDetails.notes?.benefits || 'No benefits listed.'}</p>
          </div>
        </div>

        <div>
          <h3>Additional Information</h3>
          <p><strong>Target Date:</strong> {new Date(jobDetails.targetDate).toLocaleDateString()}</p>
          <p><strong>Hiring Manager:</strong> {jobDetails.hiringManager.name}</p>
          <p><strong>Department:</strong> {jobDetails.departmentName}</p>
          <p><strong>Number of Positions:</strong> {jobDetails.numOfPositions}</p>
          <p><strong>Job Status:</strong> {jobDetails.jobOpeningStatus}</p>
        </div>
      </div>

      {/* Apply Button */}
      <div style={{ textAlign: 'center', marginTop: '20px' }}>
        <button 
          onClick={handleApplyClick} 
          style={{
            padding: '10px 20px',
            fontSize: '16px',
            backgroundColor: '#007BFF',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          Apply Now
        </button>
      </div>
    </div>
  );
};

export default JobDetails;
