import React, { useState, useEffect } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import { useNavigate } from 'react-router-dom';

const ProfilePage = () => {
    const currentYear = new Date().getFullYear();
    
    const navigate = useNavigate(); 

    const handleEditClick = () => {
      navigate('/hrms/candidate/candidate-form'); 
    };
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        address: '',
        dob: { day: '', month: '', year: '' },
        skills: '',
        linkedin: '',
        github: '',
        education: [
            {
                qualification: '',
                institution: '',
                passingYear: currentYear,
                marks: ''
            }
        ],
        experiences: [
            {
                company: '',
                role: '',
                fromDate: '',
                toDate: '',
                skillsUsed: ''
            }
        ]
    });

    useEffect(() => {
        const fetchCandidateDetails = async () => {
            try {
                const response = await axiosInstance.post('/api/hrms/candidate/profile');
                if (response.status === 200) {
                    const data = response.data[0];

                    setFormData({
                        ...data,
                        education: Array.isArray(data.education) ? data.education : [{
                            qualification: '',
                            institution: '',
                            passingYear: currentYear,
                            marks: ''
                        }],
                        experiences: Array.isArray(data.experiences) ? data.experiences.map((exp) => ({
                            ...exp,
                            fromDate: exp.fromDate ? formatDateToMonth(exp.fromDate) : '',
                            toDate: exp.toDate ? formatDateToMonth(exp.toDate) : ''
                        })) : [],
                        dob: data.dob ? parseDOB(data.dob) : { day: '', month: '', year: '' }
                    });
                }
            } catch (error) {
                console.error('Error fetching profile data:', error);
            }
        };

        const formatDateToMonth = (date) => {
            const formattedDate = new Date(date);
            const year = formattedDate.getFullYear();
            const month = (formattedDate.getMonth() + 1).toString().padStart(2, '0');
            return `${year}-${month}`;
        };

        fetchCandidateDetails();
    }, [currentYear]);

    const parseDOB = (dob) => {
        const date = new Date(dob);
        return {
            day: date.getDate(),
            month: date.getMonth() + 1,
            year: date.getFullYear()
        };
    };

    return (
        <div>
            <h2>Candidate Profile</h2>
            <button onClick={handleEditClick}>Edit</button>

            <div className="form-content">
                <div className="form-column">
                    <div className="form-group">
                        <label>Full Name</label>
                        <p>{formData.name}</p>
                    </div>

                    <div className="form-group">
                        <label>Email</label>
                        <p>{formData.email}</p>
                    </div>

                    <div className="form-group">
                        <label>Phone Number</label>
                        <p>{formData.phone_number}</p>
                    </div>

                    <div className="form-group">
                        <label>Address</label>
                        <p>{formData.address}</p>
                    </div>

                    <div className="form-group">
                        <label>Date of Birth</label>
                        <p>{`${String(formData.dob.day).padStart(2, '0')}/${String(formData.dob.month).padStart(2, '0')}/${formData.dob.year}`}</p>
                    </div>

                    <div className="form-group">
                        <label>Skills</label>
                        <p>{formData.skills}</p>
                    </div>

                    <div className="form-group">
                        <label>LinkedIn Profile</label>
                        <p>{formData.linkedin}</p>
                    </div>

                    <div className="form-group">
                        <label>GitHub Profile</label>
                        <p>{formData.github}</p>
                    </div>
                </div>

                <div className="form-column">
                    <div className="form-section">
                        <h3>Education Details</h3>
                        {formData.education.map((education, index) => (
                            <div key={index}>
                                <h4>Education {index + 1}</h4>

                                <div className="form-group">
                                    <label>Highest Qualification</label>
                                    <p>{education.qualification}</p>
                                </div>

                                <div className="form-group">
                                    <label>Institution Name</label>
                                    <p>{education.institution}</p>
                                </div>

                                <div className="form-group">
                                    <label>Passing Year</label>
                                    <p>{education.passingYear}</p>
                                </div>

                                <div className="form-group">
                                    <label>Marks/Grade</label>
                                    <p>{education.marks}</p>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="form-section">
                        <h3>Work Experience</h3>
                        {formData.experiences.length > 0 ? formData.experiences.map((experience, index) => (
                            <div key={index}>
                                <h4>Experience {index + 1}</h4>

                                <div className="form-group">
                                    <label>Company Name</label>
                                    <p>{experience.company}</p>
                                </div>

                                <div className="form-group">
                                    <label>Role</label>
                                    <p>{experience.role}</p>
                                </div>

                                <div className="experience-range">
                                    <div className="form-group">
                                        <label>From Date</label>
                                        <p>{experience.fromDate}</p>
                                    </div>

                                    <span className="to">To</span>

                                    <div className="form-group">
                                        <label>To Date</label>
                                        <p>{experience.toDate}</p>
                                    </div>
                                </div>

                                <div className="form-group">
                                    <label>Skills Used</label>
                                    <p>{experience.skillsUsed}</p>
                                </div>
                            </div>
                        )) : <p>No experiences added yet.</p>}
                    </div>
                </div>
            </div>
            
        </div>
    );
};

export default ProfilePage;
