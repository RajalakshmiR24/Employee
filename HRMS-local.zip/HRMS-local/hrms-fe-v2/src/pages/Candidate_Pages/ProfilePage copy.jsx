import React, { useState, useEffect } from 'react';
import axiosInstance from '../../utils/axiosInstance';

const ProfilePage = () => {
    const currentYear = new Date().getFullYear();
    const yearsRange = [...Array(11).keys()].map(i => currentYear - i);

    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        address: '',
        dob: { day: '', month: '', year: '' },
        skills: '',
        linkedin: '',
        github: '',
        education: [
            {
                qualification: '',
                institution: '',
                passingYear: currentYear,
                marks: ''
            }
        ],
        experiences: [
            {
                company: '',
                role: '',
                fromDate: '',
                toDate: '',
                skillsUsed: ''
            }
        ]
    });

    const [dirtyFields, setDirtyFields] = useState({});

    useEffect(() => {
        const fetchCandidateDetails = async () => {
            try {
                const response = await axiosInstance.post('/api/hrms/candidate/profile');
                if (response.status === 200) {
                    const data = response.data[0];

                    setFormData({
                        ...data,
                        education: Array.isArray(data.education) ? data.education : [{
                            qualification: '',
                            institution: '',
                            passingYear: currentYear,
                            marks: ''
                        }],
                        experiences: Array.isArray(data.experiences) ? data.experiences.map((exp) => ({
                            ...exp,
                            fromDate: exp.fromDate ? formatDateToMonth(exp.fromDate) : '',
                            toDate: exp.toDate ? formatDateToMonth(exp.toDate) : ''
                        })) : [],
                        dob: data.dob ? parseDOB(data.dob) : { day: '', month: '', year: '' }
                    });
                }
            } catch (error) {
                console.error('Error fetching profile data:', error);
            }
        };


        const formatDateToMonth = (date) => {
            const formattedDate = new Date(date);
            const year = formattedDate.getFullYear();
            const month = (formattedDate.getMonth() + 1).toString().padStart(2, '0');
            return `${year}-${month}`;
        };


        fetchCandidateDetails();
    }, [currentYear]);

    const parseDOB = (dob) => {
        const date = new Date(dob);
        return {
            day: date.getDate(),
            month: date.getMonth() + 1,
            year: date.getFullYear()
        };
    };

    const handleChange = (e) => {
        const { name, value, dataset } = e.target;
        let newValue = value;


        const isEducationField = name.startsWith('education');
        const isExperienceField = name.startsWith('experience');


        if (isEducationField) {
            const index = dataset.index;
            const field = name.split('-')[1];

            setFormData(prevFormData => {
                const updatedEducation = prevFormData.education.map((edu, i) =>
                    i === parseInt(index) ? { ...edu, [field]: newValue } : edu
                );

                return { ...prevFormData, education: updatedEducation };
            });


        } else if (isExperienceField) {
            const index = dataset.index;
            const field = name.split('-')[0];


            if (field === 'fromDate' || field === 'toDate') {

                const [day, month, year] = newValue.split('/').map(val => parseInt(val, 10));
                newValue = new Date(year, month - 1, day);
            }

            setFormData(prevFormData => {
                const updatedExperiences = prevFormData.experiences.map((exp, i) =>
                    i === parseInt(index) ? { ...exp, [field]: newValue } : exp
                );

                return { ...prevFormData, experiences: updatedExperiences };
            });


        } else {

            setFormData(prevFormData => ({ ...prevFormData, [name]: newValue }));
        }


        setDirtyFields(prevDirtyFields => ({
            ...prevDirtyFields,
            [name]: newValue
        }));
    };



    const addEducation = () => {
        setFormData(prevFormData => ({
            ...prevFormData,
            education: [
                ...prevFormData.education,
                {
                    qualification: '',
                    institution: '',
                    passingYear: currentYear,
                    marks: ''
                }
            ]
        }));
    };

    const removeEducation = (index) => {
        const newEducation = formData.education.filter((_, i) => i !== index);
        setFormData({
            ...formData,
            education: newEducation
        });
    };

    const addExperience = () => {
        setFormData(prevFormData => ({
            ...prevFormData,
            experiences: [
                ...prevFormData.experiences,
                {
                    company: '',
                    role: '',
                    fromDate: '',
                    toDate: '',
                    skillsUsed: ''
                }
            ]
        }));
    };

    const removeExperience = (index) => {
        const newExperiences = formData.experiences.filter((_, i) => i !== index);
        setFormData({
            ...formData,
            experiences: newExperiences
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();


        const updatedData = Object.keys(dirtyFields).reduce((acc, key) => {
            if (dirtyFields[key] !== formData[key]) {
                acc[key] = dirtyFields[key];
            }
            return acc;
        }, {});

        try {
            const response = await axiosInstance.post('/api/hrms/candidate/update-profile', updatedData);
            if (response.status === 200) {
                console.log('Profile updated successfully:', response.data);
                console.log('Profile updated successfully:', updatedData);
            }
        } catch (error) {
            console.error('Error updating profile:', error);
        }
    };

    return (
        <div>
            <h2>Candidate Profile</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-content">
                    <div className="form-column">
                        <div className="form-group">
                            <label htmlFor="name">Full Name</label>
                            <input
                                type="text"
                                id="name"
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                required
                                readOnly
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="email">Email</label>
                            <input
                                type="email"
                                id="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="phone">Phone Number</label>
                            <input
                                type="tel"
                                id="phone"
                                name="phone"
                                value={formData.phone_number}
                                onChange={handleChange}
                                readOnly
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="address">Address</label>
                            <input
                                type="text"
                                id="address"
                                name="address"
                                value={formData.address}
                                onChange={handleChange}
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="dob">Date of Birth</label>
                            <input
                                type="text"
                                id="dob"
                                name="dob"
                                value={`${String(formData.dob.day).padStart(2, '0')}/${String(formData.dob.month).padStart(2, '0')}/${formData.dob.year}`}
                                onChange={handleChange}
                                required
                            />
                        </div>


                        <div className="form-group">
                            <label htmlFor="skills">Skills</label>
                            <textarea
                                id="skills"
                                name="skills"
                                value={formData.skills}
                                onChange={handleChange}
                                placeholder="List your skills"
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="linkedin">LinkedIn Profile</label>
                            <input
                                type="url"
                                id="linkedin"
                                name="linkedin"
                                value={formData.linkedin}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="github">GitHub Profile</label>
                            <input
                                type="url"
                                id="github"
                                name="github"
                                value={formData.github}
                                onChange={handleChange}
                            />
                        </div>
                    </div>

                    <div className="form-column">
                        <div className="form-section">
                            <h3>Education Details</h3>
                            {formData.education.map((education, index) => (
                                <div key={index}>
                                    <h4>Education {index + 1}</h4>

                                    <div className="form-group">
                                        <label htmlFor={`qualification-${index}`}>Highest Qualification</label>
                                        <input
                                            type="text"
                                            id={`qualification-${index}`}
                                            name={`education-qualification-${index}`}
                                            data-index={index}
                                            value={education.qualification}
                                            onChange={handleChange}
                                            required
                                        />
                                    </div>

                                    <div className="form-group">
                                        <label htmlFor={`institution-${index}`}>Institution Name</label>
                                        <input
                                            type="text"
                                            id={`institution-${index}`}
                                            name={`education-institution-${index}`}
                                            data-index={index}
                                            value={education.institution}
                                            onChange={handleChange}
                                            required
                                        />
                                    </div>

                                    <div className="form-group">
                                        <label htmlFor={`passingYear-${index}`}>Passing Year</label>
                                        <select
                                            id={`passingYear-${index}`}
                                            name={`education-passingYear-${index}`}
                                            data-index={index}
                                            value={education.passingYear}
                                            onChange={handleChange}
                                            required
                                        >
                                            {yearsRange.map(year => (
                                                <option key={year} value={year}>{year}</option>
                                            ))}
                                        </select>
                                    </div>

                                    <div className="form-group">
                                        <label htmlFor={`marks-${index}`}>Marks/Grade</label>
                                        <input
                                            type="text"
                                            id={`marks-${index}`}
                                            name={`education-marks-${index}`}
                                            data-index={index}
                                            value={education.marks}
                                            onChange={handleChange}
                                            required
                                        />
                                    </div>

                                    <button
                                        type="button"
                                        className="remove-education-btn"
                                        onClick={() => removeEducation(index)}
                                    >
                                        Remove Education
                                    </button>
                                </div>
                            ))}
                            <button
                                type="button"
                                className="add-education-btn"
                                onClick={addEducation}
                            >
                                Add Education
                            </button>
                        </div>

                        <div className="form-section">
                            <h3>Work Experience</h3>
                            {formData.experiences.length > 0 ? formData.experiences.map((experience, index) => (
                                <div key={index}>
                                    <h4>Experience {index + 1}</h4>

                                    <div className="form-group">
                                        <label htmlFor={`company-${index}`}>Company Name</label>
                                        <input
                                            type="text"
                                            id={`company-${index}`}
                                            name={`experience-company-${index}`}
                                            data-index={index}
                                            value={experience.company}
                                            onChange={handleChange}
                                        />
                                    </div>

                                    <div className="form-group">
                                        <label htmlFor={`role-${index}`}>Role</label>
                                        <input
                                            type="text"
                                            id={`role-${index}`}
                                            name={`experience-role-${index}`}
                                            data-index={index}
                                            value={experience.role}
                                            onChange={handleChange}
                                        />
                                    </div>

                                    <div className="experience-range">
                                        <div className="form-group">
                                            <label htmlFor={`fromDate-${index}`}>From Date</label>
                                            <input
                                                type="month"
                                                id={`fromDate-${index}`}
                                                name={`experience-fromDate-${index}`}
                                                data-index={index}
                                                value={experience.fromDate}
                                                onChange={handleChange}
                                            />
                                        </div>

                                        <span className="to">To</span>

                                        <div className="form-group">
                                            <label htmlFor={`toDate-${index}`}>To Date</label>
                                            <input
                                                type="month"
                                                id={`toDate-${index}`}
                                                name={`experience-toDate-${index}`}
                                                data-index={index}
                                                value={experience.toDate}
                                                onChange={handleChange}
                                            />
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <label htmlFor={`skillsUsed-${index}`}>Skills Used</label>
                                        <input
                                            type="text"
                                            id={`skillsUsed-${index}`}
                                            name={`experience-skillsUsed-${index}`}
                                            data-index={index}
                                            value={experience.skillsUsed}
                                            onChange={handleChange}
                                            placeholder="Skills you used in this role"
                                        />
                                    </div>

                                    <button
                                        type="button"
                                        className="remove-experience-btn"
                                        onClick={() => removeExperience(index)}
                                    >
                                        Remove Experience
                                    </button>
                                </div>
                            )) : <p>No experiences added yet.</p>}

                            <button
                                type="button"
                                className="add-experience-btn"
                                onClick={addExperience}
                            >
                                Add Experience
                            </button>
                        </div>

                    </div>
                </div>

                <button type="submit" className="submit-button">Save Profile</button>
            </form>
        </div>
    );
};

export default ProfilePage;
