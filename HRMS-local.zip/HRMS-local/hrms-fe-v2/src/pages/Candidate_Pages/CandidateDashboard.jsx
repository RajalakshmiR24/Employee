import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosInstance';

const CandidateDashboard = () => {
  const navigate = useNavigate();

  const fetchCandidateDetails = async () => {
    try {
      const response = await axiosInstance.post(`/api/hrms/candidate/candy`);
      console.log(response,"res from profile");
      
      if (response.status === 200) {
        console.log(response.data.profile, "ghdgdfgdf");
        
        if (response.data.profile === false) {
          console.log(response.data.profile, "tu6765");
          
          navigate('/hrms/candidate/profile');
          return; 
        }
        
        if (response.data.profile === true) {
          navigate('/hrms/candidate/selectrole');
        }
      }
    } catch (err) {
      console.error('Error fetching candidate data:', err);
    }
  };

  useEffect(() => {
    
    fetchCandidateDetails();
  }, []);

  
  return null;
};

export default CandidateDashboard;
