

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from '../../style/VerificationPage.styles';
import TaskTermsModal from '../../components/Modal/TaskTermsModal'; 

const VerificationPage = () => {
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();


  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
      setMessage('Verification successful!');
    }, 1000);
  }, []);



  const navigateToTaskPage = () => {
    navigate('/hrms/candidate-task');
  };

  const toggleModal = () => {
    setShowModal(!showModal);
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Verification Page</h1>

      {loading ? (
        <p style={styles.loadingText}>Verifying your information...</p>
      ) : (
        <div>
          <p>{message}</p>

          <button onClick={navigateToTaskPage} style={styles.button}>
            Go to Task
          </button>
        </div>
      )}

      <TaskTermsModal
        showModal={showModal}
        toggleModal={toggleModal}
        navigateToTaskPage={navigateToTaskPage}
      />
    </div>
  );
};
export default VerificationPage;