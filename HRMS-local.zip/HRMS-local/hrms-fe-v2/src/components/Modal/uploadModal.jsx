import React from "react";
import {
  modalOverlayStyle,
  modalContentStyle,
} from "../../style/uploadModalStyles";
import theme from "../../style/theme";

const UploadModal = ({ handleFileChange, typeError, handleCloseModal }) => (
  <div style={modalOverlayStyle}>
    <div style={modalContentStyle}>
      <button onClick={handleCloseModal} style={closeButtonStyle}>
        X
      </button>
      <input
        type="file"
        accept=".xlsx,.xlsm,.xlsb,.xls,.xml,.xlt,.xltm,.xltx,.csv"
        onChange={handleFileChange}
        style={{ padding: "10px", marginBottom: "10px", width: "100%" }}
      />
      {typeError && (
        <div style={{ color: "red", marginBottom: "10px" }}>{typeError}</div>
      )}
    </div>
  </div>
);

const closeButtonStyle = {
  backgroundColor: theme.colors.primary,
  color: theme.colors.secondary,
  border: "none",
  padding: "0",
  fontSize: "18px",
  borderRadius: "50%",
  cursor: "pointer",
  position: "absolute",
  // top: "5px",
  right: "430px",
  width: "30px",
  height: "30px",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
};

export default UploadModal;
