import React, { useState } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import { useNavigate } from 'react-router-dom';

const HRModal = ({ isVisible, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone_number: '',
    position: '',
    organization_name: '',
    organization_address: '',
    organization_contact: {
      phone_number: '',
      email: '',
    },
    organization_website: '',
  });

  const [createError, setCreateError] = useState('');
  const [createSuccess, setCreateSuccess] = useState('');
  const [formErrors, setFormErrors] = useState({});
  const navigate = useNavigate();

  // Close modal if not visible
  if (!isVisible) return null;

  // Generic validation for all fields
  const validateForm = () => {
    const errors = {};
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    const phoneRegex = /^[6-9][0-9]{9}$/;
    const nameRegex = /^[A-Za-z\s]+$/;
    const websiteRegex = /^(https?:\/\/)?([\w\d\-_]+\.)+[a-z]{2,6}(\/[\w\d\-_.]*)*\/?$/;

    const validationRules = {
      phone_number: {
        regex: phoneRegex,
        errorMessage: 'Phone number must start with 6, 7, 8, or 9 and contain only digits.',
        minLength: 10,
        maxLength: 15
      },
      email: {
        regex: emailRegex,
        errorMessage: 'Please enter a valid professional email address.'
      },
      name: {
        regex: nameRegex,
        errorMessage: 'Name must be at least 3 characters and contain only letters and spaces.',
        minLength: 3
      },
      position: {
        minLength: 2,
        errorMessage: 'Position is required and should be at least 2 characters.'
      },
      organization_name: {
        minLength: 3,
        errorMessage: 'Organization name is required and should be at least 3 characters.'
      },
      organization_address: {
        minLength: 5,
        errorMessage: 'Organization address is required and should be at least 5 characters.'
      },
      organization_contact: {
        phone_number: {
          regex: phoneRegex,
          errorMessage: 'Organization contact number must start with 6, 7, 8, or 9 and contain only digits.'
        },
        email: {
          regex: emailRegex,
          errorMessage: 'Please enter a valid email address for the organization.'
        }
      },
      organization_website: {
        regex: websiteRegex,
        errorMessage: 'Please enter a valid organization website.'
      }
    };

    // Loop through formData to validate each field
    Object.keys(formData).forEach((field) => {
      if (field === 'organization_contact') {
        // Special handling for nested object
        Object.keys(formData[field]).forEach((subField) => {
          const value = formData[field][subField];
          const rules = validationRules[field]?.[subField];

          if (rules?.regex && !rules.regex.test(value)) {
            errors[`${field}.${subField}`] = rules.errorMessage;
          } else if (rules?.minLength && value.length < rules.minLength) {
            errors[`${field}.${subField}`] = rules.errorMessage;
          } else if (rules?.maxLength && value.length > rules.maxLength) {
            errors[`${field}.${subField}`] = `${subField} cannot exceed ${rules.maxLength} characters.`;
          }
        });
      } else {
        const value = formData[field];
        const rules = validationRules[field];

        if (rules?.regex && !rules.regex.test(value)) {
          errors[field] = rules.errorMessage;
        } else if (rules?.minLength && value.length < rules.minLength) {
          errors[field] = rules.errorMessage;
        } else if (rules?.maxLength && value.length > rules.maxLength) {
          errors[field] = `${field} cannot exceed ${rules.maxLength} characters.`;
        }
      }
    });

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const nameParts = name.split('.');

    if (nameParts.length > 1) {
      // Handle nested objects (e.g., organization_contact.phone_number)
      setFormData((prevState) => ({
        ...prevState,
        [nameParts[0]]: {
          ...prevState[nameParts[0]],
          [nameParts[1]]: value,
        },
      }));
    } else {
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    }
  };

  // Handle form submission
  const handleCreateHR = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    const newHRData = { ...formData };

    try {
      const response = await axiosInstance.post('/api/hrms/hr/create-hr', newHRData);

      if (response.data.code === 400) {
        setCreateError(response.data.message);
        setCreateSuccess('');
      } else if (response.status === 201) {
        setCreateSuccess('HR details created successfully!');
        setCreateError('');
        setFormData({
          name: '',
          email: '',
          phone_number: '',
          position: '',
          organization_name: '',
          organization_address: '',
          organization_contact: {
            phone_number: '',
            email: '',
          },
          organization_website: '',
        });

        // Close the modal and navigate to the HR list after successful creation
        onClose();
        navigate('/hrms/hr');
      }
    } catch (err) {
      setCreateError('Error occurred while creating HR. Please try again later.');
      setCreateSuccess('');
    }
  };

  // Modal styles
  const styles = {
    modalOverlay: {
      position: 'fixed',
      top: '0',
      left: '0',
      right: '0',
      bottom: '0',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: '1000',
    },
    modalContent: {
      backgroundColor: '#fff',
      padding: '20px',
      borderRadius: '8px',
      width: '400px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
    },
    formGroup: {
      marginBottom: '15px',
    },
    input: {
      width: '100%',
      padding: '8px',
      marginBottom: '10px',
      borderRadius: '5px',
      border: '1px solid #ccc',
    },
    submitButton: {
      backgroundColor: 'green',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: '5px',
      width: '100%',
    },
    closeButton: {
      backgroundColor: 'gray',
      color: 'white',
      padding: '8px 16px',
      border: 'none',
      borderRadius: '5px',
      width: '100%',
      marginTop: '10px',
      cursor: 'pointer',
    },
    buttonContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: '10px',
      marginTop: '15px',
    },
    successMessage: {
      color: 'green',
    },
    errorMessage: {
      color: 'red',
    },
    errorText: {
      color: 'red',
      fontSize: '12px',
      marginTop: '5px',
    },
  };

  return (
    <div style={styles.modalOverlay}>
      <div style={styles.modalContent}>
        <h3>Create HR Details</h3>
        {createSuccess && <p style={styles.successMessage}>{createSuccess}</p>}
        {createError && <p style={styles.errorMessage}>{createError}</p>}
        <form onSubmit={handleCreateHR}>
          {[ 
            { label: 'Name', name: 'name', type: 'text', minLength: 3, maxLength: 100 },
            { label: 'Email', name: 'email', type: 'email', minLength: 6, maxLength: 255 },
            { label: 'Phone Number', name: 'phone_number', type: 'text', minLength: 10, maxLength: 10 },
            { label: 'Position', name: 'position', type: 'text', minLength: 2, maxLength: 50 },
            { label: 'Organization Name', name: 'organization_name', type: 'text', minLength: 3, maxLength: 255 },
            { label: 'Organization Address', name: 'organization_address', type: 'text', minLength: 5, maxLength: 500 },
            { label: 'Organization Contact Phone', name: 'organization_contact.phone_number', type: 'text', minLength: 10, maxLength: 10 },
            { label: 'Organization Contact Email', name: 'organization_contact.email', type: 'email', minLength: 6, maxLength: 255 },
            { label: 'Organization Website', name: 'organization_website', type: 'text' },
          ].map(({ label, name, type, minLength, maxLength }) => (
            <div style={styles.formGroup} key={name}>
              <input
                type={type}
                name={name}
                value={name.includes('organization_contact') ? formData.organization_contact[name.split('.')[1]] : formData[name]}
                onChange={handleInputChange}
                placeholder={`Enter ${label}`}
                required
                style={styles.input}
                minLength={minLength}
                maxLength={maxLength}
              />
              {formErrors[name] && <p style={styles.errorText}>{formErrors[name]}</p>}
            </div>
          ))}
          <div style={styles.buttonContainer}>
            <button type="submit" style={styles.submitButton}>Create HR</button>
            <button onClick={onClose} style={styles.closeButton}>Close</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default HRModal;
