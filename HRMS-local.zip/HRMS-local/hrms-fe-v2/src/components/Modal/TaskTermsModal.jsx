

import React, { useRef, useEffect } from 'react';
import styles from '../../style/VerificationPage.styles'; 

const TaskTermsModal = ({ showModal, toggleModal, navigateToTaskPage }) => {
  const modalRef = useRef(null);

  
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        toggleModal();
      }
    };

    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [toggleModal]);

  return (
    showModal && (
      <div style={styles.modalOverlay}>
        <div ref={modalRef} style={styles.modalContent}>
          <h3>Terms and Conditions</h3>
          <p>By proceeding, you agree to the following terms and conditions:</p>
          <ul style={styles.termsList}>
            <li style={styles.termsListItem}>You will complete all assigned tasks on time.</li>
            <li style={styles.termsListItem}>You will respect confidentiality and privacy.</li>
            <li style={styles.termsListItem}>Any violation of the rules will result in termination.</li>
          </ul>

          <div style={styles.modalButtons}>
            <button onClick={navigateToTaskPage} style={styles.button}>
              Proceed to Task Page
            </button>
          </div>
        </div>
      </div>
    )
  );
};

export default TaskTermsModal;
