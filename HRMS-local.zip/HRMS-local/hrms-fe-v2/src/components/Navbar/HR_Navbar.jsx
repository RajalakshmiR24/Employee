import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axiosInstance from '../../utils/axiosInstance';
import theme from '../../style/theme';
import HRModal from '../Modal/HRModal';  // Import the modal component

const HrNavbar = () => {
  const [userName, setUserName] = useState('');
  const [userRole, setUserRole] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);  // State for modal visibility

  const navigate = useNavigate();

  const fetchUserName = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axiosInstance.post('/api/hrms/hr/name');

      if (response.data.code === 200) {
        setUserName(response.data.name);
        setUserRole(response.data.position || '');
      } else {
        setError(`Failed to fetch name, please try again. ${response.data.name}`);
      }
    } catch (err) {
      console.error('Error during API call:', err);
      setError('An error occurred. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserName();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('hrmstoken');
    const apiUrl = process.env.REACT_APP_HRMS_SERVER || window.location.origin;
    window.location.href = `${apiUrl}/api/hrms/auth/logout`;
    setTimeout(() => {
      localStorage.removeItem('hrmstoken');
      navigate('/hrms');
    }, 1000);
  };

  const toggleDropdown = () => {
    setDropdownVisible((prevState) => !prevState);
  };

  return (
    <nav style={theme.nav.container}>
      <ul style={{ ...theme.nav.navLinks, display: 'flex', gap: '20px', alignItems: 'center', width: '100%' }}>
        <li style={theme.nav.navItem}>
          <Link to="/hrms/hr" style={theme.nav.navLink}>
            HR_logo
          </Link>
        </li>
        <li style={theme.nav.navItem}>
          <Link to="/hrms/hr/candidate-list" style={theme.nav.navLink}>
            Candidate List
          </Link>
        </li>
        <li style={theme.nav.navItem}>
          <Link to="/hrms/hr/job-list" style={theme.nav.navLink}>
            Job List
          </Link>
        </li>
        {userRole === 'ZustPe_HR' && (
          <li style={theme.nav.navItem}>
            <Link to="/hrms/hr/hr-list" style={theme.nav.navLink}>
              HR List
            </Link>
          </li>
        )}
      </ul>
      <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
        <span
          onClick={toggleDropdown}
          style={{
            fontSize: '18px',
            fontWeight: '600',
            color: '#ffffff',
            cursor: 'pointer',
            textTransform: 'capitalize',
          }}
        >
          {loading ? 'Loading...' : error ? error : `${userName} (${userRole})`}
        </span>

        {dropdownVisible && (
          <div
            style={{
              position: 'absolute',
              top: '60px',
              right: '15px',
              backgroundColor: '#fff',
              padding: '10px 15px',
              borderRadius: '8px',
              boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
              minWidth: '150px',
              zIndex: 10,
            }}
          >
            {/* Only show "Add HR" button if the role is "ZustPe_HR" */}
            {userRole === 'ZustPe_HR' && (
              <button
                onClick={() => setIsModalVisible(true)}  // Open the modal
                style={{
                  color: '#333',
                  backgroundColor: '#f2f2f2',
                  border: '1px solid #ddd',
                  borderRadius: '5px',
                  padding: '10px 15px',
                  width: '100%',
                  cursor: 'pointer',
                  marginBottom: '8px',
                  fontWeight: '500',
                  transition: 'background-color 0.3s ease',
                }}
                onMouseEnter={(e) => (e.target.style.backgroundColor = '#ddd')}
                onMouseLeave={(e) => (e.target.style.backgroundColor = '#f2f2f2')}
              >
                Add HR
              </button>
            )}

            <button
              onClick={handleLogout}
              style={{
                color: '#fff',
                backgroundColor: '#d9534f',
                border: 'none',
                borderRadius: '5px',
                padding: '10px 15px',
                width: '100%',
                cursor: 'pointer',
                fontWeight: '500',
                transition: 'background-color 0.3s ease',
              }}
              onMouseEnter={(e) => (e.target.style.backgroundColor = '#c9302c')}
              onMouseLeave={(e) => (e.target.style.backgroundColor = '#d9534f')}
            >
              Logout
            </button>
          </div>
        )}

      </div>

      {/* Pass down the isModalVisible and onClose prop to HRModal */}
      <HRModal isVisible={isModalVisible} onClose={() => setIsModalVisible(false)} />
    </nav>
  );
};

export default HrNavbar;
