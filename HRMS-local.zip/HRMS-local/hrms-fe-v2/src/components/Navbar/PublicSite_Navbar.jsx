import React from 'react';
import { Link } from 'react-router-dom';
import logo from '../../assets/zustpe_Logo.jpg'

const PublicSite_Navbar = () => {
    // Inline styles for the navbar
    const navbarStyle = {
        backgroundColor: '#2c3e50',
        padding: '15px 30px',
        boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
    };

    const containerStyle = {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        maxWidth: '1200px',
        margin: '0 auto',
        flexWrap: 'wrap',
    };

    const logoStyle = {
        display: 'flex',
        alignItems: 'center',
    };

    const logoImgStyle = {
        height: '40px',
        marginRight: '10px',
    };

    const brandStyle = {
        color: '#fff',
        fontSize: '24px',
        fontWeight: 'bold',
        textDecoration: 'none',
    };

    const linkContainerStyle = {
        display: 'flex',
        gap: '20px',
    };

    const linkStyle = {
        color: '#ecf0f1',
        fontSize: '16px',
        textDecoration: 'none',
        transition: 'color 0.3s',
    };

    return (
        <nav style={navbarStyle}>
            <div style={containerStyle}>
                {/* Logo Section */}
                <div style={logoStyle}>
                    <Link to="/hrms/careers" style={{ ...brandStyle, display: 'flex', alignItems: 'center' }}>
                        <img src={logo} alt="Logo" style={logoImgStyle} />
                    </Link>
                </div>

                {/* Navigation Links */}
                <div style={linkContainerStyle}>
                    <Link to="/hrms/careers" style={linkStyle}>Home</Link>
                </div>


            </div>
        </nav>
    );
};

export default PublicSite_Navbar;
