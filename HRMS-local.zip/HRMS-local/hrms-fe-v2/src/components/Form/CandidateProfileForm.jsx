import React, { useState, useEffect } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import { useNavigate } from 'react-router-dom';

const CandidateProfileForm = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: '',
        address: '',
        dob: '',
        skills: '',
        linkedin: '',
        github: '',
        education: [{ qualification: '', institution: '', passingYear: '', marks: '' }],
        experiences: [{ company: '', role: '', fromDate: '', toDate: '', skillsUsed: '' }]
    });

    useEffect(() => {
        const fetchCandidateData = async () => {
            try {
                const response = await axiosInstance.post('/api/hrms/candidate/profile');
                if (response.data) {
                    setFormData({
                        ...response.data,
                        education: response.data.education || [{ qualification: '', institution: '', passingYear: '', marks: '' }],
                        experiences: response.data.experiences || [{ company: '', role: '', fromDate: '', toDate: '', skillsUsed: '' }]
                    });
                }
            } catch (error) {
                console.error('Error fetching candidate data:', error);
            }
        };
        fetchCandidateData();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;

        if (name === "dob" && value) {
            
            const [year, month, day] = value.split("-"); 
            const formattedDate = `${day}/${month}/${year}`; 
            setFormData((prevData) => ({
                ...prevData,
                [name]: formattedDate,
            }));
        } else {
            setFormData((prevData) => ({
                ...prevData,
                [name]: value,
            }));
        }
    };
    const formatDateForInput = (date) => {
        if (!date) return ''; 
        const [day, month, year] = date.split('/');
        return `${year}-${month}-${day}`; 
      };

    const handleAddEducation = () => {
        setFormData((prevData) => ({
            ...prevData,
            education: [...prevData.education, { qualification: '', institution: '', passingYear: '', marks: '' }],
        }));
    };

    const handleRemoveEducation = (index) => {
        const updatedEducation = [...formData.education];
        updatedEducation.splice(index, 1);
        setFormData((prevData) => ({
            ...prevData,
            education: updatedEducation,
        }));
    };

    const handleAddExperience = () => {
        setFormData((prevData) => ({
            ...prevData,
            experiences: [...prevData.experiences, { company: '', role: '', fromDate: '', toDate: '', skillsUsed: '' }],
        }));
    };

    const handleRemoveExperience = (index) => {
        const updatedExperiences = [...formData.experiences];
        updatedExperiences.splice(index, 1);
        setFormData((prevData) => ({
            ...prevData,
            experiences: updatedExperiences,
        }));
    };

    const handleSaveClick = async () => {
        try {
            const response = await axiosInstance.post('/api/hrms/candidate/update-profile', formData);
            alert(response.data.message);
            navigate('/hrms/candidate/profile');
        } catch (error) {
            console.error('Error updating candidate:', error);
        }
    };

    return (
        <div className="form-container">
            <h2>Edit Candidate Profile</h2>
            <form>
                <div className="form-content">
                    <div className="form-column">
                        <div className="form-group">
                            <label>Email</label>
                            <input
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div className="form-group">
                            <label>Address</label>
                            <input
                                type="text"
                                name="address"
                                value={formData.address}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div className="form-group">
                            <label>Date of Birth</label>
                            <input
                                type="date"
                                name="dob"
                                value={formatDateForInput(formData.dob)} 
                                onChange={handleInputChange}
                            />
                        </div>
                        <div className="form-group">
                            <label>Skills</label>
                            <input
                                type="text"
                                name="skills"
                                value={formData.skills}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div className="form-group">
                            <label>LinkedIn Profile</label>
                            <input
                                type="text"
                                name="linkedin"
                                value={formData.linkedin}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div className="form-group">
                            <label>GitHub Profile</label>
                            <input
                                type="text"
                                name="github"
                                value={formData.github}
                                onChange={handleInputChange}
                            />
                        </div>
                    </div>

                    <div className="form-column">
                        <div className="form-section">
                            <h3>Education</h3>
                            {formData.education?.map((edu, index) => (
                                <div key={index} className="form-group">
                                    <label>Qualification</label>
                                    <input
                                        type="text"
                                        name="qualification"
                                        value={edu.qualification}
                                        onChange={(e) => {
                                            const updatedEducation = [...formData.education];
                                            updatedEducation[index].qualification = e.target.value;
                                            setFormData({ ...formData, education: updatedEducation });
                                        }}
                                    />
                                    <label>Institution</label>
                                    <input
                                        type="text"
                                        name="institution"
                                        value={edu.institution}
                                        onChange={(e) => {
                                            const updatedEducation = [...formData.education];
                                            updatedEducation[index].institution = e.target.value;
                                            setFormData({ ...formData, education: updatedEducation });
                                        }}
                                    />
                                    <label>Passing Year</label>
                                    <input
                                        type="text"
                                        name="passingYear"
                                        value={edu.passingYear}
                                        onChange={(e) => {
                                            const updatedEducation = [...formData.education];
                                            updatedEducation[index].passingYear = e.target.value;
                                            setFormData({ ...formData, education: updatedEducation });
                                        }}
                                    />
                                    <label>Marks</label>
                                    <input
                                        type="text"
                                        name="marks"
                                        value={edu.marks}
                                        onChange={(e) => {
                                            const updatedEducation = [...formData.education];
                                            updatedEducation[index].marks = e.target.value;
                                            setFormData({ ...formData, education: updatedEducation });
                                        }}
                                    />
                                    <button type="button" onClick={() => handleRemoveEducation(index)}>Remove Education</button>
                                </div>
                            ))}
                            <button type="button" onClick={handleAddEducation}>Add Education</button>
                        </div>

                        <div className="form-section">
                            <h3>Work Experience</h3>
                            {formData.experiences?.map((exp, index) => (
                                <div key={index} className="form-group">
                                    <label>Company</label>
                                    <input
                                        type="text"
                                        name="company"
                                        value={exp.company}
                                        onChange={(e) => {
                                            const updatedExperiences = [...formData.experiences];
                                            updatedExperiences[index].company = e.target.value;
                                            setFormData({ ...formData, experiences: updatedExperiences });
                                        }}
                                    />
                                    <label>Role</label>
                                    <input
                                        type="text"
                                        name="role"
                                        value={exp.role}
                                        onChange={(e) => {
                                            const updatedExperiences = [...formData.experiences];
                                            updatedExperiences[index].role = e.target.value;
                                            setFormData({ ...formData, experiences: updatedExperiences });
                                        }}
                                    />
                                    <label>From Date</label>
                                    <input
                                        type="date"  
                                        name="fromDate"
                                        value={exp.fromDate}
                                        onChange={(e) => {
                                            const updatedExperiences = [...formData.experiences];
                                            updatedExperiences[index].fromDate = e.target.value;
                                            setFormData({ ...formData, experiences: updatedExperiences });
                                        }}
                                    />
                                    <label>To Date</label>
                                    <input
                                        type="date"  
                                        name="toDate"
                                        value={exp.toDate}
                                        onChange={(e) => {
                                            const updatedExperiences = [...formData.experiences];
                                            updatedExperiences[index].toDate = e.target.value;
                                            setFormData({ ...formData, experiences: updatedExperiences });
                                        }}
                                    />
                                    <label>Skills Used</label>
                                    <input
                                        type="text"
                                        name="skillsUsed"
                                        value={exp.skillsUsed}
                                        onChange={(e) => {
                                            const updatedExperiences = [...formData.experiences];
                                            updatedExperiences[index].skillsUsed = e.target.value;
                                            setFormData({ ...formData, experiences: updatedExperiences });
                                        }}
                                    />
                                    <button type="button" onClick={() => handleRemoveExperience(index)}>Remove Experience</button>
                                </div>
                            ))}
                            <button type="button" onClick={handleAddExperience}>Add Experience</button>
                        </div>
                    </div>
                </div>

                <div className="form-group">
                    <button type="button" className="submit-button" onClick={handleSaveClick}>
                        Save
                    </button>
                </div>
            </form>
        </div>
    );
};

export default CandidateProfileForm;
