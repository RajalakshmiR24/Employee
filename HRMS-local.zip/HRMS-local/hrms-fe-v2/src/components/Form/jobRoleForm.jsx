import React, { useState, useEffect } from 'react';
import './jobRoleForm.css';
import axiosInstance from '../../utils/axiosInstance';
import { validateForm } from '../../utils/validation';

const FormComponent = () => {
  const [formData, setFormData] = useState({
    postingTitle: '',
    title: '',
    departmentName: '',
    hiringManager: '',
    numOfPositions: '',
    targetDate: '',
    dateOpened: '',
    jobOpeningStatus: '',
    jobType: '',
    industry: '',
    workExp: '0-2 years',
    salary: '',
    requiredSkills: [],
    address: {
      city: '',
      state: '',
      country: '',
      zip: '',
    },
    notes: {
      jobDescription: '',
      requirements: '',
      benefits: '',
    },
  });

  const [enums, setEnums] = useState({
    jobOpeningStatus: [],
    jobType: [],
    workExp: [],
    industry: [],
    departmentName: [],
    hiringManagers: [],
  });

  const [errors, setErrors] = useState({});
  const [skillInput, setSkillInput] = useState('');

  useEffect(() => {
    const fetchEnums = async () => {
      try {
        const response = await axiosInstance.post('/api/hrms/hr/all-jobdetails');
        if (response.data.success) {
          setEnums(response.data.data);
        }
      } catch (error) {
        console.error('Error fetching enums:', error);
      }
    };

    fetchEnums();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === 'hiringManager') {
      const selectedManager = enums.hiringManagers.find(manager => manager.hr_id === value);
      setFormData({
        ...formData,
        hiringManager: {
          hr_id: selectedManager.hr_id,
          name: selectedManager.name
        }
      });
    } else if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData({
        ...formData,
        [parent]: {
          ...formData[parent],
          [child]: value,
        },
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };


  const handleSkillInputChange = (e) => {
    setSkillInput(e.target.value);
  };

  const handleAddSkill = () => {
    const skill = skillInput.trim();
    if (skill && !formData.requiredSkills.includes(skill)) {
      setFormData({
        ...formData,
        requiredSkills: [...formData.requiredSkills, skill],
      });
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove) => {
    setFormData({
      ...formData,
      requiredSkills: formData.requiredSkills.filter(skill => skill !== skillToRemove),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const { errors, formIsValid } = validateForm(formData);
  
    if (formIsValid) {
      try {
        const response = await axiosInstance.post('/api/hrms/hr/create-jobrole', formData);
  
        if (response.data.code && response.data.code === 400) {
          
          alert(response.data.error);
        } else if (response.data.success && response.status === 201) {
          
          alert(response.data.message);
          
          
          setFormData({
            postingTitle: '',
            title: '',
            departmentName: '',
            hiringManager: '',
            numOfPositions: '',
            targetDate: '',
            dateOpened: '',
            jobOpeningStatus: '',
            jobType: '',
            industry: '',
            workExp: '0-2 years',
            salary: '',
            requiredSkills: [],
            address: {
              city: '',
              state: '',
              country: '',
              zip: '',
            },
            notes: {
              jobDescription: '',
              requirements: '',
              benefits: '',
            },
          });
        } else {
          
          alert('Job role created, but not with a successful status code.');
        }
      } catch (error) {
        console.error('Error submitting form:', error);
        setErrors({ global: 'There was an issue submitting the form. Please try again.' });
        alert('There was an issue submitting the form. Please try again.');
      }
    } else {
      setErrors(errors);
      console.log('Form has errors:', errors);
      alert('Please fix the form errors and try again.');
    }
  };
  

  return (
    <div>
      <h2>Create Job Role</h2>
      <form onSubmit={handleSubmit} className="job-form">
        <div className="form-content">
          {/* Left Column (Basic Job Details) */}
          <div className="form-column">
            <h3>Job Details</h3>
            <div className="form-group">
              <label>Posting Title</label>
              <input
                type="text"
                name="postingTitle"
                value={formData.postingTitle}
                onChange={handleChange}
                placeholder="e.g. Senior Software Engineer"
              />
              {errors.postingTitle && <span className="error">{errors.postingTitle}</span>}
            </div>
            <div className="form-group">
              <label>Job Title</label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleChange}
                placeholder="e.g. Developer"
              />
              {errors.title && <span className="error">{errors.title}</span>}
            </div>
            <div className="form-group">
              <label>Department</label>
              <select
                name="departmentName"
                value={formData.departmentName}
                onChange={handleChange}
              >
                <option value="">Select Department</option>
                {enums.departmentName.map((department) => (
                  <option key={department} value={department}>
                    {department}
                  </option>
                ))}
              </select>
              {errors.departmentName && <span className="error">{errors.departmentName}</span>}
            </div>

            <div className="form-group">
              <label>Hiring Manager</label>
              <select
                name="hiringManager"
                value={formData.hiringManager?.hr_id || ''}
                onChange={handleChange}
              >
                <option value="">Select Hiring Manager</option>
                {enums.hiringManagers.map((manager) => (
                  <option key={manager.hr_id} value={manager.hr_id}>
                    {manager.name}
                  </option>
                ))}
              </select>
              {errors.hiringManager && <span className="error">{errors.hiringManager}</span>}
            </div>


            <div className="form-group">
              <label>Date Opened</label>
              <input
                type="date"
                name="dateOpened"
                value={formData.dateOpened}
                onChange={handleChange}
                required
              />
              {errors.dateOpened && <span className="error">{errors.dateOpened}</span>}
            </div>

            <div className="form-group">
              <label>Number of Positions</label>
              <input
                type="number"
                name="numOfPositions"
                value={formData.numOfPositions}
                onChange={handleChange}
                placeholder="e.g. 5"
              />
              {errors.numOfPositions && <span className="error">{errors.numOfPositions}</span>}
            </div>

            <div className="form-section">
              <h3>Location & Address</h3>
              <div className="form-group">
                <label>City</label>
                <input
                  type="text"
                  name="address.city"
                  value={formData.address.city}
                  onChange={handleChange}
                  placeholder="e.g. New York"
                />
                {errors.addressCity && <span className="error">{errors.addressCity}</span>}
              </div>
              <div className="form-group">
                <label>State</label>
                <input
                  type="text"
                  name="address.state"
                  value={formData.address.state}
                  onChange={handleChange}
                  placeholder="e.g. NY"
                />
                {errors.addressState && <span className="error">{errors.addressState}</span>}
              </div>
              <div className="form-group">
                <label>Country</label>
                <input
                  type="text"
                  name="address.country"
                  value={formData.address.country}
                  onChange={handleChange}
                  placeholder="e.g. USA"
                />
                {errors.addressCountry && <span className="error">{errors.addressCountry}</span>}
              </div>
              <div className="form-group">
                <label>Zip Code</label>
                <input
                  type="text"
                  name="address.zip"
                  value={formData.address.zip}
                  onChange={handleChange}
                  placeholder="e.g. 10001"
                />
                {errors.addressZip && <span className="error">{errors.addressZip}</span>}
              </div>
            </div>
          </div>

          {/* Right Column (Additional Information) */}
          <div className="form-column">
            <h3>Job Specifications</h3>
            <div className="form-group">
              <label>Target Date</label>
              <input
                type="date"
                name="targetDate"
                value={formData.targetDate}
                onChange={handleChange}
              />
            </div>
            <div className="form-group">
              <label>Job Opening Status</label>
              <select
                name="jobOpeningStatus"
                value={formData.jobOpeningStatus}
                onChange={handleChange}
              >
                <option value="">Select Status</option>
                {enums.jobOpeningStatus.map((status) => (
                  <option key={status} value={status}>
                    {status}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Job Type</label>
              <select
                name="jobType"
                value={formData.jobType}
                onChange={handleChange}
              >
                <option value="">Select Job Type</option>
                {enums.jobType.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Industry</label>
              <select
                name="industry"
                value={formData.industry}
                onChange={handleChange}
              >
                <option value="">Select Industry</option>
                {enums.industry.map((industry) => (
                  <option key={industry} value={industry}>
                    {industry}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Required Skills</label>
              <div>
                <input
                  type="text"
                  name="requiredSkills"
                  value={skillInput}
                  onChange={handleSkillInputChange}
                  placeholder="Add a skill"
                  maxLength="30"
                />
                <button type="button" onClick={handleAddSkill}>Add Skill</button>
              </div>
              <ul>
                {formData.requiredSkills.length > 0 ? (
                  formData.requiredSkills.map((skill, index) => (
                    <li key={index}>
                      {skill}
                      <button type="button" onClick={() => handleRemoveSkill(skill)}>Remove</button>
                    </li>
                  ))
                ) : (
                  <li>No skills added yet.</li>
                )}
              </ul>
            </div>

            <div className="form-group">
              <label>Experience</label>
              <div className="experience-range">
                {/* Min Experience Dropdown */}
                <select
                  name="minWorkExp"
                  value={formData.minWorkExp}
                  onChange={handleChange}
                >
                  {/* Generating options 0, 1, 2, ... 9 */}
                  {[...Array(10).keys()].map((exp) => (
                    <option key={exp} value={exp}>
                      {exp}
                    </option>
                  ))}
                </select>

                <span className="to">to</span> {/* "to" text between the two select fields */}

                {/* Max Experience Dropdown */}
                <select
                  name="maxWorkExp"
                  value={formData.maxWorkExp}
                  onChange={handleChange}
                >
                  {/* Generating options 0, 1, 2, ... 9 */}
                  {[...Array(10).keys()].map((exp) => (
                    <option key={exp} value={exp}>
                      {exp}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label>Salary</label>
              <input
                type="text"
                name="salary"
                value={formData.salary}
                onChange={handleChange}
                placeholder="e.g. ₹10,000-50000"
                required
              />
            </div>
          </div>
        </div>

        {/* Job Description & Requirements */}
        <div className="form-section">
          <h3>Job Description & Requirements</h3>
          <div className="form-group">
            <label>Job Description</label>
            <textarea
              name="notes.jobDescription"
              value={formData.notes.jobDescription}
              onChange={handleChange}
              placeholder="Describe the role..."
            />
          </div>
          <div className="form-group">
            <label>Job Requirements</label>
            <textarea
              name="notes.requirements"
              value={formData.notes.requirements}
              onChange={handleChange}
              placeholder="Specify required skills/qualifications..."
            />
          </div>
          <div className="form-group">
            <label>Benefits</label>
            <textarea
              name="notes.benefits"
              value={formData.notes.benefits}
              onChange={handleChange}
              placeholder="List benefits..."
            />
          </div>
        </div>

        <div className="form-group">
          <button type="submit" className="submit-button">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default FormComponent;
