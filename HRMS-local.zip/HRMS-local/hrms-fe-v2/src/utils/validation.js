export const validateForm = (formData) => {
    let errors = {};
    let formIsValid = true;
  
    // Required Fields Validation
    if (!formData.postingTitle) {
      errors.postingTitle = 'Posting Title is required.';
      formIsValid = false;
    }
  
    if (!formData.title) {
      errors.title = 'Job Title is required.';
      formIsValid = false;
    }
  
    if (!formData.departmentName) {
      errors.departmentName = 'Department is required.';
      formIsValid = false;
    }
  
    if (!formData.hiringManager) {
      errors.hiringManager = 'Hiring Manager is required.';
      formIsValid = false;
    }
  
    if (!formData.numOfPositions || formData.numOfPositions <= 0) {
      errors.numOfPositions = 'Number of Positions is required and must be greater than 0.';
      formIsValid = false;
    }
  
    if (!formData.dateOpened) {
      errors.dateOpened = 'Date Opened is required.';
      formIsValid = false;
    }
  
    if (!formData.salary) {
      errors.salary = 'Salary is required.';
      formIsValid = false;
    }
  
    // Nested Address Validation
    if (!formData.address.city) {
      errors.addressCity = 'City is required.';
      formIsValid = false;
    }
  
    if (!formData.address.state) {
      errors.addressState = 'State is required.';
      formIsValid = false;
    }
  
    if (!formData.address.country) {
      errors.addressCountry = 'Country is required.';
      formIsValid = false;
    }
  
    if (!formData.address.zip) {
      errors.addressZip = 'Zip Code is required.';
      formIsValid = false;
    }
  
    // Job Description & Requirements Validation
    if (!formData.notes.jobDescription) {
      errors.jobDescription = 'Job Description is required.';
      formIsValid = false;
    }
  
    if (!formData.notes.requirements) {
      errors.jobRequirements = 'Job Requirements are required.';
      formIsValid = false;
    }
  
    return { errors, formIsValid };
  };
  