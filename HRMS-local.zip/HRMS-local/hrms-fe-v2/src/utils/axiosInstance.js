import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: process.env.REACT_APP_HRMS_SERVER || window.location.origin,
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
});

axiosInstance.interceptors.request.use(
  (config) => {
    const hrmstoken = localStorage.getItem("hrmstoken");  
    if (hrmstoken) {
      config.headers.Authorization = `Bearer ${hrmstoken}`;  
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response) => {
    
    
    if (response.data.code && [403, 301, 404].includes(response.data.code)) {
      localStorage.removeItem('hrmstoken');
      window.location.href = '/hrms';
      alert('Session expired or permission issue. Please log in again.');
    }
    return response;
  },
  (error) => {
    const originalRequest = error.config;

    
    if (error.response && error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      alert('Session expired. Please log in again.');
      localStorage.removeItem('hrmstoken');  
      window.location.href = '/hrms';   
      return Promise.reject(error);
    }

    if (error.response) {
      const { status, data } = error.response;
      
       if (status === 400 && data.message) {
        alert(`Error: ${data.message}`);
        localStorage.removeItem('hrmstoken');
        window.location.href = '/hrms';
      } else if (status === 500) {
        
        alert('Server error. Please try again later.');
        localStorage.removeItem('hrmstoken');
        window.location.href = '/hrms';
      }
    }

    return Promise.reject(error);  
  }
);

export default axiosInstance;
