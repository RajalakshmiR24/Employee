import { useState } from 'react';
import * as XLSX from 'xlsx';
import moment from 'moment';

const useFileUpload = () => {
  const [excelData, setExcelData] = useState(null);
  const [typeError, setTypeError] = useState(null);

  const handleFileChange = (e) => {
    const fileTypes = [
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv',
    ];

    const selectedFile = e.target.files[0];

    if (selectedFile) {
      if (fileTypes.includes(selectedFile.type)) {
        setTypeError(null);
        let reader = new FileReader();
        reader.readAsArrayBuffer(selectedFile);
        reader.onload = (e) => {
          parseExcelData(e.target.result);
        };
      } else {
        setTypeError('Please select only excel file types');
      }
    }
  };

  const parseExcelData = (fileContent) => {
    try {
      const workbook = XLSX.read(fileContent, { type: 'buffer' });
      const worksheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[worksheetName];
      const data = XLSX.utils.sheet_to_json(worksheet);

      const invalidDates = [];
      data.forEach((record, index) => {
        let walkinDate = record.walkin_date;

        if (!isNaN(walkinDate)) {
          walkinDate = XLSX.SSF.format('DD-MM-YYYY', walkinDate); 
        }

        if (!moment(walkinDate, 'DD-MM-YYYY', true).isValid()) {
          invalidDates.push({
            index: index + 1,
            record,
            error: `Invalid date format for walkin_date: ${walkinDate}. Expected format: DD-MM-YYYY.`,
          });
        } else {
          record.walkin_date = walkinDate;
        }
      });

      if (invalidDates.length > 0) {
        setTypeError(invalidDates.map(item => `${item.error}`).join('\n'));
        return;
      }

      setExcelData(data);
    } catch (error) {
      console.error('Error parsing the file:', error);
      setTypeError('Error parsing the Excel file');
    }
  };

  return { excelData, typeError, handleFileChange };
};

export default useFileUpload;
