import { useState, useEffect, useCallback } from 'react';
import axiosInstance from '../../utils/axiosInstance';

const useCandidates = (searchQuery, timeline) => {
  const [candidates, setCandidates] = useState([]);
  const [candidateStatuses, setCandidateStatuses] = useState([]);
  const [jobStatuses, setJobStatuses] = useState([]);

  const fetchCandidates = useCallback(async () => {
    try {
      const response = await axiosInstance.post('/api/hrms/hr/all-candidates');
      const { code, message, data } = response.data;
      if (code === 200) {
        setCandidates(data);
      } else {
        alert(`Error: ${message}`);
      }
    } catch (error) {
      console.error('Error fetching candidates:', error);
    }
  }, [searchQuery]);

  useEffect(() => {
    fetchCandidates();
  }, [fetchCandidates]);

  const fetchRoleStatuses = useCallback(async () => {
    try {
      const response = await axiosInstance.post('/api/hrms/hr/roles-status');
      const { available_candidate_statuses, available_job_statuses } = response.data;

      if (timeline === 'TODAY') {
        setCandidateStatuses(available_candidate_statuses.filter(status => ['PRESENT', 'ABSENT', 'WAITING', 'RE-SCHEDULED'].includes(status)));
        setJobStatuses(available_job_statuses.filter(status => ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'].includes(status)));
      } else if (timeline === 'UPCOMING') {
        setCandidateStatuses(available_candidate_statuses.filter(status => ['WAITING'].includes(status)));
        setJobStatuses(available_job_statuses.filter(status => ['IN_PROGRESS'].includes(status)));
      } else if (timeline === 'PREVIOUS') {
        setCandidateStatuses(available_candidate_statuses.filter(status => ['PRESENT', 'ABSENT', 'RE-SCHEDULED'].includes(status)));
        setJobStatuses(available_job_statuses.filter(status => ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'].includes(status)));
      }
    } catch (error) {
      console.error('Error fetching roles and statuses:', error);
    }
  }, [timeline]);

  useEffect(() => {
    fetchRoleStatuses();
  }, [fetchRoleStatuses]);

  return { candidates, candidateStatuses, jobStatuses, fetchCandidates };
};

export default useCandidates;
