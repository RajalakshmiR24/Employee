

import React from 'react';
import { Link } from 'react-router-dom';
import theme from '../style/theme';
import notFoundStyles from '../style/styles';

const NotFound = () => {
  return (
    <div style={theme.body}>
      <div style={notFoundStyles.container}>
        <h1 style={notFoundStyles.title}>
          404
        </h1>
        <h2 style={notFoundStyles.subtitle}>
          Oops! Page Not Found
        </h2>
        <p style={notFoundStyles.description}>
          The page you are looking for might have been moved or doesn't exist.
        </p>

        <div style={notFoundStyles.buttonWrapper}>
          <Link
            to="/"
            style={notFoundStyles.button}
          >
            Go to Homepage
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
