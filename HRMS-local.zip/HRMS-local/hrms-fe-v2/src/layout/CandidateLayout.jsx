import React from 'react';
import { Outlet } from 'react-router-dom';
import CandidateNavbar from '../components/Navbar/Candidate_Navbar';

const CandidateLayout = () => {
  return (
    <div>
      <CandidateNavbar />
      <div style={{ padding: '20px' }}>
        <Outlet />
      </div>
    </div>
  );
};

export default CandidateLayout;
