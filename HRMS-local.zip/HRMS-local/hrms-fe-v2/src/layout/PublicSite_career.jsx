import React from 'react';
import { Outlet } from 'react-router-dom';
import PublicSiteNavbar from '../components/Navbar/PublicSite_Navbar';

const PublicSite_career = () => {
  return (
    <div>
      <PublicSiteNavbar />
      <div className="content">
        <Outlet />
      </div>
    </div>
  );
};

export default PublicSite_career;
