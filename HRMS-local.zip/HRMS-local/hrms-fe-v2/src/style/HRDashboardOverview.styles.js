
import theme from './theme';

export const cardStyle = {
  backgroundColor: theme.card.container.backgroundColor,
  padding: theme.card.container.padding,
  borderRadius: theme.card.container.borderRadius,
  boxShadow: theme.card.container.boxShadow,
  marginBottom: '20px',
  flex: '1 1 30%',
  minWidth: '250px',
  maxWidth: '350px',
  textAlign: 'center',
};

export const cardHeaderStyle = {
  fontSize: theme.card.header.fontSize,
  fontWeight: theme.card.header.fontWeight,
  color: theme.card.header.color,
};

export const cardBodyStyle = {
  fontSize: theme.card.body.fontSize,
  color: theme.card.body.color,
  marginTop: '10px',
};

export const selectStyle = {
  marginTop: '10px',
  padding: '5px',
  fontSize: '16px',
};

export const buttonStyle = {
  marginTop: '10px',
  padding: '8px 16px',
  fontSize: '16px',
  cursor: 'pointer',
  backgroundColor: theme.colors.primary,
  color: '#fff',
  border: 'none',
  borderRadius: '5px',
};

export const monthSelectStyle = {
  marginTop: '10px',
  padding: '5px',
  fontSize: '16px',
};

export const containerStyle = {
  padding: '20px',
  maxWidth: '1200px',
  margin: '0 auto',
};

export const headingStyle = {
  fontSize: theme.typography.headingFontSize,
  color: theme.colors.primary,
};

export const flexContainerStyle = {
  display: 'flex',
  justifyContent: 'space-around',
  flexWrap: 'wrap',
};
