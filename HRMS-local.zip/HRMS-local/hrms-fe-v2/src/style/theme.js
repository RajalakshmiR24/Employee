const theme = {
  colors: {
    primary: '#1e275a',
    secondary: '#ffffff',
    border: '#ccc',
    textPrimary: '#333',
    textSecondary: '#777',
  },
  typography: {
    fontFamily: "'Arial', sans-serif",
    fontSize: '16px',
    headingFontSize: '24px',
  },
  table: {
    tableContainer: {
      borderRadius: '8px',
      overflow: 'hidden',
      margin: '12%',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
      backgroundColor: '#fff',
    },
    th: {
      backgroundColor: '#1e275a',
      color: '#fff',
      padding: '12px',
      textAlign: 'left',
      fontSize: '18px',
    },
    td: {
      padding: '12px',
      borderBottom: `1px solid ${'#ccc'}`,
      fontSize: '16px',
      color: '#333',
    },
    trHover: {
      backgroundColor: '#f9f9f9',
    },
    thHover: {
      backgroundColor: '#1e275a',
    },
  },
  select: {
    select: {
      width: '60%',
      padding: '8px 12px',
      fontSize: '12px',
      borderRadius: '4px',
      border: '1px solid #ccc',
      backgroundColor: '#fff',
      color: '#333',
      fontFamily: "'Arial', sans-serif",
      cursor: 'pointer',
      transition: 'border 0.3s, background-color 0.3s',
    },
    selectHover: {
      borderColor: '#1e275a', 
      backgroundColor: '#f1f1f1',
    },
    selectFocus: {
      borderColor: '#1e275a', 
      outline: 'none',
      boxShadow: '0 0 5px rgba(30, 39, 90, 0.5)',
    },
    option: {
      padding: '8px 12px',
      fontSize: '16px',
    },
  },
  card: {
    container: {
      backgroundColor: '#fff',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
      marginBottom: '20px',
      justifyContent: 'center',
      alignItems: 'center',
      margin: '12%',
    },
    header: {
      fontSize: '20px',
      fontWeight: 'bold',
      color: '#1e275a',
    },
    body: {
      fontSize: '16px',
      color: '#333',
      marginTop: '10px',
    },
  },
  form: {
    container: {
      backgroundColor: '#fff',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
      maxWidth: '500px',
      margin: '0 auto',
    },
    input: {
      width: '90%',
      padding: '8px',
      marginBottom: '10px',
      borderRadius: '4px',
      border: '3px solid #ccc',
      fontSize: '16px',
    },
    label: {
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#333',
      marginBottom: '5px',
    },
    submitButton: {
      backgroundColor: '#1e275a',
      color: '#fff',
      padding: '12px 20px',
      fontSize: '16px',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
    },
    submitButtonHover: {
      backgroundColor: '#1e275a',
    },
  },
  nav: {
    container: {
      backgroundColor: '#1e275a',
      padding: '10px 20px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
      position: 'sticky',
      top: 0,
      zIndex: 100,
    },
    logo: {
      color: '#fff',
      fontSize: '24px',
      fontWeight: 'bold',
      textDecoration: 'none',
    },
    navLinks: {
      listStyle: 'none',
      display: 'flex',
      gap: '20px',
    },
    navLink: {
      color: '#fff',
      textDecoration: 'none',
      fontSize: '16px',
      fontWeight: 'bold',
      transition: 'color 0.3s',
    },
    navLinkHover: {
      color: '#ffcc00',
    },
  },
  body: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    width: '100vw',
    margin: 0,
    padding: 0,
    overflow: 'hidden',
  },
  logoutButton: {
    color: 'white',
    backgroundColor: '#e74c3c', 
    border: 'none',
    padding: '8px 16px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    borderRadius: '4px', 
    transition: 'background-color 0.3s ease',
  },
  logoutButtonHover: {
    backgroundColor: '#c0392b', 
  },
  trashIcon: {
    color: 'red',
    fontSize: '20px',
    border: 'none',
    cursor: 'pointer',
  },
};
  

export default theme;
