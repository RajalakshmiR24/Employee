
import theme from './theme'; 

const modalOverlayStyle = {
  position: 'fixed',
  top: 0,
  left: 0,
  width: '100%',
  height: '100%',
  backgroundColor: 'rgba(0, 0, 0, 0.5)',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 1000,
};

const modalContentStyle = {
  backgroundColor: theme.card.container.backgroundColor,
  padding: '20px',
  borderRadius: theme.card.container.borderRadius,
  width: '500px',
  textAlign: 'center',
  boxShadow: theme.card.container.boxShadow,
};

const modalHeaderStyle = {
  fontSize: '20px',
  fontWeight: 'bold',
  color: theme.colors.primary,
  marginBottom: '10px',
};

const closeButtonStyle = {
  backgroundColor: theme.colors.primary,
  color: theme.colors.secondary,
  border: 'none',
  padding: '12px 20px',
  fontSize: '16px',
  borderRadius: '4px',
  cursor: 'pointer',
  transition: 'background-color 0.3s',
  marginTop: '10px',
  width: '100%',
};

export {
  modalOverlayStyle,
  modalContentStyle,
  modalHeaderStyle,
  closeButtonStyle,
};
