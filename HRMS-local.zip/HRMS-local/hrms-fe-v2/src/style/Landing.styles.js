
import theme from './theme';

export const containerStyle = {
  ...theme.body,
};

export const headingStyle = {
  fontSize: '36px',
  color: theme.colors.primary,
};

export const buttonContainerStyle = {
  display: 'flex',
  justifyContent: 'center',
  marginTop: '40px',
};

export const buttonStyle = {
  ...theme.navLink,
  padding: '12px 20px',
  borderRadius: '4px',
  backgroundColor: theme.colors.primary,
  color: '#fff',
  textDecoration: 'none',
};

export const textContainerStyle = {
  textAlign: 'center',
  padding: '20px',
};
