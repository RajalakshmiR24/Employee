

const container = {
    backgroundColor: '#333', 
    padding: '10px 20px',
  };
  
  const navLinks = {
    listStyle: 'none',
    padding: '0',
    margin: '0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  };
  
  const navItem = {
    color: '#fff',
    fontSize: '18px',
    fontWeight: 'bold',
  };
  
  const navLink = {
    color: '#fff',
    textDecoration: 'none',
  };
  
  const navText = {
    fontSize: '18px',
    fontWeight: 'bold',
    color: 'white',
  };
  
  const logoutButton = {
    color: 'white',
    backgroundColor: 'red',
    border: 'none',
    padding: '8px 16px',
    cursor: 'pointer',
    float: 'right',
  };
  
  export default {
    container,
    navLinks,
    navItem,
    navLink,
    navText,
    logoutButton,
  };
  