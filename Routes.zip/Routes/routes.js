import { createBrowserRouter, Navigate } from "react-router-dom";

import Task from "../Pages/MainPage/index";

import NotFound from "../Components/NotFound/NotFound";
import Landing from "../Pages/LandingPage/Landing";
import Projects from "../Pages/Projects/Projects";

import Auth from "../Pages/Auth/Auth";
import Profile from "../Pages/Profile/Profile";
import EntitiesMember from "../Pages/Entities/EntitiesTable/MemberEntity";

import PublicRoute from "./PublicRoute";
import ProtectedRoute from "./ProtectedRoute";
import Dashboard from "../Pages/Dashboard/Dashboard";
import Teams from "../Pages/Teams/Teams";
import Layout from "../Layouts/Layout";
import TaskDetails from "../Pages/TaskDetails/TaskDetails";
import UserTeams from "../Pages/Teams/UserTeams/UserTeams";
import ClientProject from "../Pages/ClientProject/client";

const superAdminRoutes = [
  { index: true, element: <Dashboard /> },
  { path: "dashboard", element: <Dashboard /> },
  { path: "tasks", element: <Task /> },
  { path: "task/:taskName", element: <TaskDetails /> },
  { path: "members", element: <EntitiesMember /> },
  { path: "projects", element: <Projects /> },
  { path: "teams", element: <Teams /> },
  { path: "profile", element: <Profile /> },
];

const adminRoutes = [
  { index: true, element: <Dashboard /> },
  { path: "dashboard", element: <Dashboard /> },
  { path: "tasks", element: <Task /> },
  { path: "task/:taskName", element: <TaskDetails /> },
  { path: "members", element: <EntitiesMember /> },
  { path: "projects", element: <Projects /> },
  { path: "teams", element: <Teams /> },
  { path: "profile", element: <Profile /> },
];

const userRoutes = [
  { index: true, element: <Task /> },
  { path: "tasks", element: <Task /> },
  { path: "task/:taskName", element: <TaskDetails /> },
  { path: "projects", element: <Projects /> },
  { path: "userteams", element: <UserTeams /> },
  { path: "profile", element: <Profile /> },

];

const clientRoutes = [
  { index: true, element: <ClientProject /> },
  { path: "clientprojects", element: <ClientProject /> },
  { path: "task/:taskName", element: <TaskDetails /> },

  { path: "tasks", element: <Task /> },
  { path: "profile", element: <Profile /> },
];

export default createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/ProjectHub" />,
  },
  {
    path: "/ProjectHub",
    element: <Landing />,
  },

  {
    path: "/projecthub/auth/start",
    element: (
      <PublicRoute>
        <Auth />
      </PublicRoute>
    ),
  },
  {
    path: "/ProjectHub/superAdmin",
    element: (
      <ProtectedRoute role="superAdmin">
        <Layout />
      </ProtectedRoute>
    ),
    children: superAdminRoutes,
  },
  {
    path: "/ProjectHub/Admin",
    element: (
      <ProtectedRoute role="Admin">
        <Layout />
      </ProtectedRoute>
    ),
    children: adminRoutes,
  },
  {
    path: "/ProjectHub/User",
    element: (
      <ProtectedRoute role="User">
        <Layout />
      </ProtectedRoute>
    ),
    children: userRoutes,
  },
  {
    path: "/ProjectHub/Client",
    element: (
      <ProtectedRoute role="Client">
        <Layout />
      </ProtectedRoute>
    ),
    children: clientRoutes,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);
