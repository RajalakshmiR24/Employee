import React, { useContext } from "react";
import { Navigate } from "react-router-dom";
import { RoleContext } from "../Context/RoleContext"; 

const PublicRoute = ({ element }) => {
  
  const { role } = useContext(RoleContext);

  
  // const isAuthenticated = !!localStorage.getItem("token");
  const isAuthenticated = !!localStorage.getItem("user-hash");

  if (isAuthenticated) {
    switch (role) {
      case "superAdmin":
        return <Navigate to={`/projecthub/${role} `}/>;
      case "Admin":
        return <Navigate to={`/projecthub/${role} `}/>;
      case "User":
        return <Navigate to={`/projecthub/${role} `}/>;
      case "Client":
        return <Navigate to={`/projecthub/${role} `}/>;
      default:
        return <Navigate to="/projecthub" />;
    }
  }


  return element;
};

export default PublicRoute;
