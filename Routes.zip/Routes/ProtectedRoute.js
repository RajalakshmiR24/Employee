import React from "react";
import { Navigate } from "react-router-dom";


const isAuthenticated = () => {
  const userHash = localStorage.getItem("user-hash");
  // const userHash = localStorage.getItem("token");

  return userHash;  
};


const ProtectedRoute = ({ children }) => {

  if (!isAuthenticated()) {
    localStorage.removeItem('user-hash');
    return <Navigate to="/projecthub" />;
  }
  
  return children;  
};

export default ProtectedRoute;
