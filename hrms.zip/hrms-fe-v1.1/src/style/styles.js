

const notFoundStyles = {
    container: {
      textAlign: 'center',
      padding: '20px',
    },
    title: {
      fontSize: '72px',
      color: '#FF6347',  
      fontWeight: 'bold',
    },
    subtitle: {
      fontSize: '24px',
      color: '#4A4A4A',  
    },
    description: {
      fontSize: '18px',
      color: '#A9A9A9',  
    },
    buttonWrapper: {
      marginTop: '40px',
    },
    button: {
      padding: '12px 20px',
      backgroundColor: '#FF6347',  
      color: '#fff',
      fontSize: '16px',
      textDecoration: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
    },
  };
  
  export default notFoundStyles;
  