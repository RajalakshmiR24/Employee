
import theme from './theme';

const styles = {
  container: {
    padding: '20px',
    textAlign: 'center',
  },
  title: {
    color: theme.colors.primary,
  },
  loadingText: {
    color: theme.colors.secondary,
  },
  statusText: {
    fontSize: '18px',
    color: theme.colors.textPrimary,
  },
  verifiedText: {
    color: theme.colors.success,
  },
  pendingText: {
    color: theme.colors.warning,
  },
  button: {
    padding: '10px 20px',
    backgroundColor: theme.colors.primary,
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '16px',
  },
  logoutButton: {
    color: 'white',
    backgroundColor: 'red',
    border: 'none',
    padding: '8px 16px',
    cursor: 'pointer',
  },
  closeButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    backgroundColor: 'transparent',
    color: '#000',
    border: 'none',
    fontSize: '20px',
    cursor: 'pointer',
    padding: '5px',
  },
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)', 
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 9999, 
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '5px',
    width: '60%',
    maxWidth: '600px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
  },
  modalButtons: {
    marginTop: '20px',
    textAlign: 'center',
  },
  termsList: {
    listStyleType: 'circle', 
    paddingLeft: '20px', 
    marginBottom: '20px',
  },
  termsListItem: {
    fontSize: '16px',
    color: '#333',
    marginBottom: '10px', 
  },
};

export default styles;
