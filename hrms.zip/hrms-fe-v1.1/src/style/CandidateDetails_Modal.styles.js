
const styles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
    },
    modal: {
      backgroundColor: '#fff',
      padding: '20px',
      borderRadius: '8px',
      minWidth: '400px',
      maxWidth: '600px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
      overflowY: 'auto',
    },
    modalHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderBottom: '1px solid #ccc',
      paddingBottom: '10px',
    },
    closeButton: {
      background: 'transparent',
      border: 'none',
      fontSize: '20px',
      cursor: 'pointer',
    },
    modalContent: {
      paddingTop: '10px',
    },
    resumeButton: {
      backgroundColor: '#4CAF50',
      color: 'white',
      border: 'none',
      padding: '10px 20px',
      borderRadius: '4px',
      cursor: 'pointer',
      marginTop: '10px',
    },
    uploadButton: {
      backgroundColor: '#FF9800',
      color: 'white',
      border: 'none',
      padding: '10px 20px',
      borderRadius: '4px',
      cursor: 'pointer',
      marginTop: '10px',
    },
    fileInput: {
      marginTop: '10px',
      padding: '5px',
    },
    errorText: {
      color: 'red',
      fontSize: '12px',
      marginTop: '10px',
    },
  };
  
  export default styles;
  