import React, { useEffect, useRef, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import theme from '../style/theme';
import axiosInstance from '../utils/axiosInstance';

const Auth = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const callRef = useRef(0);

  const urlParams = new URLSearchParams(location.search);
  const code = urlParams.get('code');
  const state = urlParams.get('state');
  const iss = urlParams.get('iss');

  const handleNavigate = useCallback((role) => {
    if (!role) {
      navigate('/hrms');
      return;
    }

    const roleRoutes = {
      hr: '/hrms/hr',
      candidate: '/hrms/candidate'
    };

    navigate(roleRoutes[role] || '/hrms');
  }, [navigate]);

  useEffect(() => {
    if (callRef.current === 1) return;

    callRef.current = 1;

    if (!code || !state || !iss) {
      navigate('/hrms');
      return;
    }

    const formData = new URLSearchParams({ code, state, iss });

    axiosInstance
      .post('/api/hrms/auth/verify', formData, {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        withCredentials: true
      })
      .then((response) => {
        const { hrmstoken, role } = response.data;

        if (hrmstoken) {
          localStorage.setItem('hrmstoken', hrmstoken); 
        }

        handleNavigate(role);
      })
      .catch((error) => {
        console.error('Error during authentication:', error.response.data || error.message || error.error);
      });
  }, [code, state, iss, handleNavigate, navigate]);

  return (
    <div style={theme.body}>
      <div style={{ textAlign: 'center', padding: '20px' }}>
        <div style={{ marginTop: '40px' }}>
          <span onClick={handleNavigate}></span>
        </div>
      </div>
    </div>
  );
};

export default Auth;
