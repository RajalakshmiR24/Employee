import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Task = () => {
  const [hasCamera, setHasCamera] = useState(false); 
  const [cameraStream, setCameraStream] = useState(null); 
  const navigate = useNavigate();

  useEffect(() => {
    window.history.pushState(null, '', window.location.href);

    const handlePopState = () => {
      localStorage.removeItem('hrmstoken');
      const confirmation = window.confirm(
        'Are you sure you want to leave this page? This will remove your session.'
      );
      localStorage.removeItem('hrmstoken');

      if (confirmation) {
        localStorage.removeItem('hrmstoken');
        navigate('/hrms');
      } else {
        window.history.pushState(null, '', window.location.href);
      }
    };

    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [navigate]);

  useEffect(() => {
    const getCamera = async () => {
      try {
        
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        setCameraStream(stream); 
        setHasCamera(true); 
      } catch (error) {
        console.error("Error accessing camera:", error);
        setHasCamera(false); 
      }
    };

    getCamera();

    
    return () => {
      if (cameraStream) {
        const tracks = cameraStream.getTracks();
        tracks.forEach(track => track.stop()); 
      }
    };
  }, [cameraStream]);

  return (
    <div>
      <h2>Task</h2>
      {hasCamera ? (
        <video
          autoPlay
          playsInline
          muted
          ref={videoElement => {
            if (videoElement && cameraStream) {
              videoElement.srcObject = cameraStream; 
            }
          }}
          style={{ width: '100%', height: 'auto', border: '2px solid black' }} 
        />
      ) : (
        <p>Access to the camera is denied or failed.</p>
      )}
    </div>
  );
};

export default Task;
