import React from 'react';
import theme from '../../style/theme';
import { FaPlusCircle } from 'react-icons/fa';

const SearchBar = ({ searchQuery, handleSearchChange, handleOptionClick, handleNewTable, handleOldTable }) => {
  const buttonStyle = {
    ...theme.form.submitButton,
    backgroundColor: theme.colors.primary,
  };

  const handleButtonHover = (e, hover) => e.target.style.backgroundColor = hover
    ? theme.form.submitButtonHover.backgroundColor
    : theme.colors.primary;

  return (
    <div>
      <div>
        {['Old Candidate', 'New Candidate'].map((label, idx) => (
          <button
            key={label}
            onClick={idx === 0 ? handleOldTable : handleNewTable}
            style={buttonStyle}
            onMouseEnter={(e) => handleButtonHover(e, true)}
            onMouseLeave={(e) => handleButtonHover(e, false)}
          >
            {label}
          </button>
        ))}
      </div>
      <br />
      <div>
        <input
          type="text"
          placeholder="Search by Name, Mobile, candidate Status, Job Status, Job Role, Date, Timeline(Today, Upcoming, Previous)"
          value={searchQuery}
          onChange={handleSearchChange}
          style={theme.form.input}
        />
        <button
          onClick={handleOptionClick}
          style={{ ...buttonStyle, float: 'right' }}
          onMouseEnter={(e) => handleButtonHover(e, true)}
          onMouseLeave={(e) => handleButtonHover(e, false)}
        >
          <FaPlusCircle />
        </button>
      </div>
      <br />
    </div>
  );
};

export default SearchBar;
