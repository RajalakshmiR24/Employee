import React, { useEffect, useState } from 'react';
import { useNavigate,Link } from 'react-router-dom';
import axiosInstance from '../../utils/axiosInstance';
import theme from '../../style/theme';

const HrNavbar = () => {
  const [userName, setUserName] = useState('');
  const [userRole, setUserRole] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [dropdownVisible, setDropdownVisible] = useState(false); 
  const navigate = useNavigate();

  const fetchUserName = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axiosInstance.post('/api/hrms/hr/name');

      if (response.data.code === 200) {
        setUserName(response.data.name);
        setUserRole(response.data.role || '');
      } else {
        setError(`Failed to fetch name, please try again. ${response.data.name}`);
      }
    } catch (err) {
      console.error('Error during API call:', err);
      setError('An error occurred. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserName();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('hrmstoken');
    const apiUrl = process.env.REACT_APP_HRMS_SERVER || window.location.origin;
    window.location.href = `${apiUrl}/api/hrms/auth/logout`; 
    setTimeout(() => {
      localStorage.removeItem('hrmstoken');
      navigate('/hrms');
    }, 1000); 
  };

  const toggleDropdown = () => {
    setDropdownVisible((prevState) => !prevState); 
  };

  return (
    <nav style={theme.nav.container}>
      <ul style={{ ...theme.nav.navLinks, display: 'flex', gap: '20px', alignItems: 'center', width: '100%' }}>
        <li style={theme.nav.navItem}>
          <Link to="/hrms/hr" style={theme.nav.navLink}>
            HR_logo
          </Link>
        </li>
        <li style={theme.nav.navItem}>
          <Link to="/hrms/hr/candidate-list" style={theme.nav.navLink}>
            Candidate List
          </Link>
        </li>
      </ul>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <span
          onClick={toggleDropdown}
          style={{ fontSize: '18px', fontWeight: 'bold', color: 'white', cursor: 'pointer' }}
        >
          {loading ? 'Loading...' : error ? error : `${userName} (${userRole})`}
        </span>

        {dropdownVisible && (
          <div style={{ position: 'absolute', top: '50px', right: '10px', backgroundColor: 'white', padding: '10px', borderRadius: '5px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)' }}>
            <button
              onClick={handleLogout}
              style={{ color: 'white', backgroundColor: 'red', border: 'none', padding: '8px 16px', cursor: 'pointer' }}
            >
              Logout
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default HrNavbar;
