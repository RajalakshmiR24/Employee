import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosInstance'; 
import theme from '../../style/theme';

const CandidateNavbar = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true); 
  const [error, setError] = useState(null);
  const [name, setName] = useState(null);
  const [showSubmenu, setShowSubmenu] = useState(false);
  
  const handleNavigate = () => {
    navigate('/hrms/candidate');
  };

  const handleLogout = () => {
    localStorage.removeItem('hrmstoken');
    const apiUrl = process.env.REACT_APP_HRMS_SERVER || window.location.origin;
    window.location.href = `${apiUrl}/api/hrms/auth/logout`; 
    setTimeout(() => {
      localStorage.removeItem('hrmstoken');
      navigate('/hrms');
    }, 1000); 
  };
  
  const toggleSubmenu = () => {
    setShowSubmenu(prevState => !prevState);
  };

  const fetchUserName = async () => {
    setLoading(true);
    setError(null);
  
    try {
      const response = await axiosInstance.post('/api/hrms/candidate/name');
  
      if (response.data.code === 200) {
        setName(response.data.name);
      } else {
        setError(`Failed to fetch name, please try again.,${response.data.name}`);
      }
    } catch (err) {
      console.error('Error during API call:', err);
      setError('An error occurred. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserName(); 
  }, []);  

  return (
    <nav style={theme.nav.container}>
      <ul style={{ ...theme.nav.navLinks, display: 'flex', gap: '20px' }}>
        <li style={theme.nav.navItem}>
          <span
            onClick={handleNavigate}
            style={theme.nav.navLink}
          >
            Candidate_Photo
          </span>
        </li>
      </ul>

      {loading ? (
        <li style={theme.nav.navItem}>
          <span style={theme.nav.navLink}>Loading...</span>
        </li>
      ) : name ? (
        <li style={theme.nav.navItem}>
          <span 
            onClick={toggleSubmenu} 
            style={{ ...theme.nav.navLink, cursor: 'pointer' }}
          >
            Hello, {name}!
          </span>

          {showSubmenu && (
            <ul style={{ position: 'absolute', backgroundColor: '#fff', boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)', padding: '10px', listStyleType: 'none', marginTop: '5px' }}>
              <li>
                <button 
                  onClick={handleLogout} 
                  style={{ color: 'white', backgroundColor: 'red', border: 'none', padding: '8px 16px', cursor: 'pointer' }}
                >
                  Logout
                </button>
              </li>
            </ul>
          )}
        </li>
      ) : (
        
        <li style={theme.nav.navItem}>
          <button 
            onClick={handleLogout} 
            style={{ color: 'white', backgroundColor: 'red', border: 'none', padding: '8px 16px', cursor: 'pointer' }}
          >
            Logout
          </button>
        </li>
      )}

      {error && <div style={{ color: 'red' }}>{error}</div>}
    </nav>
  );
};

export default CandidateNavbar;
