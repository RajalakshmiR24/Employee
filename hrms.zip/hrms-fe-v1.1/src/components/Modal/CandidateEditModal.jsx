import React, { useState, useEffect, useRef } from 'react';

const CandidateEditModal = ({ candidate, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone_number: '',
    job_role: '',
    job_status: '',
    candidate_status: '',
    scheduled_date: '',
    walkin_date: '',
    timeline: '',
  });

  const modalRef = useRef();

  useEffect(() => {
    if (candidate) {
      setFormData({
        name: candidate.name,
        phone_number: candidate.phone_number,
        job_role: candidate.job_role || '',
        job_status: candidate.job_Status || '',
        candidate_status: candidate.candidate_Status || '',
        scheduled_date: candidate.scheduled_date || '',
        walkin_date: candidate.walkin_date || '',
        timeline: candidate.timeline || '',
      });
    }
  }, [candidate]);

  
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose(); 
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onClose]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));

    
    if (name === 'walkin_date') {
      const currentDate = new Date();
      const walkinDate = new Date(value);
      
      
      if (walkinDate > currentDate) {
        setFormData((prevData) => ({
          ...prevData,
          timeline: 'UPCOMING',
        }));
      } else {
        setFormData((prevData) => ({
          ...prevData,
          timeline: prevData.timeline, 
        }));
      }
    }
  };

  const handleSubmit = () => {
    onSubmit(formData); 
    onClose(); 
  };

  return (
    <div style={{ ...modalStyles }}>
      <div ref={modalRef} style={modalContentStyles}>
        <h2>Update Candidate</h2>
        <form>
          <div style={inputWrapperStyles}>
            <input
              type="text"
              name="name"
              value={formData.name}
              readOnly
              placeholder="Name"
              style={inputStyles}
            />
          </div>
          <div style={inputWrapperStyles}>
            <input
              type="text"
              name="phone_number"
              value={formData.phone_number}
              readOnly
              placeholder="Phone Number"
              style={inputStyles}
            />
          </div>
          <div style={inputWrapperStyles}>
            <input
              type="text"
              name="job_role"
              value={formData.job_role}
              onChange={handleChange}
              placeholder="Job Role"
              style={inputStyles}
            />
          </div>
          <div style={inputWrapperStyles}>
            <input
              type="text"
              name="job_status"
              value={formData.job_status}
              onChange={handleChange}
              placeholder="Job Status"
              style={inputStyles}
            />
          </div>
          <div style={inputWrapperStyles}>
            <input
              type="text"
              name="candidate_status"
              value={formData.candidate_status}
              onChange={handleChange}
              placeholder="Candidate Status"
              style={inputStyles}
            />
          </div>
          
          <div style={inputWrapperStyles}>
            <input
              type="date"
              name="walkin_date"
              value={formData.walkin_date}
              onChange={handleChange}
              placeholder="Walkin Date"
              style={inputStyles}
              min={new Date().toISOString().split('T')[0]} 
            />
          </div>
          <div style={inputWrapperStyles}>
            <input
              type="text"
              name="timeline"
              value={formData.timeline}
              readOnly
              placeholder="Timeline"
              style={inputStyles}
            />
          </div>
          <div style={buttonWrapperStyles}>
            <button type="button" onClick={handleSubmit} style={submitButtonStyles}>
              Update
            </button>
            <button type="button" onClick={onClose} style={cancelButtonStyles}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const modalStyles = {
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: 'rgba(0, 0, 0, 0.5)',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 1000,
};

const modalContentStyles = {
  backgroundColor: 'white',
  padding: '20px',
  borderRadius: '8px',
  width: '400px',
};

const inputWrapperStyles = {
  marginBottom: '15px',
};

const inputStyles = {
  width: '100%',
  padding: '8px',
  marginTop: '5px',
  borderRadius: '4px',
  border: '1px solid #ccc',
};

const buttonWrapperStyles = {
  display: 'flex',
  justifyContent: 'space-between',
};

const submitButtonStyles = {
  backgroundColor: '#4CAF50',
  color: 'white',
  padding: '10px 20px',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
};

const cancelButtonStyles = {
  backgroundColor: '#f44336',
  color: 'white',
  padding: '10px 20px',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
};

export default CandidateEditModal;
