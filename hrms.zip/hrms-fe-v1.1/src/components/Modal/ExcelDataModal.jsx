import React, { useState } from 'react';
import {
  modalOverlayStyle,
  modalContentStyle,
  modalHeaderStyle,
  buttonContainerStyle,
  closeButtonStyle,
  submitButtonStyle
} from '../../style/ExcelDataModal.styles';

const ExcelDataModal = ({ excelData, setIsExcelDataModalOpen, handleSubmit }) => {
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null); 
  const [successMessage, setSuccessMessage] = useState(null); 

  const onSubmit = async () => {
    setLoading(true); 
    setErrorMessage(null); 
    setSuccessMessage(null); 

    try {
      await handleSubmit(excelData);
      setSuccessMessage('Data submitted successfully!');
      setIsExcelDataModalOpen(false);  
    } catch (error) {
      console.error('Error submitting data:', error);
      setErrorMessage('Failed to submit the data. Please try again.');
    } finally {
      setLoading(false); 
    }
  };

  return (
    <div style={modalOverlayStyle}>
      <div style={modalContentStyle}>
        <h3 style={modalHeaderStyle}>Excel Data</h3>

        {errorMessage && (
          <div style={{ color: 'red', marginBottom: '10px' }}>{errorMessage}</div>
        )}
        {successMessage && (
          <div style={{ color: 'green', marginBottom: '10px' }}>{successMessage}</div>
        )}

        <div style={{ overflowY: 'auto', maxHeight: '400px' }}>
          {excelData && excelData.length > 0 ? (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  {Object.keys(excelData[0]).map((key) => (
                    <th key={key} style={{ border: '1px solid #ccc', padding: '8px' }}>
                      {key}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {excelData.map((rowData, index) => (
                  <tr key={index}>
                    {Object.keys(rowData).map((key) => (
                      <td key={key} style={{ border: '1px solid #ccc', padding: '8px' }}>
                        {rowData[key]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No data available to display.</p>
          )}
        </div>

        <div style={buttonContainerStyle}>
          <button onClick={() => setIsExcelDataModalOpen(false)} style={closeButtonStyle}>
            Close
          </button>

          <button 
            onClick={onSubmit} 
            style={{
              ...submitButtonStyle, 
              ...(loading ? { backgroundColor: '#ccc', cursor: 'not-allowed' } : {}),
            }} 
            disabled={loading}
          >
            {loading ? 'Submitting...' : 'Submit'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExcelDataModal;
