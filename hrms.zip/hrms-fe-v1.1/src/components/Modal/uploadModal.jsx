import React, { useEffect, useRef } from 'react';
import {
  modalOverlayStyle,
  modalContentStyle,
  modalHeaderStyle,
} from '../../style/uploadModalStyles';

const UploadModal = ({ handleFileChange, typeError, handleCloseModal }) => {
  const modalRef = useRef();

  // Close modal when clicking outside of it
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        handleCloseModal();
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);

    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [handleCloseModal]);

  return (
    <div style={modalOverlayStyle}>
      <div style={modalContentStyle} ref={modalRef}>
        <h3 style={modalHeaderStyle}>Upload Excel File</h3>
        <input
          type="file"
          accept=".xlsx, .xlsm, .xlsb, .xls, .xml, .xlt, .xltm, .xltx, .csv"
          onChange={handleFileChange}
          style={{ padding: '10px', marginBottom: '10px', width: '100%' }}
        />
        {typeError && (
          <div style={{ color: 'red', marginBottom: '10px' }}>
            {typeError}
          </div>
        )}
      </div>
    </div>
  );
};

export default UploadModal;
