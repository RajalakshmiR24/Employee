import React from 'react';
import theme from '../../style/theme';

const CandidateTable = ({ candidates, candidateStatuses, jobStatuses, handleCandidateClick }) => {
  const tableColumnStyle = theme.table.th;
  const tableRowStyle = theme.table.trHover;
  const tableCellStyle = theme.table.td;

  return (
    <div>
      <table style={theme.table.table}>
        <thead>
          <tr>
            {['#', 'Name', 'Mobile Number', 'Scheduled Date', 'Walkin Date', 'Timeline', 'Role', 'Candidate Status', 'Job Status', 'Actions']
              .map((header) => (
                <th key={header} style={tableColumnStyle}>{header}</th>
              ))}
          </tr>
        </thead>
        <tbody>
          {candidates.map((candidate, index) => (
            <tr key={candidate.candidate_id} style={tableRowStyle}>
              <td style={tableCellStyle}>{index + 1}</td>
              <td style={tableCellStyle}>{candidate.name}</td>
              <td style={tableCellStyle}>{candidate.phone_number}</td>
              <td style={tableCellStyle}>{candidate.scheduled_date}</td>
              <td style={tableCellStyle}>{candidate.walkin_date}</td>
              <td style={tableCellStyle}>{candidate.timeline}</td>
              <td style={tableCellStyle}>{candidate.job_role}</td>
              <td style={tableCellStyle}>
                <select
                  value={candidate.candidate_Status}
                  onChange={(e) => handleCandidateStatusChange(candidate.candidate_id, e.target.value)}
                  style={theme.select.select}
                >
                  {candidateStatuses.map((status) => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>
              </td>
              <td style={tableCellStyle}>
                <select
                  value={candidate.job_Status}
                  onChange={(e) => handleJobStatusChange(candidate.candidate_id, e.target.value)}
                  style={theme.select.select}
                >
                  {jobStatuses.map((status) => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>
              </td>
              <td style={tableCellStyle}>
                <button onClick={() => handleCandidateClick(candidate)} style={theme.form.submitButton}>
                  View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CandidateTable;
