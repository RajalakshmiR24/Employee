import React from "react";
import { Navigate } from "react-router-dom";

const PublicRoute = ({ element }) => {
  // const isAuthenticated = !!localStorage.getItem("hrmstoken");
  const isAuthenticated = !!localStorage.getItem("user-hash");

  if (isAuthenticated) {
    return <Navigate to="/hrms" />;
  }

  return element;
};

export default PublicRoute;
