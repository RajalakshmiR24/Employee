const express = require('express');
const candidateRoutes = express.Router();
const candidateController = require('../Controllers/candidateController');
const {verifyToken, checkCandidateEligibility, findRoleByHash} = require('../Middlewares/auth');



// candidateRoutes.use(verifyToken);
candidateRoutes.use(findRoleByHash);

candidateRoutes.use(checkCandidateEligibility);

candidateRoutes.post('/name',candidateController.getCandidateDetailsByHash);
candidateRoutes.post('/upload-resume',candidateController.uploadResume);
candidateRoutes.post('/upload-kyc',candidateController.uploadKYC);
candidateRoutes.post('/get-job-roles', candidateController.getJobRoles);
candidateRoutes.post('/update-job-role',candidateController.updateJobRoles);
candidateRoutes.patch('/cameraPermission',candidateController.updateCameraPermission);
candidateRoutes.post('/get-job-role-questions',candidateController.getJobRoleQuestions);

module.exports = candidateRoutes;
