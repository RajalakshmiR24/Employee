
const express = require('express');
const passport = require('passport');
const authController = require('../Controllers/authController');
const hrController = require('../Controllers/hrController');

const authRouter = express.Router();

authRouter.get('/start',
  authController.login,
  passport.authenticate('oidc', {
    scope: "openid refresh_token",
  }),
  authController.authenticate 
);

authRouter.get('/logout',
  authController.logout,
  passport.authenticate('oidc', {
    scope: "openid refresh_token",
  }),
);

authRouter.post('/verify', 
  passport.authenticate('oidc'), 
  (req, res, next) => {
    next();
  },
  authController.verifySession
);


authRouter.post('/create-hr', hrController.createHRDetails);

module.exports = authRouter;
