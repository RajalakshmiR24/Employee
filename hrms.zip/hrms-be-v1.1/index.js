require('dotenv').config();

const express = require('express');
const fileUpload = require('express-fileupload');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const http = require("http");
const cors = require("cors");
const morgan = require('morgan'); 

const connectDB = require("./Database/db");
const hrmsRouter = require('./Routes/hrmsRoutes');
const app = express();

app.use(morgan('tiny')); 

app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '15mb' }));
app.use(cors({
  origin: process.env.CORS_ORIGIN,  
  credentials: true, 
  allowedHeaders: ["content-Type","user-hash", "Authorization"]
}));
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true
}));
app.use(helmet());
app.use(fileUpload());

app.use('/api/hrms', hrmsRouter);

connectDB()
  .then(() => {
    const httpServer = http.createServer(app);
        
    httpServer.listen(process.env.PORT, () => {
      console.log(`Http Server Running on port ${process.env.PORT}`);
    });
  })
  .catch((err) => {
    console.log(err.message);
  });
