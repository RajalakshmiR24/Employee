
const Candidate = require('../Models/candidate');
const moment = require('moment');
const HR = require('../Models/hr');
const jobRoleQuestions = require('../data/jobRoleQuestions');


exports.getCandidateDetailsByHash = async (req, res) => {
  try {
    const hash = req.hash;


    const user = await Candidate.findOne({ hash });

    if (user) {

      return res.status(200).json({
        code: 200,
        name: user.name,
        role: user.role,
      });
    }


    return res.status(200).json({
      code: 404,
      message: 'Candidate user not found.',
    });

  } catch (err) {
    res.status(200).json({ code: 500, error: err.message });
  }
};


exports.uploadResume = async (req, res) => {
  const { filename, contentType, data } = req.body;

  if (!filename || !contentType || !data) {
    return res.status(200).json({ code: 400, error: 'All fields are required' });
  }

  try {
    const hash = req.hash;
    const candidate = await Candidate.findOne({ hash });

    if (!candidate) {
      return res.status(200).json({ code: 404, error: 'Candidate not found or invalid hash' });
    }

    
    const newFile = {
      filename,
      contentType,
      data,
    };

    
    candidate.files.push(newFile);

    
    candidate.candidate_Status = 'PRESENT';

    
    await candidate.save();

    
    res.status(201).json({
      code: 201,
      message: 'File uploaded successfully and status updated to PRESENT',
      file: newFile,
    });
  } catch (error) {
    res.status(200).json({ code: 500, error:error.message });
  }
};


exports.uploadKYC = async (req, res) => {
  const { filename, contentType, data } = req.body;

  if (!filename || !contentType || !data) {
    return res.status(200).json({ code: 400, error: 'All fields are required' });
  }

  try {
    const hash = req.hash;

    const candidate = await Candidate.findOne({ hash });

    if (!candidate) {
      return res.status(200).json({ code: 404, error: 'Candidate not found or invalid hash' });
    }

    const newFile = new File({
      filename,
      contentType,
      data,
    });
    await newFile.save();
    res.status(201).json({
      code: 201,
      message: 'File uploaded successfully',
      file: newFile,
    });
  } catch (error) {
    res.status(200).json({ code: 500, error: error.message });
  }
};


function updateTimeline(candidate) {
  const currentDate = new Date();
  const candidateDate = candidate.walkin_date;

  if (candidateDate.toDateString() === currentDate.toDateString()) {
    candidate.timeline = 'TODAY';
  } else if (candidateDate > currentDate) {
    candidate.timeline = 'UPCOMING';
  } else {
    candidate.timeline = 'PREVIOUS';
  }
}

exports.getAllCandidates = async (req, res) => {
  try {
    const hash = req.hash;

    if (!hash) {
      return res.status(200).json({
        code: 400,
        message: 'Hash is required.',
      });
    }

    const user = await HR.findOne({ hash });
    if (!user || user.role !== 'hr') {
      return res.status(200).json({
        code: 403,
        message: 'Only HR can view datas',
      });
    }

    let candidates = await Candidate.find().select('-hash -_id -files._id -__v -updatedAt -createdAt');

    
    candidates = candidates.map(candidate => {
      updateTimeline(candidate);
      return candidate;
    });

    res.status(200).json({
      code: 200,
      success: true,
      data: candidates,
    });
  } catch (error) {
    res.status(200).json({
      code: 500,
      success: false,
      message: error.message,
    });
  }
};

exports.updateCandidateStatus = async (req, res) => {
  const hash = req.hash;

  if (!hash) {
    return res.status(200).json({
      code: 400,
      message: 'Hash is required.',
    });
  }

  try {
    const user = await HR.findOne({ hash });
    if (!user || user.role !== 'hr') {
      return res.status(200).json({
        code: 403,
        message: 'Only HR can update candidate status.',
      });
    }

    const { candidate_Status, job_Status, timeline, description, candidate_id, walkin_date } = req.body;

    if (!candidate_Status || !job_Status || !timeline || !candidate_id) {
      return res.status(200).json({
        code: 400,
        message: 'Please provide hash, candidate_Status, job_Status, candidate_id, and timeline.',
      });
    }

    const validStatuses = {
      TODAY: {
        candidate: ['PRESENT', 'ABSENT', 'RE-SCHEDULED', 'WAITING'],
        job: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
      },
      UPCOMING: {
        candidate: ['WAITING', 'RE-SCHEDULED'],
        job: ['IN_PROGRESS'],
      },
      PREVIOUS: {
        candidate: ['PRESENT', 'ABSENT'],
        job: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
      },
    };

    if (!validStatuses[timeline]) {
      return res.status(200).json({
        code: 400,
        message: 'Invalid timeline provided.',
      });
    }

    const { candidate: validCandidateStatuses, job: validJobStatuses } = validStatuses[timeline];

    if (!validCandidateStatuses.includes(candidate_Status)) {
      return res.status(200).json({
        code: 400,
        message: `The candidate status you provided is not valid for the ${timeline} timeline. Please check and try again.`,
      });
    }
    
    if (!validJobStatuses.includes(job_Status)) {
      return res.status(200).json({
        code: 400,
        message: `The job status you provided is not valid for the ${timeline} timeline. Please check and try again.`,
      });
    }
    

    const candidate = await Candidate.findOne({ candidate_id });

    if (!candidate) {
      return res.status(200).json({
        code: 404,
        message: 'No candidate found with the provided candidate ID.',
      });
    }

    if (candidate.candidate_Status === 'ABSENT') {
      return res.status(200).json({
        code: 400,
        message: 'Status cannot be changed when the candidate is ABSENT.',
      });
    }

    let jobStatusDescription = description || 'Status updated.';

    if (job_Status === 'REJECTED') {
      jobStatusDescription = description || 'Candidate has been rejected. No further details provided.';
    } else {
      switch (job_Status) {
        case 'SCHEDULED':
          jobStatusDescription = 'Interview is scheduled.';
          break;
        case 'RE-SCHEDULED':
          jobStatusDescription = 'Interview is re-scheduled.';
          break;
        case 'COMPLETED':
          jobStatusDescription = 'Interview completed.';
          break;
        case 'HIRED':
          jobStatusDescription = 'Candidate has been hired.';
          break;
        case 'SELECTED':
          jobStatusDescription = 'Candidate has been selected for the role.';
          break;
        case 'IN_PROGRESS':
          jobStatusDescription = 'The recruitment process is in progress.';
          break;
      }
    }

    if ((timeline === 'UPCOMING' || timeline === 'TODAY') && candidate_Status === 'RE-SCHEDULED' && job_Status === 'IN_PROGRESS') {
      candidate.invited = true;

      await candidate.save();

      if (!walkin_date) {
        return res.status(200).json({
          code: 400,
          message: 'Please provide a walkin_date when re-scheduling the interview.',
        });
      }

      const currentDate = new Date();
      const selectedDate = new Date(walkin_date);

      if (selectedDate <= currentDate) {
        return res.status(200).json({
          code: 400,
          message: 'The re-scheduled interview date must be in the future and cannot be today or in the past.',
        });
      }

      candidate.scheduled_date = selectedDate;
      candidate.walkin_date = selectedDate;
      candidate.candidate_Status = 'RE-SCHEDULED';
    }

    if (candidate.job_Status === 'REJECTED' && job_Status !== 'REJECTED') {
      return res.status(200).json({
        code: 400,
        message: 'The job status cannot be changed after the candidate is rejected.',
      });
    }

    candidate.job_Status = job_Status;
    candidate.description = jobStatusDescription;

    await candidate.save();

    return res.status(200).json({
      message: 'Candidate status updated successfully.',
    });
  } catch (error) {
    return res.status(200).json({
      code: 500,
      message: error.message,
    });
  }
};


exports.getHRDashboardOverview = async (req, res) => {
  try {
    const hash = req.hash;

    const { timeline, month } = req.body;

    const user = await HR.findOne({ hash });
    if (!user || user.role !== 'hr') {
      return res.status(200).json({
        code: 403,
        message: 'Only HR can access this data.',
      });
    }


    let candidateQuery = {};
    let totalCandidates = 0;


    if (timeline === 'UPCOMING') {
      candidateQuery = { walkin_date: { $gt: newwalkin_date() } };
    } else if (timeline === 'TODAY') {
      candidateQuery = { walkin_date: { $gte: moment().startOf('day').toDate(), $lte: moment().endOf('day').toDate() } };
    } else if (timeline === 'PREVIOUS') {
      candidateQuery = { walkin_date: { $lt: moment().startOf('month').toDate() } };
    }


    totalCandidates = await Candidate.countDocuments(candidateQuery);


    const startOfMonth = moment().startOf('month').toDate();
    const endOfMonth = moment().endOf('month').toDate();
    const hiresThisMonthQuery = {
      job_Status: 'HIRED',
      walkin_date: { $gte: startOfMonth, $lte: endOfMonth },
    };

    const hiresThisMonth = await Candidate.countDocuments(hiresThisMonthQuery);


    let hiresInSelectedMonth = 0;
    let totalCandidatesMonthWise = {};


    if (month) {
      const startOfSelectedMonth = moment(month, 'MM').startOf('month').toDate();
      const endOfSelectedMonth = moment(month, 'MM').endOf('month').toDate();
      hiresInSelectedMonth = await Candidate.countDocuments({
        job_Status: 'HIRED',
        walkin_date: { $gte: startOfSelectedMonth, $lte: endOfSelectedMonth },
      });


      totalCandidatesMonthWise = await Candidate.aggregate([
        {
          $match: {
            walkin_date: { $gte: startOfSelectedMonth, $lte: endOfSelectedMonth },
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
          },
        },
      ]);
    }


    if (!month) {
      totalCandidatesMonthWise = await Candidate.aggregate([
        {
          $match: {
            walkin_date: { $gte: startOfMonth, $lte: endOfMonth },
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
          },
        },
      ]);
    }


    res.status(200).json({
      totalCandidates,
      totalCandidatesMonthWise: totalCandidatesMonthWise.length ? totalCandidatesMonthWise[0].total : 0,
      hiresThisMonth,
      hiresInSelectedMonth,
    });

  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};

exports.updateJobRoles = async (req, res) => {
  try {
    const { job_role } = req.body;

    if (!job_role) {
      return res.status(200).json({ code: 400, message: 'Hash and job role are required' });
    }

    const validJobRoles = [
      'Video Editor',
      'AWS',
      'Software Tester',
      'MERN Stack Developer',
      'Graphic Designer',
      'HR Recruiter',
      'Operations Associate',
      'Compliance Auditor',
      'Accountant',
      'Finance Analyst',
      'Flutter Developer',
      'Marketing Specialist',
      'Pre-Sales Executive',
      'Client Handling Manager',
      'Sales Executive'
    ];

    if (!validJobRoles.includes(job_role)) {
      return res.status(200).json({ code: 400, message: 'Invalid job role' });
    }
    const hash = req.hash;

    const user = await Candidate.findOne({ hash });

    if (!user) {
      return res.status(200).json({ code: 404, message: 'User not found' });
    }

    if (user.job_role === job_role) {
      return res.status(200).json({
        code: 200,
        message: 'Job role is already updated to the same value.',
        available_job_roles: validJobRoles
      });
    }



    user.job_role = job_role;
    await user.save();

    return res.status(200).json({
      message: 'Job role updated successfully',
      user,
      available_job_roles: validJobRoles
    });

  } catch (error) {
    return res.status(200).json({ code: 500, error:error.message });
  }
};



exports.getJobRoles = async (req, res) => {
  try {
    const hash = req.hash;
    const user = await Candidate.findOne({ hash });
    if (!user) {
      return res.status(200).json({ code: 404, message: 'User not found' });
    }
    if (user.role !== 'candidate') {
      return res.status(200).json({ code: 403, message: 'Access denied. User is not a candidate.' });
    }

    const validJobRoles = [
      'Video Editor',
      'AWS',
      'Software Tester',
      'MERN Stack Developer',
      'Graphic Designer',
      'HR Recruiter',
      'Operations Associate',
      'Compliance Auditor',
      'Accountant',
      'Finance Analyst',
      'Flutter Developer',
      'Marketing Specialist',
      'Pre-Sales Executive',
      'Client Handling Manager',
      'Sales Executive'
    ];


    return res.status(200).json({
      available_job_roles: validJobRoles
    });
  } catch (error) {

    return res.status(200).json({ code: 500, error:error.message });
  }
};


exports.updateCameraPermission = async (req, res) => {
  try {
    const hash = req.hash;
    const user = await Candidate.findOne({ hash });
    if (!user) {
      return res.status(200).json({ code: 404, message: 'User not found' });
    }
    const { cameraPermission } = req.body;
    if (typeof cameraPermission !== 'boolean') {
      return res.status(200).json({code:400, error: 'Camera permission must be a boolean' });
    }

    const candidate = await Candidate.findByIdAndUpdate(
      user._id,
      { cameraPermission },
      { new: true, runValidators: true }
    );


    if (!candidate) {
      return res.status(200).json({ code:404, error: 'Candidate not found' });
    }


    res.status(200).json(candidate);
  } catch (error) {
    res.status(200).json({ code:500, error: error.message });
  }
};


exports.getJobRoleQuestions = async (req, res) => {
  try {
    const hash = req.hash;
    const user = await Candidate.findOne({ hash });
    if (!user) {
      return res.status(200).json({ code: 404, message: 'User not found' });
    }
    const { job_role } = req.body;


    if (!job_role) {
      return res.status(200).send({ code:400, message: 'Job role is required' });
    }


    const questions = jobRoleQuestions[job_role];


    if (!questions) {
      return res.status(200).send({ code:400, message: 'Invalid job role' });
    }


    return res.status(200).send({ questions });

  } catch (error) {

    return res.status(200).json({ code: 500, error:error.message });
  }
};