const express = require('express');
const fileUpload = require('express-fileupload');
const moment = require('moment');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

const Candidate = require('../Models/candidate');
const HR = require('../Models/hr');


const app = express();
app.use(fileUpload());


const jobStatusDescription = (jobStatus) => {
  switch (jobStatus) {
    case 'SCHEDULED':
      return 'The candidate has been scheduled for the interview.';
    case 'RE-SCHEDULED':
      return 'The interview has been re-scheduled.';
    case 'COMPLETED':
      return 'The job has been completed.';
    case 'HIRED':
      return 'The candidate has been hired.';
    case 'SELECTED':
      return 'The candidate has been selected.';
    case 'REJECTED':
      return 'The candidate has been rejected.';
    case 'IN_PROGRESS':
      return 'The candidate is in progress.';
    default:
      return 'Status updated.';
  }
};


exports.getHRDetailsByHash = async (req, res) => {
  try {
    const hash = req.hash;


    const user = await HR.findOne({ hash });

    if (user) {

      return res.status(200).json({
        code: 200,
        name: user.name,
        role: user.role,
      });
    }


    return res.status(200).json({
      code: 404,
      message: 'HR user not found.',
    });

  } catch (err) {
    res.status(200).json({ code: 500, message: err.message });
  }
};


exports.handleExcelUpload = async (req, res) => {
  try {
    const hash = req.hash;
    let { excelData } = req.body;

    if (!hash) {
      return res.status(200).json({
        code: 400,
        message: 'Hash is required.',
      });
    }

    let user = await HR.findOne({ hash });
    if (!user || user.role !== 'hr') {
      return res.status(200).json({
        code: 403,
        message: 'Only HR can upload',
      });
    }

    let results = { successCount: 0, errors: [] };
    let isExcelData = Array.isArray(excelData);

    if (isExcelData) {
      for (let record of excelData) {
        let { name, phone_number, job_role, candidate_Status, job_Status, walkin_date, files } = record;

        let parsedDate;

        
        if (walkin_date === 'NA' || !moment(walkin_date, 'DD-MM-YYYY', true).isValid()) {
          results.errors.push({
            record,
            error: `Invalid walkin date ${walkin_date}.`,
          });
          continue;
        } else {
          parsedDate = moment(walkin_date, 'DD-MM-YYYY').toDate();
        }

        let currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);

        
        let timeline;
        if (parsedDate.getTime() === currentDate.getTime()) {
          timeline = 'TODAY';
        } else if (parsedDate.getTime() > currentDate.getTime()) {
          timeline = 'UPCOMING';
        } else {
          timeline = 'PREVIOUS';
        }

        if (timeline === 'TODAY') {
          results.errors.push({
            record,
            error: 'Records with TODAY\'s date are not allowed to be saved.',
          });
          continue; 
        }

        if (timeline === 'UPCOMING') {
          if (!candidate_Status) {
            candidate_Status = 'WAITING'; 
          }

          if (!job_Status) {
            job_Status = 'IN_PROGRESS'; 
          }
        }

        if (timeline === 'PREVIOUS') {
          if (!candidate_Status) {
            results.errors.push({
              record,
              error: 'Skipping record: Candidate status is required for PREVIOUS date.',
            });
            continue;
          }
          if (candidate_Status === 'PRESENT') {
            if (!job_Status) {
              results.errors.push({
                record,
                error: 'Job status is required when candidate status is PRESENT for PREVIOUS date.',
              });
              continue;
            }
          }

          if (candidate_Status === 'ABSENT') {
            job_Status = 'REJECTED';
            record.job_Status = job_Status;
            record.job_Status_Description = 'Candidate was absent; status set to REJECTED';
          }
        }

        const validStatuses = {
          TODAY: {
            candidate: ['PRESENT', 'ABSENT', 'RE-SCHEDULED', 'WAITING'],
            job: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
          },
          UPCOMING: {
            candidate: ['WAITING', 'RE-SCHEDULED'],
            job: ['IN_PROGRESS'],
          },
          PREVIOUS: {
            candidate: ['PRESENT', 'ABSENT'],
            job: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
          },
        };

        if (!validStatuses[timeline]) {
          return res.status(200).json({
            code: 400,
            message: 'Invalid timeline provided.',
          });
        }

        const { candidate: validCandidateStatuses, job: validJobStatuses } = validStatuses[timeline];

        if (!validCandidateStatuses.includes(candidate_Status)) {
          results.errors.push({
            record,
            error: `The candidate status ${candidate_Status} is not valid for the ${timeline} timeline.`,
          });
          continue;
        }

        if (job_Status && !validJobStatuses.includes(job_Status)) {
          results.errors.push({
            record,
            error: `The job status ${job_Status} is not valid for the ${timeline} timeline.`,
          });
          continue;
        }

        


        if (timeline === 'PREVIOUS') {
          if (!candidate_Status) {
            results.errors.push({
              record,
              error: 'Skipping record: Candidate status is required for PREVIOUS date.',
            });
            continue;
          }
          if (candidate_Status === 'PRESENT') {
            if (!job_Status) {
              results.errors.push({
                record,
                error: 'Job status is required when candidate status is PRESENT for PREVIOUS date.',
              });
              continue;
            }
          }

          if (candidate_Status === 'ABSENT') {
            job_Status = 'REJECTED';
            record.job_Status = job_Status;
            record.job_Status_Description = 'Candidate was absent; status set to REJECTED';
          }
        }

        try {
          let existingCandidate = await Candidate.findOne({ phone_number: phone_number });

          if (existingCandidate) {
            results.errors.push({
              record,
              error: `A candidate with the phone number ${phone_number} already exists.`,
            });
            continue;
          }

          let hashedPhoneNumber = crypto.createHash('sha256').update(phone_number.toString()).digest('hex');

          let newCandidate = new Candidate({
            name,
            phone_number,
            hash: hashedPhoneNumber,
            job_role,
            candidate_Status,
            job_Status,
            description: jobStatusDescription(job_Status),
            walkin_date: parsedDate,
            scheduled_date: parsedDate,
            timeline: timeline,
            invited: true,
          });

          if (files && files.length > 0) {
            newCandidate.files = files.map(file => {
              file.file_id = file.file_id || uuidv4();
              return file;
            });
          }

          await newCandidate.save();
          results.successCount += 1;

        } catch (dbError) {
          results.errors.push({
            record,
            error: `Database error: ${dbError.message}`,
          });
        }
      }
    } else {
      return res.status(200).json({
        code: 400,
        message: 'Invalid data format. Please provide either form data or excel data.',
      });
    }

    res.status(201).json({
      message: "Data processing complete.",
      successCount: results.successCount,
      errors: results.errors,
    });

  } catch (error) {
    res.status(200).json({
      code: 500,
      message: error.message
    });
  }
};


exports.createHRDetails = async (req, res) => {
  try {
    const { phone_number, name, email, position } = req.body;


    const countHR = await HR.countDocuments();
    if (countHR === 1) {
      return res.status(200).json({ code: 400, message: "Cannot create another HR" });
    }


    const existingHR = await HR.findOne({ email });
    if (existingHR) {
      return res.status(200).json({ code: 400, message: 'Email already exists in HR' });
    }


    const existingCandidateEmail = await Candidate.findOne({ email });
    if (existingCandidateEmail) {
      return res.status(200).json({ code: 400, message: 'Email already exists in Candidate' });
    }


    const existingHRPhone = await HR.findOne({ phone_number });
    if (existingHRPhone) {
      return res.status(200).json({ code: 400, message: 'Phone number already exists in HR' });
    }


    const existingCandidatePhone = await Candidate.findOne({ phone_number });
    if (existingCandidatePhone) {
      return res.status(200).json({ code: 400, message: 'Phone number already exists in Candidate' });
    }


    const hashedPhoneNumber = crypto.createHash('sha256').update(phone_number).digest('hex');


    const newHR = new HR({
      phone_number: phone_number,
      hash: hashedPhoneNumber,
      name,
      email,
      position,
    });

    await newHR.save();

    res.status(201).json({
      message: 'HR details created successfully',
      hr: newHR,
    });
  } catch (error) {
    res.status(200).json({code:500, error: error.message });
  }
};


exports.uploadCandidateResume = async (req, res) => {
  const hash = req.hash;

  const { filename, contentType, data, candidate_id } = req.body;


  if (!filename || !contentType || !data || !hash || !candidate_id) {
    return res.status(200).json({ code: 400, error: 'All fields are required' });
  }

  try {

    const Hr = await HR.findOne({ hash });
    if (!Hr) {
      return res.status(200).json({ code: 404, error: 'HR not found or invalid hash' });
    }


    const candidate = await Candidate.findOne({ candidate_id });
    if (!candidate) {
      return res.status(200).json({ code: 404, error: 'Candidate not found' });
    }


    const newFile = {
      filename,
      contentType,
      data,
      file_id: uuidv4(),
    };


    candidate.files.push(newFile);


    await candidate.save();


    res.status(201).json({
      code: 201,
      message: 'File uploaded successfully',
      file: newFile,
    });
  } catch (error) {
    res.status(200).json({ code: 500, error: error.message });
  }
};



exports.getJobRolesAndStatuses = async (req, res) => {
  try {
    const hash = req.hash;

    if (!hash) {
      return res.status(200).json({
        code: 400,
        message: 'Hash is required.',
      });
    }


    let user = await HR.findOne({ hash });
    if (!user) {
      return res.status(200).json({
        code: 404,
        message: 'User not found.',
      });
    }


    if (user.role !== 'hr') {
      return res.status(200).json({
        code: 403,
        message: 'Only HR can upload.',
      });
    }


    const validJobRoles = [
      'Video Editor',
      'AWS',
      'Software Tester',
      'MERN Stack Developer',
      'Graphic Designer',
      'HR Recruiter',
      'Operations Associate',
      'Compliance Auditor',
      'Accountant',
      'Finance Analyst',
      'Flutter Developer',
      'Marketing Specialist',
      'Pre-Sales Executive',
      'Client Handling Manager',
      'Sales Executive',
      'others',
    ];

    const validCandidateStatuses = ['PRESENT', 'ABSENT', 'RE-SCHEDULED', 'WAITING'];

    const validJobStatuses = ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'];

    const selectedStatuses = ['TRAINEE', 'EMPLOYEE'];

    return res.status(200).json({
      code: 200,
      message: 'Data fetched successfully.',
      available_job_roles: validJobRoles,
      available_candidate_statuses: validCandidateStatuses,
      available_job_statuses: validJobStatuses,
      available_selected_statuses: selectedStatuses,

    });

  } catch (error) {
    return res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};



exports.uploadFormResume = async (req, res) => {
  const { filename, contentType, data, name, phone_number, walkin_date, job_role, candidate_Status, job_Status } = req.body;

  if (!filename || !contentType || !data || !phone_number || !name || !walkin_date || !job_role || !candidate_Status || !job_Status) {
    return res.status(200).json({ code: 400, error: 'All fields are required' });
  }

  const inputDate = new Date(walkin_date);
  const currentDate = new Date();

  if (inputDate.setHours(0, 0, 0, 0) <= currentDate.setHours(0, 0, 0, 0)) {
    return res.status(200).json({ code: 400, error: 'Date should be in the future' });
  }


  const hashedPhoneNumber = crypto.createHash('sha256').update(phone_number).digest('hex');

  try {
    const candidateExist = await Candidate.findOne({ phone_number: phone_number });
    if (candidateExist) {
      return res.status(200).json({ code: 400, error: 'Phone number already exists in Candidate data.' });
    }

    const hrExist = await HR.findOne({ phone_number: phone_number });
    if (hrExist) {
      return res.status(200).json({ code: 400, error: 'Phone number already exists in HR schema' });
    }

    let timeline = 'PREVIOUS';
    const parsedDate = new Date(walkin_date);

    let dateDifference = currentDate.getTime() - parsedDate.getTime();

    if (dateDifference === 0) {
      timeline = 'TODAY';
    } else if (dateDifference > 0) {
      timeline = 'PREVIOUS';
    } else {
      timeline = 'UPCOMING';
    }

    if (timeline === 'TODAY') {
      return res.status(200).json({ code: 400, error: 'Creating candidates for today or with "TODAY" timeline is not allowed.' });
    }

    const candidate = new Candidate({
      hash: hashedPhoneNumber,
      name,
      phone_number,
      walkin_date,
      job_role,
      candidate_Status,
      job_Status,
      timeline,
      invited: true,
      files: [{
        filename,
        contentType,
        data,
      }]
    });

    await candidate.save();

    res.status(201).json({
      code: 201,
      message: 'New candidate created and file uploaded successfully',
    });
  } catch (error) {
    res.status(200).json({ code: 500, error: error.message });
  }
};





