const { Schema, model } = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');

const allowedFileTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg'];

const htmlTagRegex = /<[^>]*>/g; 

const fileSchema = new Schema({
  filename: {
    type: String,
    required: true,
    maxlength: [255, 'Filename cannot be longer than 255 characters'],
    match: [/^[^<]*$/, 'Filename cannot contain HTML tags'],
  },
  contentType: {
    type: String,
    required: true,
    validate: {
      validator: function (value) {
        return allowedFileTypes.includes(value);
      },
      message: 'Invalid file type. Only PDF, DOCX, JPG, and JPEG are allowed.',
    }
  },
  data: {
    type: String,
    required: true,
    match: [/^[^<]*$/, 'File data cannot contain HTML tags'],
  },
  file_id: {
    type: String,
    default: uuidv4,
  },
});

const candidateSchema = new Schema({
  phone_number: {
    type: String,
    required: [true, 'Phone number is required'],
    trim: true,
    minlength: [10, 'Phone number must be at least 10 digits'],
    maxlength: [15, 'Phone number cannot exceed 15 digits'],
    match: [/^[6-9][0-9]{9}$/, 'Phone number must start with 6, 7, 8, or 9 and contain only digits'],
  },
  hash: {
    type: String,
    required: [true, 'Hash is required'],
    match: [/^[^<]*$/, 'Hash cannot contain HTML tags'],
  },
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    minlength: [3, 'Name must be at least 3 characters'],
    maxlength: [100, 'Name cannot be longer than 100 characters'],
    match: [/^[A-Za-z\s]+$/, 'Name must only contain alphabets and spaces and cannot start with spaces'],
  },
  role: {
    type: String,
    enum: ['candidate', 'hr'],
    default: 'candidate',
    required: [true, 'Role is required'],
  },
  candidate_id: {
    type: String,
    default: uuidv4,
  },
  scheduled_date: {
    type: Date,
    default: Date.now,
  },
  walkin_date: {
    type: Date,
    required: [true, 'Walkin_date is required'],
    default: () => {
      const today = new Date();
      today.setHours(0, 0, 0, 0); 
      return today;
    },
  },

  job_role: {
    type: String,
    required: [true, 'Job role is required'],
    enum: [
      'Video Editor',
      'AWS',
      'UI/UX',
      'Software Tester',
      'MERN Stack Developer',
      'Graphic Designer',
      'HR Recruiter',
      'Operations Associate',
      'Compliance Auditor',
      'Accountant',
      'Finance Analyst',
      'Flutter Developer',
      'Marketing Specialist',
      'Pre-Sales Executive',
      'Client Handling Manager',
      'Sales Executive',
      'others',
    ],
  },
  timeline: {
    type: String,
    enum: ['UPCOMING', 'TODAY', 'PREVIOUS'],
    default: 'TODAY',
  },
  candidate_Status: {
    type: String,
    enum: ['PRESENT', 'ABSENT', 'RE-SCHEDULED', 'WAITING'],
  },
  job_Status: {
    type: String,
    enum: ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'],
    default: 'IN_PROGRESS',
  },
  description: {
    type: String,
    default: 'Status updated.',
    maxlength: [500, 'Description cannot be longer than 500 characters'],
    minlength: [10, 'Description should be at least 10 characters'],
    match: [/^[^<]*$/, 'Description cannot contain HTML tags'],
  },
  files: [fileSchema],

  cameraPermission: {
    type: Boolean,
    default: false,
    required: [true, 'Camera permission status is required'],
  },
  invited: {
    type: Boolean,
    required: [true, 'Invited by field is required'],
    default: false,
  }
}, { timestamps: true });

function updateTimeline(candidate) {
  const currentDate = new Date();
  const candidateDate = candidate.walkin_date;

  if (candidateDate.toDateString() === currentDate.toDateString()) {
    candidate.timeline = 'TODAY';
  } else if (candidateDate > currentDate) {
    candidate.timeline = 'UPCOMING';
  } else {
    candidate.timeline = 'PREVIOUS';
  }
}

candidateSchema.pre('save', function (next) {
  updateTimeline(this);
  next();
});

candidateSchema.pre('findOneAndUpdate', function (next) {
  const update = this.getUpdate();

  if (update && update.walkin_date) {
    updateTimeline(update);
  }

  next();
});

candidateSchema.virtual('formattedDate').get(function () {
  return moment(this.walkin_date).format('DD-MM-YYYY');
});

candidateSchema.methods.toJSON = function () {
  const candidate = this.toObject();
  candidate.walkin_date = moment(candidate.walkin_date).format('DD-MM-YYYY');
  return candidate;
};

const Candidate = model('Candidate', candidateSchema);

module.exports = Candidate;
