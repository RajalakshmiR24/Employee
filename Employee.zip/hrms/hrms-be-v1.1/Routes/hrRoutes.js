const express = require('express');
const fileUpload = require('express-fileupload');  
const candidateController = require('../Controllers/candidateController');
const hrController = require('../Controllers/hrController');  
const {verifyToken, findRoleByHash} = require('../Middlewares/auth');

const hrRouter = express.Router();

hrRouter.use(fileUpload());
// hrRouter.use(verifyToken);
hrRouter.use(findRoleByHash);
hrRouter.post('/name', hrController.getHRDetailsByHash);
hrRouter.post('/overview', candidateController.getHRDashboardOverview);
hrRouter.post('/all-candidates', candidateController.getAllCandidates);
hrRouter.post('/candidate-status', candidateController.updateCandidateStatus);
hrRouter.post('/upload-excel',hrController.handleExcelUpload);
hrRouter.post('/upload-resume',hrController.uploadCandidateResume);
hrRouter.post('/roles-status',hrController.getJobRolesAndStatuses);
hrRouter.post('/upload-formresume',hrController.uploadFormResume);

module.exports = hrRouter;
