import React from 'react';
import {
  containerStyle,
  headingStyle,
  buttonContainerStyle,
  buttonStyle,
  textContainerStyle
} from '../style/Landing.styles';
import { useNavigate } from 'react-router-dom';

const Landing = () => {
  const navigate = useNavigate();

  const handleLogin = () => {
    // const apiUrl = process.env.REACT_APP_HRMS_SERVER || window.location.origin;
    // window.open(`${apiUrl}/api/hrms/auth/start`, "_self");
    navigate(`/hrms/hr`);

  }

  return (
    <div style={containerStyle}>
      <div style={textContainerStyle}>
        <h1 style={headingStyle}>
          Welcome to ZustPe | Land of Freshers
        </h1>

        <div style={buttonContainerStyle}>
          <button
            onClick={handleLogin}
            style={buttonStyle}
          >
            Go to Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default Landing;
