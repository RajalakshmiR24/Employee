import React, { useState, useEffect } from 'react';
import { FaBars } from 'react-icons/fa'; 
import { headerStyles } from '../../style/TaskHeader'; 

const TaskHeader = ({ toggleSidebar }) => {  
  const [elapsedTime, setElapsedTime] = useState(0); 
  const [running, setRunning] = useState(false); 
  const [prevTime, setPrevTime] = useState(null); 
  const [nextTime, setNextTime] = useState(null); 

  const toggleStopwatch = () => {
    setRunning(!running);
  };

  const resetStopwatch = () => {
    setElapsedTime(0);
    setPrevTime(null);
    setNextTime(null);
  };

  const formatTime = (timeInSeconds) => {
    const hours = Math.floor(timeInSeconds / 3600).toString().padStart(2, '0');
    const minutes = Math.floor((timeInSeconds % 3600) / 60).toString().padStart(2, '0');
    const seconds = (timeInSeconds % 60).toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
  };

  const handlePrev = () => {
    if (prevTime !== null) {
      setElapsedTime(prevTime);
      setNextTime(elapsedTime); 
    }
  };

  const handleNext = () => {
    if (nextTime !== null) {
      setElapsedTime(nextTime);
    }
  };

  useEffect(() => {
    let interval;
    if (running) {
      interval = setInterval(() => {
        setElapsedTime((prevTime) => prevTime + 1); 
      }, 1000);
    } else {
      setPrevTime(elapsedTime);
      clearInterval(interval); 
    }

    return () => clearInterval(interval);
  }, [running, elapsedTime]);

  return (
    <header style={headerStyles.container}>
      <div style={headerStyles.right}>
        <FaBars style={headerStyles.icon} onClick={toggleSidebar} /> 
      </div>
      <div style={headerStyles.center}>
        <p>{formatTime(elapsedTime)}</p>
      </div>
      <div style={headerStyles.left}>
        <button style={headerStyles.button} onClick={toggleStopwatch}>
          {running ? 'Pause' : 'Start'}
        </button>
        <button style={headerStyles.button} onClick={resetStopwatch}>
          Reset
        </button>
        <button style={headerStyles.button} onClick={handlePrev} disabled={prevTime === null}>
          Prev
        </button>
        <button style={headerStyles.button} onClick={handleNext} disabled={nextTime === null}>
          Next
        </button>
      </div>
    </header>
  );
};

export default TaskHeader;
