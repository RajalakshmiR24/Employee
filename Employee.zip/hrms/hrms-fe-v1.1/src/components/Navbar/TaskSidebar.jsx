import React, { useState, useEffect } from 'react';
import axiosInstance from '../../utils/axiosInstance'; 

const TaskSidebar = ({ jobRole }) => {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [storedJobRole, setStoredJobRole] = useState(null);

  
  useEffect(() => {
    const savedRole = localStorage.getItem('job_role');
    if (savedRole) {
      setStoredJobRole(savedRole);
    }
  }, []);

  
  useEffect(() => {
    
    const roleToUse = jobRole || storedJobRole;

    if (!roleToUse) return; 

    const fetchJobRoleQuestions = async () => {
      setLoading(true);
      setError(null);

      try {
        const response = await axiosInstance.post('/api/hrms/candidate/get-job-role-questions', { job_role: roleToUse });
        setQuestions(response.data.questions);
      } catch (err) {
        setError(err.response ? err.response.data.message : 'Error fetching questions');
      } finally {
        setLoading(false);
      }
    };

    fetchJobRoleQuestions();
  }, [jobRole, storedJobRole]); 

  return (
    <div className="task-sidebar">
      <h3>Job Role: {storedJobRole || jobRole || 'Not Selected'}</h3> 

      {loading && <p>Loading questions...</p>}

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <ul>
        {questions.length > 0 ? (
          questions.map((question, index) => (
            <li key={index}>{question}</li>
          ))
        ) : (
          <p>No questions available for this job role.</p>
        )}
      </ul>
    </div>
  );
};

export default TaskSidebar;
