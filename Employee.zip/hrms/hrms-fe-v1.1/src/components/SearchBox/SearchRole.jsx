import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosInstance';

const SearchRole = () => {
  const [selectedRole, setSelectedRole] = useState('');
  const [jobRoles, setJobRoles] = useState([]); 
  const [error, setError] = useState('');
  const [responseMessage, setResponseMessage] = useState('');
  const [loading, setLoading] = useState(true); 

  const navigate = useNavigate();

  const fetchJobRoles = async () => {
    try {
      setLoading(true); 
      const response = await axiosInstance.post('/api/hrms/candidate/get-job-roles');
      const { available_job_roles, code, message } = response.data;

      if (code && message) {
        
        localStorage.removeItem('hrmstoken'); 
        alert(message);  
        return;
      }

      setJobRoles(available_job_roles || []); 
    } catch (error) {
      setError('Failed to fetch job roles');
      console.error('Error fetching job roles:', error);
    } finally {
      setLoading(false); 
    }
  };

  useEffect(() => {
    fetchJobRoles();
  }, []);

  const handleRoleChange = (event) => {
    const role = event.target.value;
    setSelectedRole(role);
  };

  const handleSubmit = async () => {
    if (selectedRole) {
      try {
        const response = await axiosInstance.post('/api/hrms/candidate/update-job-role', {
          job_role: selectedRole,
        });

        if (response.data) {
          const { code, message } = response.data;

          if (code === 400 || code === 404) {
          
            alert(message);  
            localStorage.removeItem('role');
            localStorage.removeItem('hrmstoken');
          } else if (code === 200) {
            setResponseMessage('Job role updated successfully.');
            navigate('/hrms/candidate/welcome');
             
          }
        }
      } catch (error) {
        console.error('Error updating job role:', error);
        setResponseMessage('Failed to update job role.');
      }
    } else {
      console.error('job role is missing');
      setResponseMessage('Job role is missing.');
    }
  };

  return (
    <div style={{ justifyContent: 'center', justifyItems: 'center', padding: '20px', borderRadius: '8px' }}>
      <h2 style={{ color: '#1a125f' }}>Select Job Role</h2>
      {error && <p style={{ color: 'red', fontWeight: 'bold' }}>{error}</p>}
      {responseMessage && <p style={{ color: 'red', fontWeight: 'bold' }}>{responseMessage}</p>}

      {loading ? (
        <p>Loading roles...</p> 
      ) : (
        <select
          value={selectedRole}
          onChange={handleRoleChange}
          style={{
            padding: '10px',
            margin: '10px 0',
            borderRadius: '4px',
            border: '1px solid #ccc',
            backgroundColor: '#fff',
            color: '#1a125f',
            fontSize: '16px',
          }}
        >
          <option value="">Select a Role</option>
          {jobRoles.length > 0 ? (
            jobRoles.map((role, index) => (
              <option key={index} value={role}>
                {role}
              </option>
            ))
          ) : (
            <option disabled>No available roles</option>
          )}
        </select>
      )}

      <button
        onClick={handleSubmit}
        style={{
          padding: '10px 20px',
          backgroundColor: '#1a125f',
          color: '#fff',
          border: 'none',
          borderRadius: '4px',
          fontSize: '16px',
          cursor: 'pointer',
        }}
      >
        Submit
      </button>
    </div>
  );
};

export default SearchRole;
