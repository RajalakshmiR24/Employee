import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import theme from '../../style/theme';

const TermsAndConditions = () => {
  const [isChecked, setIsChecked] = useState(false);
  const [timerExpired, setTimerExpired] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(5); 
  const navigate = useNavigate();

  const handleCheckboxChange = (event) => {
    setIsChecked(event.target.checked);
  };

  const handleSubmit = () => {
    if (isChecked) {
      navigate('/hrms/status');
    } else {
      alert('Please accept the terms and conditions to proceed.');
    }
  };

  
  useEffect(() => {
    
    const interval = setInterval(() => {
      setTimeRemaining((prevTime) => {
        if (prevTime <= 1) {
          clearInterval(interval); 
          setTimerExpired(true); 
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000); 

    
    return () => clearInterval(interval);
  }, []);

  
  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secondsRemaining = seconds % 60;
    return `${minutes}:${secondsRemaining < 10 ? '0' : ''}${secondsRemaining}`;
  };

  return (
    <div>
      <h2 style={{ fontSize: theme.typography.headingFontSize, color: theme.colors.primary }}>
        Terms and Conditions
      </h2>
      <p style={{ fontSize: theme.typography.fontSize, color: theme.colors.textPrimary }}>
        By using this service, you agree to the following terms and conditions.
      </p>

      <div>
        <label style={{ fontSize: theme.typography.fontSize, color: theme.colors.textPrimary }}>
          <input
            type="checkbox"
            checked={isChecked}
            onChange={handleCheckboxChange}
            style={{ marginRight: '8px' }}
          />
          I agree to the Terms and Conditions
        </label>
      </div>

      <div style={{ fontSize: theme.typography.fontSize, color: theme.colors.textPrimary, marginTop: '10px' }}>
        <p>Time Remaining: {formatTime(timeRemaining)}</p>
      </div>

      <button
        onClick={handleSubmit}
        disabled={!isChecked || !timerExpired}
        style={{
          backgroundColor: theme.colors.primary,
          color: theme.colors.secondary,
          padding: '12px 20px',
          fontSize: theme.typography.fontSize,
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer',
          transition: 'background-color 0.3s',
          opacity: isChecked && timerExpired ? 1 : 0.6,
        }}
      >
        Proceed
      </button>
    </div>
  );
};

export default TermsAndConditions;
