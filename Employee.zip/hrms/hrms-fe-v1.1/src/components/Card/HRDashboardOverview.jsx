import React, { useState, useEffect,useCallback } from 'react';
import axiosInstance from '../../utils/axiosInstance';  
import { 
  cardStyle, 
  cardHeaderStyle, 
  cardBodyStyle, 
  selectStyle, 
  buttonStyle, 
  monthSelectStyle, 
  containerStyle, 
  headingStyle, 
  flexContainerStyle 
} from '../../style/HRDashboardOverview.styles';

const HRDashboardOverview = () => {
  const [dashboardData, setDashboardData] = useState({
    totalCandidates: 0,
    hiresThisMonth: 0,
    hiresInSelectedMonth: 0,
  });
  const [candidateFilter, setCandidateFilter] = useState('TODAY');
  const [showMonthPicker, setShowMonthPicker] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState('');
  
  

  
  const fetchDashboardData = useCallback(async () => {
    try {
      const requestBody = {
        timeline: candidateFilter, 
        month: selectedMonth,
      };
  
      const response = await axiosInstance.post('/api/hrms/hr/overview', requestBody);
  
      setDashboardData(response.data); 
  
    } catch (error) {
      console.error('Error fetching HR dashboard data:', error);
    }
  }, [candidateFilter, selectedMonth]); 
  
  useEffect(() => {
    fetchDashboardData(); 
  }, [fetchDashboardData]); 
  

  const handleCandidateFilterChange = (e) => {
    setCandidateFilter(e.target.value);
  };

  const toggleMonthPicker = () => {
    setShowMonthPicker(!showMonthPicker);
  };

  const handleMonthChange = (e) => {
    setSelectedMonth(e.target.value);
  };

  return (
    <div style={containerStyle}>
      <h2 style={headingStyle}>HR Dashboard Overview</h2>

      <div style={flexContainerStyle}>
        <div style={cardStyle}>
          <h3 style={cardHeaderStyle}>Total Candidates</h3>
          <select
            value={candidateFilter}
            onChange={handleCandidateFilterChange}
            style={selectStyle}
          >
            <option value="UPCOMING">Upcoming</option>
            <option value="TODAY">Today</option>
            <option value="PREVIOUS">Previous</option>
          </select>
          <p style={cardBodyStyle}>{dashboardData.totalCandidates}</p>
        </div>

        <div style={cardStyle}>
          <h3 style={cardHeaderStyle}>Hires This Month</h3>
          <button
            style={buttonStyle}
            onClick={toggleMonthPicker}
          >
            {showMonthPicker ? 'Close Month Picker' : 'Select Month'}
          </button>

          {showMonthPicker && (
            <select
              value={selectedMonth}
              onChange={handleMonthChange}
              style={monthSelectStyle}
            >
              <option value="">Select Month</option>
              <option value="01">January</option>
              <option value="02">February</option>
              <option value="03">March</option>
              <option value="04">April</option>
              <option value="05">May</option>
              <option value="06">June</option>
              <option value="07">July</option>
              <option value="08">August</option>
              <option value="09">September</option>
              <option value="10">October</option>
              <option value="11">November</option>
              <option value="12">December</option>
            </select>
          )}
          
          <p style={cardBodyStyle}>
            {selectedMonth ? dashboardData.hiresInSelectedMonth : dashboardData.hiresThisMonth}
          </p>
        </div>
      </div>
    </div>
  );
};

export default HRDashboardOverview;
