import React, { useState } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import styles from '../../style/CandidateDetails_Modal.styles';

const CandidateDetails_Modal = ({ candidate, onClose, fetchCandidates }) => {
  const [isUploading, setIsUploading] = useState(false);
  const [file, setFile] = useState(null);
  const [uploadError, setUploadError] = useState('');
  const [modalOpen, setModalOpen] = useState(true); // Keep modalOpen state to control modal visibility
  const [uploadProgress, setUploadProgress] = useState(0);

  const allowedFileTypes = [
    'application/pdf',
    'image/jpeg',
    'image/png',
    'application/vnd.ms-word',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ];

  if (!candidate) return null;

  const openResumeInNewTab = () => {
    const file = candidate.files && candidate.files[0];
    if (file) {
      const byteCharacters = atob(file.data);
      const byteArrays = [];
      for (let offset = 0; offset < byteCharacters.length; offset += 1024) {
        const slice = byteCharacters.slice(offset, offset + 1024);
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
          byteNumbers[i] = slice.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
      }

      const blob = new Blob(byteArrays, { type: file.contentType });
      const fileURL = URL.createObjectURL(blob);
      const extension = file.contentType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ? 'docx' : (file.contentType === 'application/vnd.ms-word' ? 'doc' : file.contentType.split('/')[1]);

      const fileName = `${candidate.name.replace(/\s+/g, '_')}_resume.${extension}`;
      const a = document.createElement('a');
      a.href = fileURL;
      a.target = '_blank';
      a.download = fileName;
      a.click();
    }
  };

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && !allowedFileTypes.includes(selectedFile.type)) {
      setUploadError('Invalid file type. Please upload a .pdf, .jpg, .jpeg, .png, or .docx file.');
      setFile(null);
    } else {
      setFile(selectedFile);
      setUploadError('');
    }
  };

  const handleFileUpload = async () => {
    if (!file) {
      setUploadError('Please select a file to upload.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('candidate_id', candidate.candidate_id);

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const response = await axiosInstance.post('/api/hrms/hr/upload-resume', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            setUploadProgress(percent);
          }
        }
      });

      if (response.status === 200) {
        alert('File uploaded successfully');
        fetchCandidates();
        setModalOpen(false); // Close modal after successful upload
        onClose();
      } else {
        console.error('Unexpected response status:', response.status);
        onClose();
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      setUploadError('An error occurred during file upload. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const closeModal = () => {
    setModalOpen(false); // Close modal on clicking close
    onClose();
  };

  if (!modalOpen) return null;

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <div style={styles.modalHeader}>
          <h2>Candidate Details</h2>
          <button onClick={closeModal} style={styles.closeButton}>Close</button>
        </div>
        <div style={styles.modalContent}>
          <p><strong>Name:</strong> {candidate.name}</p>
          <p><strong>Mobile Number:</strong> {candidate.phone_number}</p>
          <p><strong>Walkin date:</strong> {new Date(candidate.walkin_date).toLocaleDateString()}</p>
          <p><strong>Timeline:</strong> {candidate.timeline}</p>
          <p><strong>Role:</strong> {candidate.job_role || 'N/A'}</p>
          <p><strong>Candidate Status:</strong> {candidate.candidate_Status}</p>
          <p><strong>Job Status:</strong> {candidate.job_Status}</p>
          <p><strong>Description:</strong> {candidate.description}</p>

          {candidate.files && candidate.files.length > 0 ? (
            <button onClick={openResumeInNewTab} style={styles.resumeButton}>Open Resume</button>
          ) : (
            <div>
              <input
                type="file"
                onChange={handleFileChange}
                accept=".pdf, .docx, .png, .jpg, .jpeg"
                style={styles.fileInput}
              />
              <button onClick={handleFileUpload} style={styles.uploadButton}>
                {isUploading ? 'Uploading...' : 'Upload Resume'}
              </button>
              {uploadProgress > 0 && uploadProgress < 100 && (
                <div style={styles.progressBar}>
                  <div style={{ width: `${uploadProgress}%`, backgroundColor: 'green', height: '5px' }}></div>
                </div>
              )}
              {uploadError && <p style={styles.errorText}>{uploadError}</p>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CandidateDetails_Modal;
