import React, { useState, useEffect } from 'react';
import theme from '../../style/theme';
import * as XLSX from 'xlsx';
import axiosInstance from '../../utils/axiosInstance';

const OptionModal = ({ handleUpload, handleCloseModal, fetchCandidates }) => {
  const [isBulkUpload, setIsBulkUpload] = useState(false);
  const [isSingleUpload, setIsSingleUpload] = useState(false);
  const [jobRoles, setJobRoles] = useState([]);
  const [candidateStatuses, setCandidateStatuses] = useState([]);
  const [jobStatuses, setJobStatuses] = useState([]);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');

  const [jobRole, setJobRole] = useState('');
  const [candidateStatus, setCandidateStatus] = useState('');
  const [jobStatus, setJobStatus] = useState('');

  const [nameError, setNameError] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [dateError, setDateError] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const [isDateLocked, setIsDateLocked] = useState(false);

  const validateName = (value) => {
    const nameRegex = /^[A-Za-z\s]+$/;
    if (!value.trim()) {
      setNameError('Name cannot be empty.');
      return false;
    }
    if (!nameRegex.test(value)) {
      setNameError('Name can only contain letters and spaces.');
      return false;
    }
    if (value.trim().charAt(0) === ' ') {
      setNameError('Name cannot start with a space.');
      return false;
    }
    setNameError('');
    return true;
  };

  const validatePhone = (value) => {
    const phoneRegex = /^[6-9][0-9]{9}$/;
    if (!value.trim()) {
      setPhoneError('Phone number cannot be empty.');
      return false;
    }
    if (!phoneRegex.test(value)) {
      setPhoneError('Phone number must start with 6,7,8, or 9 and contain 10 digits.');
      return false;
    }
    setPhoneError('');
    return true;
  };

  const validateDate = (value) => {
    const today = new Date();
    const selectedDate = new Date(value);

    today.setHours(0, 0, 0, 0);

    if (!value) {
      setDateError('Date cannot be empty.');
      return false;
    }

    if (selectedDate < today) {
      setDateError('Date must be today or a future date.');
      return false;
    }

    setDateError('');
    return true;
  };

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];

    if (selectedFile && !allowedFileTypes.includes(selectedFile.type)) {
      setUploadError('Invalid file type. Please upload a .pdf, .jpg, .jpeg, .png, or .docx file.');
      setFile(null);
      return;
    }

    setFile(selectedFile);
    setUploadError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const isNameValid = validateName(name);
    const isPhoneValid = validatePhone(phone);
    const isDateValid = validateDate(date);

    if (isNameValid && isPhoneValid && isDateValid) {
      setLoading(true);
      setErrorMessage('');

      const formData = {
        name,
        phone_number: phone,
        walkin_date: date,
        job_role: jobRole,
        candidate_Status: candidateStatus,
        job_Status: jobStatus,
        filename: file.name,
        contentType: file.type,
        data: '',
      };

      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = reader.result.split(',')[1];
        formData.data = base64Data;

        try {
          const formSubmitResponse = await axiosInstance.post('/api/hrms/hr/upload-formresume', formData);

          if (formSubmitResponse.data.code === 201) {
            alert(formSubmitResponse.data.message);
            fetchCandidates();
          } else {
            console.error('Error from form submission:', formSubmitResponse.data.error);
            alert(formSubmitResponse.data.error);
          }
        } catch (error) {
          setLoading(false);
          handleCloseModal(true);

          if (error.response && error.response.data && error.response.data.error) {
            const errorMessage = error.response.data.error;
            setErrorMessage(errorMessage);
            alert(errorMessage);
          } else {
            setErrorMessage('An unexpected error occurred.');
            alert('An unexpected error occurred.');
          }
        } finally {
          setLoading(false);
          handleCloseModal(true);
        }
      };

      reader.readAsDataURL(file);
    } else {
      console.log('Form is invalid');
      setErrorMessage('Please fill in all fields correctly before submitting.');
    }
  };

  useEffect(() => {
    axiosInstance
      .post('/api/hrms/hr/roles-status')
      .then(response => {
        const { available_job_roles, available_candidate_statuses, available_job_statuses } = response.data;
        setJobRoles(available_job_roles);
        setCandidateStatuses(available_candidate_statuses);
        setJobStatuses(available_job_statuses);
      })
      .catch(error => {
        console.error('Error fetching roles and statuses:', error);
      });
  }, []);

  const handleSingleUploadClick = () => {
    setIsSingleUpload(true);
  };

  const handleBulkUploadClick = () => {
    setIsBulkUpload(true);
  };

  const handleNameChange = (e) => {
    setName(e.target.value);
    validateName(e.target.value);
  };

  const handlePhoneChange = (e) => {
    setPhone(e.target.value);
    validatePhone(e.target.value);
  };

  const handleDateChange = (e) => {
    const selectedDate = e.target.value;
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    setDate(selectedDate);

    const walkinDate = new Date(selectedDate);
    walkinDate.setHours(0, 0, 0, 0);

    if (!selectedDate) {
      setDateError('Date cannot be empty.');
      return;
    }

    if (walkinDate < currentDate) {
      setDateError('Date must be today or a future date.');
      return;
    }

    setDateError('');

    if (walkinDate > currentDate) {
      setCandidateStatus('WAITING');
      setJobStatus('IN_PROGRESS');
      setIsDateLocked(true);
    } else {
      setCandidateStatus('');
      setJobStatus('');
      setIsDateLocked(false);
    }
  };

  const handleJobRoleChange = (e) => setJobRole(e.target.value);
  const handleCandidateStatusChange = (e) => setCandidateStatus(e.target.value);
  const handleJobStatusChange = (e) => setJobStatus(e.target.value);

  const handleDownloadExcel = () => {
    const headers = ['name', 'phone_number', 'walkin_date', 'job_role', 'candidate_Status', 'job_Status'];
    const ws = XLSX.utils.aoa_to_sheet([headers]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, 'candidates_template.xlsx');
  };

  const allowedFileTypes = [
    'application/pdf',
    'image/jpeg',
    'image/png',
    'application/vnd.ms-word',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ];

  const [file, setFile] = useState(null);
  const [, setUploadError] = useState('');

  const renderSingleUploadForm = () => {
    return (
      <div>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={handleNameChange}
            style={inputStyle}
            minLength={3}
            maxLength={256}
          />
          {nameError && <span style={{ color: 'red' }}>{nameError}</span>}

          <input
            type="text"
            placeholder="Phone Number"
            value={phone}
            onChange={handlePhoneChange}
            style={inputStyle}
            minLength={10}
            maxLength={10}
          />
          {phoneError && <span style={{ color: 'red' }}>{phoneError}</span>}

          <input
            type="date"
            value={date}
            onChange={handleDateChange}
            style={inputStyle}
          />
          {dateError && <span style={{ color: 'red' }}>{dateError}</span>}

          <select style={inputStyle} value={jobRole} onChange={handleJobRoleChange}>
            <option value="">Select Job Role</option>
            {jobRoles.map((role, index) => (
              <option key={index} value={role}>
                {role}
              </option>
            ))}
          </select>

          <select
            style={inputStyle}
            value={candidateStatus}
            onChange={handleCandidateStatusChange}
            disabled={isDateLocked}
          >
            <option value="">Select Candidate Status</option>
            {candidateStatuses.map((status, index) => (
              <option key={index} value={status}>
                {status}
              </option>
            ))}
          </select>

          <select
            style={inputStyle}
            value={jobStatus}
            onChange={handleJobStatusChange}
            disabled={isDateLocked}
          >
            <option value="">Select Job Status</option>
            {jobStatuses.map((status, index) => (
              <option key={index} value={status}>
                {status}
              </option>
            ))}
          </select>
          <input
            type="file"
            onChange={handleFileChange}
            accept=".pdf, .docx, .png, .jpg, .jpeg"
            style={{
              padding: '10px',
              margin: '5px',
              width: '100%',
              borderRadius: '5px',
              border: '1px solid #ccc',
              cursor: 'pointer',
            }}
          />

          {loading ? <p>Submitting...</p> : <button style={submitButtonStyle} type="submit">Submit</button>}

          {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
        </form>
      </div>
    );
  };

  const renderBulkUploadOptions = () => {
    return (
      <div>
        <div style={buttonContainerStyle}>
          <button onClick={handleUpload} style={optionButtonStyle}>
            Upload Excel File
          </button>
          <button onClick={handleDownloadExcel} style={optionButtonStyle}>
            Download Excel File
          </button>
        </div>
      </div>
    );
  };

  // Styles for buttons and input
  const buttonContainerStyle = {
    display: 'flex',
    justifyContent: 'space-between',  // Aligns buttons to left and right
    marginTop: '20px',
  };

  const modalOverlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  };

  const modalContentStyle = {
    backgroundColor: theme.card.container.backgroundColor,
    padding: '20px',
    borderRadius: theme.card.container.borderRadius,
    width: '500px',
    textAlign: 'center',
    boxShadow: theme.card.container.boxShadow,
    position: 'relative', // Important for positioning the close button
  };

  const modalHeaderStyle = {
    fontSize: '20px',
    fontWeight: 'bold',
    color: theme.colors.primary,
    marginBottom: '10px',
  };

  const closeButtonStyle = {
    backgroundColor: theme.colors.primary,
    color: theme.colors.secondary,
    border: 'none',
    padding: '10px',
    fontSize: '18px',
    borderRadius: '50%',
    cursor: 'pointer',
    position: 'absolute',
    top: '10px',
    right: '10px',
    width: '30px',
    height: '30px',
    textAlign: 'center',
    lineHeight: '30px',
  };

  const submitButtonStyle = {
    backgroundColor: 'green', // Green color for the submit button
    color: theme.colors.secondary,
    border: 'none',
    padding: '10px',
    fontSize: '18px',
    borderRadius: '4px',
    cursor: 'pointer',
    width: '100%',
  };

  const optionButtonStyle = {
    backgroundColor: theme.colors.primary,
    color: theme.colors.secondary,
    border: 'none',
    padding: '12px 20px',
    fontSize: '16px',
    borderRadius: '4px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    width: '48%', // Adjust width to ensure proper spacing between buttons
  };

  const inputStyle = {
    width: '100%',
    padding: '8px',
    margin: '8px 0',
    fontSize: '16px',
    borderRadius: '4px',
    border: '1px solid #ddd',
    marginBottom: '10px',
  };

  return (
    <div style={modalOverlayStyle}>
      <div style={modalContentStyle}>
        <h3 style={modalHeaderStyle}>Choose Action</h3>
        {!isSingleUpload && !isBulkUpload ? (
          <div style={buttonContainerStyle}>
            <button onClick={handleSingleUploadClick} style={optionButtonStyle}>
              Single Upload
            </button>
            <button onClick={handleBulkUploadClick} style={optionButtonStyle}>
              Bulk Upload
            </button>
          </div>
        ) : null}

        {isSingleUpload ? renderSingleUploadForm() : null}
        {isBulkUpload ? renderBulkUploadOptions() : null}

        <button onClick={handleCloseModal} style={closeButtonStyle}>X</button>
      </div>
    </div>
  );
};

export default OptionModal;
