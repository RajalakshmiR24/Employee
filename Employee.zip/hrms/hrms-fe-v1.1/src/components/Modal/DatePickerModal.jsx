import React, { useState } from 'react';
import theme from '../../style/theme';
import {
  modalStyles,
  modalContentStyles,
  navigationStyles,
  buttonStyles,
  calendarGridStyles,
  emptyCellStyles,
  buttonContainerStyles,
  submitButtonStyles,
  cancelButtonStyles
} from './DatePickerModal.styles';

const DatePickerModal = ({ isOpen, onClose, onDateSelect, selectedCandidateId }) => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  const daysInMonth = (month, year) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (month, year) => new Date(year, month, 1).getDay();

  const handleSelectDate = (day) => {
    const selected = new Date(currentYear, currentMonth, day).toISOString().split('T')[0];
    setSelectedDate(selected); 
  };

  const isSelectedDate = (day) => {
    return selectedDate === new Date(currentYear, currentMonth, day).toISOString().split('T')[0];
  };

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const handleConfirm = () => {
    if (!selectedDate) {
      alert("Please select a date for the interview.");
      return;
    }
  
    onDateSelect(selectedCandidateId, 'RE-SCHEDULED', selectedDate); 
    onClose(); 
  };
  
  if (!isOpen) return null;

  const days = [];
  const totalDays = daysInMonth(currentMonth, currentYear);
  const firstDay = firstDayOfMonth(currentMonth, currentYear);
  for (let i = 1; i <= totalDays; i++) {
    const day = i;
    const isPast = new Date(currentYear, currentMonth, day) < new Date();
    days.push(
      <button
        key={i}
        onClick={() => handleSelectDate(day)}
        disabled={isPast} 
        style={{
          padding: theme.select.select.padding,
          margin: '5px',
          backgroundColor: isSelectedDate(day) ? theme.colors.selectedBackground : '',
          border: isSelectedDate(day)
            ? `2px solid ${theme.colors.selectedBorder}` 
            : `1px solid ${theme.colors.border}`, 
          fontSize: theme.typography.fontSize,
          color: theme.colors.textPrimary,
          cursor: isPast ? 'not-allowed' : 'pointer',
          borderRadius: '4px', 
        }}
      >
        {day}
      </button>
    );
  }

  return (
    <div style={modalStyles}>
      <div style={modalContentStyles}>
        <h3 style={{ fontSize: theme.typography.headingFontSize, color: theme.colors.primary }}>
          Select Interview Date
        </h3>
        <div style={navigationStyles}>
          <button onClick={handlePrevMonth} style={buttonStyles}>Previous</button>
          <span style={{ fontSize: theme.typography.fontSize }}>
            {`${new Date(currentYear, currentMonth).toLocaleString('default', { month: 'long' })} ${currentYear}`}
          </span>
          <button onClick={handleNextMonth} style={buttonStyles}>Next</button>
        </div>
        <div style={calendarGridStyles}>
          {Array.from({ length: firstDay }).map((_, index) => (
            <div key={index} style={emptyCellStyles}></div>
          ))}
          {days}
        </div>
        <div style={buttonContainerStyles}>
          {selectedDate && (
            <button
              onClick={handleConfirm}
              style={submitButtonStyles}
            >
              Confirm
            </button>
          )}
          <button onClick={onClose} style={cancelButtonStyles}>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default DatePickerModal;
