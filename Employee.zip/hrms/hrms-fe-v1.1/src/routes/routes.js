import { createBrowserRouter, Navigate } from "react-router-dom";

import CandidateLayout from "../layout/CandidateLayout";
import HRLayout from "../layout/HRLayout";

import NotFound from "../common/NotFound";
import Landing from "../common/Landing";
import Auth from "../auth/Auth";

import CandidateDashboard from "../pages/Candidate_Pages/CandidateDashboard";
import VerificationPage from "../pages/Candidate_Pages/VerificationPage";

import HRDashboard from "../pages/HR_Pages/HRDashboard";
import CandidateList from "../pages/HR_Pages/CandidateList";
import SearchRole from "../components/SearchBox/SearchRole";

import TermsAndConditions from "../components/SearchBox/TermsAndConditions";

import ProtectedRoute from "./ProtectedRoute";
import PublicRoute from "./PublicRoute";
import Task from "../pages/Candidate_Pages/Task";
import TaskLayout from "../layout/TaskLayout";

const candidateRoutes = [
  { index: true, element: <SearchRole /> },
  { path: "welcome", element: <CandidateDashboard /> },
  { path: "terms", element: <TermsAndConditions /> },
];

const hrRoutes = [
  { index: true, element: <HRDashboard /> },
  { path: "candidate-list", element: <CandidateList /> },
];

const candidateRole = "candidate";
const hrRole = "hr";

export default createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/hrms" />,
  },
  {
    path: "/hrms",
    element: <PublicRoute element={<Landing />} />,
  },
  {
    path: "/hrms/auth-start",
    element: <PublicRoute element={<Auth />} />,
  },
  {
    path: "/hrms/status",
    element: (
      <ProtectedRoute role={candidateRole}>
        <VerificationPage />
      </ProtectedRoute>
    ),
  },
  {
    path: "/hrms/candidate",
    element: (
      <ProtectedRoute role={candidateRole}>
        <CandidateLayout />
      </ProtectedRoute>
    ),
    children: candidateRoutes,
  },
  {
    path: "/hrms/hr",
    element: (
      <ProtectedRoute role={hrRole}>
        <HRLayout />
      </ProtectedRoute>
    ),
    children: hrRoutes,
  },
  {
    path: "/hrms/candidate-task",
    element: (
      <ProtectedRoute role={candidateRole}>
        <TaskLayout />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <Task /> },
    ],
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);
