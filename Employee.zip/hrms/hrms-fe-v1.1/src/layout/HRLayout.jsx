import React from 'react';
import { Outlet } from 'react-router-dom';
import HrNavbar from '../components/Navbar/HR_Navbar';

const Layout = () => {
  return (
    <div>
      <HrNavbar />
      <div style={{ padding: '20px' }}>
        <Outlet />
      </div>
    </div>
  );
};

export default Layout;
