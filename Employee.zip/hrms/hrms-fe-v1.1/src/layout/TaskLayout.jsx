import React, { useState } from 'react';
import TaskNavbar from '../components/Navbar/TaskHeader';
import TaskSidebar from '../components/Navbar/TaskSidebar';
import { Outlet } from 'react-router-dom';

const TaskLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <TaskNavbar toggleSidebar={toggleSidebar} />
      <div style={{ display: 'flex', flex: 1 }}>
        {isSidebarOpen && (
          <div style={{ width: '250px', backgroundColor: '#f4f4f4' }}>
            <TaskSidebar />
          </div>
        )}
        <div style={{ flex: 1 }}>
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default TaskLayout;
