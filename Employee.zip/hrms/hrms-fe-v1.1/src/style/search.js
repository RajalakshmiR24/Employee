
const styles = {
    searchContainer: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '20px',
        gap: '10px',
    },
    searchInput: {
        padding: '10px 20px',
        borderRadius: '30px',
        border: '1px solid #dcdcdc',
        outline: 'none',
        fontSize: '16px',
        width: '100%',
        maxWidth: '350px',
        transition: 'all 0.3s ease',
        backgroundColor: '#fff',
    },
    searchButton: {
        backgroundColor: '#1e275a',  
        color: '#fff',               
        padding: '10px 15px',
        fontSize: '18px',
        border: 'none',
        borderRadius: '50%',
        cursor: 'pointer',
        transition: 'background-color 0.3s',
    },
};

export default styles;
