import theme from '../../style/theme';

const modalStyles = {
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: 'rgba(0, 0, 0, 0.5)',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
};

const modalContentStyles = {
  backgroundColor: theme.card.container.backgroundColor,
  padding: theme.card.container.padding,
  borderRadius: theme.card.container.borderRadius,
  textAlign: 'center',
  maxWidth: '600px',
  width: '100%',
};

const navigationStyles = {
  marginBottom: '10px',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
};

const buttonStyles = {
  padding: '8px 12px',
  fontSize: theme.typography.fontSize,
  backgroundColor: theme.colors.primary,
  color: theme.colors.secondary,
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
  transition: 'background-color 0.3s',
};

const calendarGridStyles = {
  display: 'grid',
  gridTemplateColumns: 'repeat(7, 1fr)',
  gap: '5px',
  margin: '10px 0',
};

const emptyCellStyles = {
  visibility: 'hidden',
};

const buttonContainerStyles = {
  marginTop: '20px',
  display: 'flex',
  justifyContent: 'space-between',
};

const submitButtonStyles = {
  backgroundColor: theme.colors.primary,
  color: theme.colors.secondary,
  padding: '12px 20px',
  fontSize: theme.typography.fontSize,
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
  transition: 'background-color 0.3s',
};

const cancelButtonStyles = {
  backgroundColor: '#ccc',
  color: '#333',
  padding: '12px 20px',
  fontSize: theme.typography.fontSize,
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
  transition: 'background-color 0.3s',
};

export {
  modalStyles,
  modalContentStyles,
  navigationStyles,
  buttonStyles,
  calendarGridStyles,
  emptyCellStyles,
  buttonContainerStyles,
  submitButtonStyles,
  cancelButtonStyles
};
