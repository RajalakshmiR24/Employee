import theme from './theme';

export const headerStyles = {
  container: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 20px',
    backgroundColor: theme.colors.secondary,
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
  left: {
    display: 'flex',
    gap: '10px',
  },
  button: {
    padding: '8px 16px',
    backgroundColor: theme.colors.primary,
    color: theme.colors.secondary,
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  center: {
    textAlign: 'center',
  },
  right: {
    fontSize: '24px',
    cursor: 'pointer',
  },
  icon: {
    color: theme.colors.primary,
  },
};

export const formStyles = {
  container: {
    backgroundColor: theme.colors.secondary,
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    maxWidth: '500px',
    margin: '0 auto',
  },
  input: {
    width: '90%',
    padding: '8px',
    marginBottom: '10px',
    borderRadius: '4px',
    border: `3px solid ${theme.colors.border}`,
    fontSize: theme.typography.fontSize,
  },
  label: {
    fontSize: theme.typography.fontSize,
    fontWeight: 'bold',
    color: theme.colors.textPrimary,
    marginBottom: '5px',
  },
  submitButton: {
    backgroundColor: theme.colors.primary,
    color: theme.colors.secondary,
    padding: '12px 20px',
    fontSize: theme.typography.fontSize,
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
};
