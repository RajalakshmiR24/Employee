import React, { useEffect, useState, useCallback } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import { FaPlusCircle } from 'react-icons/fa';
import theme from '../../style/theme';
import CandidateDetailsModal from '../../components/Modal/CandidateDetails_Modal';
import moment from 'moment';
import OptionModal from '../../components/Modal/OptionModal';
import UploadModal from '../../components/Modal/uploadModal';
import ExcelDataModal from '../../components/Modal/ExcelDataModal';
import * as XLSX from 'xlsx';
import styles from '../../style/search';

const CandidateList = () => {
  const [candidates, setCandidates] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [timeline,] = useState('TODAY');
  const [candidateStatuses, setCandidateStatuses] = useState([]);
  const [jobStatuses, setJobStatuses] = useState([]);
  const [isHovered, setIsHovered] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCandidateDetailsModal, setIsCandidateDetailsModal] = useState(false);


  const [isOptionModal, setIsOptionModal] = useState(false);
  const [excelData, setExcelData] = useState(null);
  const [typeError, setTypeError] = useState(null);
  const [, setExcelFile] = useState(null);
  const [isExcelDataModalOpen, setIsExcelDataModalOpen] = useState(false);
  const [timelineFilter, setTimelineFilter] = useState('new');




  const fetchCandidates = useCallback(async () => {
    try {
      const response = await axiosInstance.post('/api/hrms/hr/all-candidates');
      const { code, message } = response.data;

      if (code === 200) {

      } else if (code === 201) {
        alert('success: ' + message);
      } else {
        alert('Error: ' + message);
      }

      const fetchedCandidates = response.data.data;

      const filteredCandidates = fetchedCandidates.filter(candidate => {
        return (
          (searchQuery ? candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) : true) ||
          (searchQuery ? candidate.phone_number.includes(searchQuery) : true)
        );
      });


      setCandidates(filteredCandidates);
    } catch (error) {
      console.error('Error fetching candidates:', error);

      if (error.response) {
        console.error('Error Response:', error.response.data);
        console.error('Error Status:', error.response.status);
        console.error('Error Headers:', error.response.headers);
      } else {
        console.error('Error Details:', error.message);
      }
    }
  }, [searchQuery,]);

  useEffect(() => {
    fetchCandidates();
  }, [fetchCandidates]);


  useEffect(() => {
    const fetchRoleStatuses = async () => {
      try {
        const response = await axiosInstance.post('/api/hrms/hr/roles-status');

        const { available_candidate_statuses, available_job_statuses } = response.data;


        if (timeline === 'TODAY') {
          setCandidateStatuses(available_candidate_statuses.filter(status => ['PRESENT', 'ABSENT', 'WAITING', 'RE-SCHEDULED'].includes(status)));
          setJobStatuses(available_job_statuses.filter(status => ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'].includes(status)));
        } else if (timeline === 'UPCOMING') {
          setCandidateStatuses(available_candidate_statuses.filter(status => ['WAITING'].includes(status)));
          setJobStatuses(available_job_statuses.filter(status => ['IN_PROGRESS'].includes(status)));
        } else if (timeline === 'PREVIOUS') {
          setCandidateStatuses(available_candidate_statuses.filter(status => ['PRESENT', 'ABSENT', 'RE-SCHEDULED'].includes(status)));
          setJobStatuses(available_job_statuses.filter(status => ['COMPLETED', 'HIRED', 'SELECTED', 'REJECTED', 'IN_PROGRESS'].includes(status)));
        }

      } catch (err) {
        console.error('Error fetching roles and statuses:', err);
      }
    };

    fetchRoleStatuses();
  }, [timeline]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleUpload = () => {
    setIsModalOpen(true);
    setIsOptionModal(false);
  };
  const handleNewSheet = () => {
    alert('New Sheet option selected');
    setIsModalOpen(false);
  };
  const handleFileChange = (e) => {
    const fileTypes = [
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv',
    ];

    const selectedFile = e.target.files[0];

    if (selectedFile) {
      if (fileTypes.includes(selectedFile.type)) {
        setTypeError(null);
        let reader = new FileReader();
        reader.readAsArrayBuffer(selectedFile);
        reader.onload = (e) => {
          setExcelFile(e.target.result);
          parseExcelData(e.target.result);
        };
      } else {
        setTypeError('Please select only excel file types');
        setExcelFile(null);
      }
    }
  };

  const parseExcelData = (fileContent) => {
    try {
      const workbook = XLSX.read(fileContent, { type: 'buffer' });
      const worksheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[worksheetName];
      const data = XLSX.utils.sheet_to_json(worksheet);


      const invalidDates = [];
      data.forEach((record, index) => {
        let walkinDate = record.walkin_date;


        if (!isNaN(walkinDate)) {
          walkinDate = XLSX.SSF.format('DD-MM-YYYY', walkinDate);
        }


        if (!moment(walkinDate, 'DD-MM-YYYY', true).isValid()) {
          invalidDates.push({
            index: index + 1,
            record,
            error: `Invalid date format for walkin_date: ${walkinDate}. Expected format: DD-MM-YYYY.`,
          });
        } else {

          record.walkin_date = walkinDate;
        }
      });

      if (invalidDates.length > 0) {

        setTypeError(invalidDates.map(item => `${item.error}`).join('\n'));
        return;
      }

      setExcelData(data);
      setIsExcelDataModalOpen(true);

    } catch (error) {
      console.error('Error parsing the file:', error);
      setTypeError('Error parsing the Excel file');
    }
  };


  const handleSubmit = async () => {
    try {

      const config = {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      };

      const response = await axiosInstance.post('/api/hrms/hr/upload-excel', {
        excelData,
      }, config);

      const { successCount, errors, message } = response.data;

      alert(message || "Data processing complete.");

      if (successCount > 0) {
        alert(`Data saved successfully! \nSuccess: ${successCount} records.\n${message || ""}`);
      }

      if (errors.length > 0) {
        const errorMessages = errors
          .map((error, index) =>
            `Record ${index + 1} - ${error.record.name} (Phone: ${error.record.phone_number})\nError: ${error.error}`
          )
          .join("\n");

        alert(`Some records failed to save:\n${errorMessages}\nMessage: ${message || ""}`);
      }

      if (!successCount && errors.length === 0) {
        alert(`Response Message: ${message || "No records processed."}`);
      }

      fetchCandidates();

    } catch (error) {
      if (error.response && error.response.data && error.response.data.message) {
        const errorMessage = error.response.data.message;
        alert(`Error: ${errorMessage}`);
      } else if (error.message) {
        alert(`Unexpected Error: ${error.message}`);
      } else {
        alert('An unexpected error occurred.');
      }
      console.error("Error during file upload:", error);
    }
  };



  const handleCandidateClick = (candidate) => {
    setSelectedCandidate(candidate);
    setIsCandidateDetailsModal(true);
  };

  const handleCloseModal = () => {
    setSelectedCandidate(null);
    setIsModalOpen(false);
    setIsCandidateDetailsModal(false)
    setIsOptionModal(false);
    setIsExcelDataModalOpen(false)

  };

  const handleCandidateStatusChange = async (candidateId, newStatus) => {
    try {
      const candidate = candidates.find(candidate => candidate.candidate_id === candidateId);

      if (!candidate) {
        console.error('Candidate not found');
        return;
      }


      if (newStatus === 'RE-SCHEDULED' && candidate.candidate_Status === 'WAITING') {
        const walkinDate = prompt('Please provide the walkin date for re-scheduling (YYYY-MM-DD):');
        if (!walkinDate) {
          console.error('Walkin date is required');
          return;
        }

        const selectedDate = new Date(walkinDate);
        const currentDate = new Date();

        if (selectedDate <= currentDate) {
          console.error('The re-scheduled walkin date must be in the future and cannot be today or in the past.');
          return;
        }


        const response = await axiosInstance.post('/api/hrms/hr/candidate-status', {
          candidate_id: candidate.candidate_id,
          candidate_Status: newStatus,
          job_Status: candidate.job_Status,
          timeline: candidate.timeline,
          walkin_date: walkinDate,
        });

        if (response.data && response.data.message) {
          alert(response.data.message);
        }

        setCandidates((prevCandidates) =>
          prevCandidates.map(candidate =>
            candidate.candidate_id === candidateId
              ? { ...candidate, candidate_Status: newStatus, walkin_date: walkinDate }
              : candidate
          )
        );

        fetchCandidates();
      }
    } catch (error) {
      console.error('Error updating candidate status:', error);
      alert('An error occurred while updating the status. Please try again.');
    }
  };


  const handleJobStatusChange = async (candidateId, newStatus) => {
    try {
      const candidate = candidates.find(candidate => candidate.candidate_id === candidateId);

      if (!candidate) {
        console.error('Candidate not found');
        return;
      }

      let jobStatusDescription = '';
      let interviewDate = '';



      if (newStatus === 'REJECTED') {
        jobStatusDescription = prompt('Please provide a reason for rejection:');
        if (!jobStatusDescription) {
          console.error('Rejection description is required');
          return;
        }
      }

      const response = await axiosInstance.post('/api/hrms/hr/candidate-status', {
        candidate_id: candidate.candidate_id,
        candidate_Status: candidate.candidate_Status,
        job_Status: newStatus,
        timeline: candidate.timeline,
        description: jobStatusDescription,
        walkin_date: interviewDate,
      });

      alert(response.data.message);

      if (response.data.code === 200) {
        setCandidates((prevCandidates) =>
          prevCandidates.map(candidate =>
            candidate.candidate_id === candidateId
              ? { ...candidate, job_Status: newStatus, job_Status_Description: jobStatusDescription, scheduled_date: interviewDate }
              : candidate
          )
        );
      } else {
        console.error('Error from backend:', response.data.message);
      }

      fetchCandidates();
    } catch (error) {
      console.error('Error updating job status:', error);
    }
  };


  const handleOptionClick = () => {
    setIsOptionModal(true);
    fetchCandidates();
  };

  const handleNewTable = () => {
    setTimelineFilter('new');
    fetchCandidates();
  };

  const handleOldTable = () => {
    setTimelineFilter('old');
  };


  const filteredCandidates = candidates.filter((candidate) => {
    if (timelineFilter === 'old') {
      return candidate.timeline === 'PREVIOUS';
    } else if (timelineFilter === 'new') {
      return candidate.timeline === 'UPCOMING' || candidate.timeline === 'TODAY';
    }
    return true;
  });

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div>
          <button
            onClick={handleOldTable}
            style={{
              ...theme.form.submitButton,
              backgroundColor: theme.colors.primary,
            }}
            onMouseEnter={(e) => (e.target.style.backgroundColor = theme.form.submitButtonHover.backgroundColor)}
            onMouseLeave={(e) => (e.target.style.backgroundColor = theme.colors.primary)}
          >
            Old Candidate
          </button>
          <button
            onClick={handleNewTable}
            style={{
              ...theme.form.submitButton,
              backgroundColor: theme.colors.primary,
            }}
            onMouseEnter={(e) => (e.target.style.backgroundColor = theme.form.submitButtonHover.backgroundColor)}
            onMouseLeave={(e) => (e.target.style.backgroundColor = theme.colors.primary)}
          >
            New Candidate
          </button>
        </div>

        <div style={styles.searchContainer}>
          <input
            type="text"
            placeholder="Search by Name and Mobile"
            value={searchQuery}
            onChange={handleSearchChange}
            style={styles.searchInput}
          />
          <button
            onClick={handleOptionClick}
            style={styles.searchButton}
            onMouseEnter={(e) => (e.target.style.backgroundColor = theme.form.submitButtonHover.backgroundColor)}
            onMouseLeave={(e) => (e.target.style.backgroundColor = theme.colors.primary)}
          >
            <FaPlusCircle />
          </button>
        </div>
      </div>

      <br />
      <div>
        <table style={theme.table.table}>
          <thead>
            <tr>
              <th style={theme.table.th}>#</th>
              <th style={theme.table.th}>Name</th>
              <th style={theme.table.th}>Mobile Number</th>
              {timelineFilter !== 'old' && <th style={theme.table.th}>Scheduled Date</th>}
              <th style={theme.table.th}>Walkin Date</th>
              <th style={theme.table.th}>Timeline</th>
              <th style={theme.table.th}>Role</th>
              <th style={theme.table.th}>Candidate Status</th>
              <th style={theme.table.th}>Job Status</th>
              <th style={theme.table.th}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredCandidates.map((candidate, index) => (
              <tr key={candidate.candidate_id} style={theme.table.trHover}>
                <td style={theme.table.td}>{index + 1}</td>
                <td style={theme.table.td}>{candidate.name} </td>
                <td style={theme.table.td}>{candidate.phone_number}</td>
                {timelineFilter !== 'old' && (
                  <td style={theme.table.td}>
                    {candidate.timeline === 'UPCOMING' || candidate.timeline === 'TODAY' ? (
                      new Date(candidate.scheduled_date).toLocaleDateString()
                    ) : (
                      'N/A'
                    )}
                  </td>
                )}
                <td style={theme.table.td}>{candidate.walkin_date}</td>
                <td style={theme.table.td}>{candidate.timeline}</td>
                <td style={theme.table.td}>{candidate.job_role || 'N/A'}</td>
                <td style={theme.table.td}>
                  <select
                    value={candidate.candidate_Status}
                    onChange={(e) => handleCandidateStatusChange(candidate.candidate_id, e.target.value)}
                    style={{
                      ...theme.select.select,
                      ...(isHovered ? theme.select.selectHover : {}),
                      ...(isFocused ? theme.select.selectFocus : {}),
                    }}
                    onFocus={() => setIsFocused(true)}
                    onBlur={() => setIsFocused(false)}
                    onMouseEnter={() => setIsHovered(true)}
                    onMouseLeave={() => setIsHovered(false)}
                  >
                    {candidateStatuses.map((status) => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                </td>

                <td style={theme.table.td}>
                  <select
                    value={candidate.job_Status}
                    onChange={(e) => handleJobStatusChange(candidate.candidate_id, e.target.value)}
                    style={{
                      ...theme.select.select,
                      ...(isHovered ? theme.select.selectHover : {}),
                      ...(isFocused ? theme.select.selectFocus : {}),
                    }}
                    onFocus={() => setIsFocused(true)}
                    onBlur={() => setIsFocused(false)}
                    onMouseEnter={() => setIsHovered(true)}
                    onMouseLeave={() => setIsHovered(false)}
                  >
                    {jobStatuses.map((status) => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                </td>

                <td style={theme.table.td}>
                  <button
                    onClick={() => handleCandidateClick(candidate)}
                    style={{
                      backgroundColor: theme.colors.primary,
                      color: theme.colors.secondary,
                      padding: '8px 16px',
                      fontSize: '16px',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontFamily: theme.typography.fontFamily,
                      transition: 'background-color 0.3s',
                    }}
                  >
                    View
                  </button>
                </td>



              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isCandidateDetailsModal && (
        <CandidateDetailsModal candidate={selectedCandidate} onClose={handleCloseModal}
          handleCandidateClick={handleCandidateClick}
          fetchCandidates={fetchCandidates}
        />
      )}


      {isOptionModal && (
        <OptionModal
          handleUpload={handleUpload}
          handleNewSheet={handleNewSheet}
          handleCloseModal={handleCloseModal}
          fetchCandidates={fetchCandidates}

        />
      )}

      {isModalOpen && !isOptionModal && (
        <UploadModal
          handleFileChange={handleFileChange}
          typeError={typeError}
          handleCloseModal={handleCloseModal}

        />
      )}


      {isExcelDataModalOpen && (
        <ExcelDataModal
          excelData={excelData}
          setIsExcelDataModalOpen={setIsExcelDataModalOpen}
          handleSubmit={handleSubmit}

        />
      )}
    </div>
  );
};

export default CandidateList;
