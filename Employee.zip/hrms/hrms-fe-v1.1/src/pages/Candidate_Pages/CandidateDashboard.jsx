import React, { useState } from 'react';
import theme from '../../style/theme';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosInstance'; 



const Status = ({ message }) => {
  return (
    <div>
      {message && <p style={{ color: theme.colors.textPrimary, textAlign: 'center' }}>{message}</p>}
    </div>
  );
};

const PipelineStep = ({ stepNumber, label, completed, status }) => {
  return (
    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
      <div
        style={{
          width: '30px',
          height: '30px',
          borderRadius: '50%',
          backgroundColor: completed ? theme.colors.primary : '#ccc',
          color: 'white',
          textAlign: 'center',
          lineHeight: '30px',
          fontWeight: 'bold',
          marginRight: '10px',
        }}
      >
        {stepNumber}
      </div>
      <span>{label}</span>
      {completed && <span style={{ marginLeft: '10px', color: theme.colors.primary }}>Completed</span>}
      {status && <span style={{ marginLeft: '10px', color: theme.colors.secondary }}>{status}</span>}
    </div>
  );
};

const CandidateDashboard = () => {
  const [resumeFile, setResumeFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState('');
  const [resumeUploaded, setResumeUploaded] = useState(false);
  const [kycUploaded, setKycUploaded] = useState(false);
  const navigate = useNavigate();


  const handleResumeFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setResumeFile(selectedFile);
    }
  };

  const handleResumeSubmit = async (e) => {
    e.preventDefault();
  
    if (!resumeFile) {
      setMessage('Please select a resume file to upload.');
      return;
    }

  
    const reader = new FileReader();
    setUploading(true);
    setMessage('');
  
    try {
      reader.onloadend = async () => {
        const fileData = reader.result.split(',')[1]; 
        const fileContentType = resumeFile.type;
        const fileName = resumeFile.name;
  
        const payload = {
          filename: fileName,
          contentType: fileContentType,
          data: fileData,
           
        };
  
        try {
          const endpoint = '/api/hrms/candidate/upload-resume'; 
          const response = await axiosInstance.post(endpoint, payload, {
            headers: {
              'Content-Type': 'application/json',
            },
          });
  
          setUploading(false);
  
          if (response.data.code === 201) {
            setMessage('Resume uploaded successfully!');
            setResumeUploaded(true);
          } else {
            setMessage('Error uploading resume. Please try again.');
          }
        } catch (error) {
          setUploading(false);
          setMessage('Error uploading resume. Please try again.');
          console.error('Upload error:', error);
        }
      };
  
      reader.onerror = () => {
        setUploading(false);
        setMessage('Error reading the file.');
      };
  
      reader.readAsDataURL(resumeFile); 
    } catch (error) {
      setUploading(false);
      setMessage('Error processing the file.');
      console.error('Error processing the file:', error);
    }
  };
  

  const handleKycSubmit = async (e) => {
    e.preventDefault();

    
    
    navigate('/hrms/candidate/terms');
    setKycUploaded(true);
  };

  return (
    <div>
      <h1 style={{ textAlign: 'center' }}>Candidate Dashboard</h1>

      <Status message={message} />

      <div style={{ marginBottom: '20px' }}>
        <PipelineStep
          stepNumber={1}
          label="Upload Resume"
          completed={resumeUploaded}
        />
        <PipelineStep
          stepNumber={2}
          label="KYC Verification"
          completed={kycUploaded}
        />
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', gap: '20px', flexWrap: 'wrap' }}>
        <div
          style={{
            flex: '1 1 calc(50% - 10px)',
            minWidth: '280px',
            ...theme.form.container,
            display: resumeUploaded ? 'none' : 'block',
          }}
        >
          <h1 style={{ fontSize: theme.typography.headingFontSize, color: theme.colors.primary }}>Upload Resume</h1>
          <form onSubmit={handleResumeSubmit}>
            <div>
              <label htmlFor="resumeFileInput" style={theme.form.label}>Select a resume file:</label>
              <input
                type="file"
                id="resumeFileInput"
                onChange={handleResumeFileChange}
                accept=".pdf,.doc,.docx,.jpeg,.jpg"
                style={theme.form.input}
              />
            </div>
            <div>
              <button
                type="submit"
                disabled={uploading}
                style={{
                  ...theme.form.submitButton,
                  backgroundColor: uploading ? '#ccc' : theme.colors.primary,
                }}
              >
                {uploading ? 'Uploading...' : 'Upload Resume'}
              </button>
            </div>
          </form>
        </div>

        <div
          style={{
            flex: '1 1 calc(50% - 10px)',
            minWidth: '280px',
            ...theme.form.container,
            display: resumeUploaded && !kycUploaded ? 'block' : 'none',
          }}
        >
          <form onSubmit={handleKycSubmit}>
            <div>
              <button
                type="submit"
                disabled={uploading}
                style={{
                  ...theme.form.submitButton,
                  
                }}
              >
                {uploading ? 'Uploading...' : 'KYC Verification'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CandidateDashboard;
