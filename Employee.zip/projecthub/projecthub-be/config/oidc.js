// ../config/oidc.js
const { Issuer } = require('openid-client');


const setupOIDC = async () => {
  try {

    const oidcIssuer = await Issuer.discover(process.env.OIDC_ISSUER);
    // console.log("oidcIssuer", oidcIssuer);
    
    const client = new oidcIssuer.Client({
      client_id: process.env.OIDC_CLIENT_ID,
      client_secret: process.env.OIDC_CLIENT_SECRET,
      redirect_uris: [process.env.OIDC_REDIRECT_URI],
      post_logout_redirect_uris: process.env.OIDC_POST_LOGOUT,
      response_types: ['code'],
    });
    // console.log(client, "Client +++++++++++++++");
    return client;
  } catch (error) {
    console.error('Error discovering OIDC issuer:', error.message);
    throw error;
  }
};

module.exports = setupOIDC;
