const mongoose = require("mongoose");

const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URL, {
            serverSelectionTimeoutMS: 30000,
            socketTimeoutMS: 45000
        });
        mongoose.set('strictPopulate', false); 

        console.log("MongoDB Connected");
    } catch (error) {
        return next(error.message);    }
}

module.exports = connectDB;