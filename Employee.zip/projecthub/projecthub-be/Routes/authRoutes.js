
const express = require('express');
const passport = require('passport');
const authController = require('../Controllers/authController');
const superAdminController = require('../Controllers/superAdminController'); 
const {findRoleByHash, verifyToken }= require('../Middlewares/auth');


const authRouter = express.Router();


authRouter.get('/start',
  authController.login,
  passport.authenticate('oidc', {
    scope: "openid refresh_token",
  }),
  authController.authenticate 
);


authRouter.get('/projecthub-logout',
  authController.logout,
  passport.authenticate('oidc', {
    scope: "openid refresh_token",
  }),
);

authRouter.post('/projecthub-verify', 
  passport.authenticate('oidc'), 
  (req, res, next) => {
    next();
  },
  authController.verifySession
);


authRouter.post('/get-role',findRoleByHash, authController.checkRole);
authRouter.post('/get-details',findRoleByHash, authController.getRoleDetails);

// authRouter.post('/get-role',verifyToken, authController.checkRole);
// authRouter.post('/get-details',verifyToken, authController.getRoleDetails);
authRouter.post('/create-superAdmin', superAdminController.createSuperAdmin);

module.exports = authRouter;
