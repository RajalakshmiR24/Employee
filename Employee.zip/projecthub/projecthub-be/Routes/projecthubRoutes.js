const express = require('express');
const projecthubRouter = express.Router();
const authRouter = require('../Routes/authRoutes');
const superAdminRouter = require('../Routes/superAdminRoutes');
const userRouter = require('../Routes/userRoutes');
const adminRouter = require('../Routes/adminRoutes');
const clientRouter = require('../Routes/clientRoutes');

projecthubRouter.use('/auth', authRouter);
projecthubRouter.use('/superadmin', superAdminRouter);
projecthubRouter.use('/user', userRouter);
projecthubRouter.use('/admin', adminRouter);
projecthubRouter.use('/client', clientRouter);

module.exports = projecthubRouter;


