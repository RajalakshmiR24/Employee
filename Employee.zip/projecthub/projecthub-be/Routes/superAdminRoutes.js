const express = require('express');
const superAdminController = require('../Controllers/superAdminController');
const userController = require('../Controllers/userController');
const commonController = require('../Controllers/common/commonController');
const teamController = require('../Controllers/teamController');
const taskController = require('../Controllers/taskController');
const projectController = require('../Controllers/projectController');
const { findRoleByHash, checkSuperAdmin, verifyToken } = require('../Middlewares/auth');

const superAdminRouter = express.Router();


// Middlewares
superAdminRouter.use(findRoleByHash); 
// superAdminRouter.use(verifyToken); 

superAdminRouter.use(checkSuperAdmin);
//dashboard
superAdminRouter.post('/dashboard', commonController.getDashboardCounts);

//common
superAdminRouter.post('/all-entities', commonController.getAllByRole);


// ==================
// SuperAdmin Controller Routes
// ==================



//positions

superAdminRouter.post('/create-position', commonController.createPosition);
superAdminRouter.post('/all-positions', commonController.getAllPositions);
superAdminRouter.post('/assign-position', commonController.assignPosition);


superAdminRouter.post('/profile', superAdminController.getSuperAdminById);
superAdminRouter.post('/verify-admin', superAdminController.manageAdmins);
superAdminRouter.post('/create', superAdminController.createUserAdminClient);
superAdminRouter.post('/add-datas', superAdminController.handleExcelUploadBySuperAdmin);

superAdminRouter.post('/columns', commonController.getAllColumns);


// ==================
// Team Controller Routes
// ==================

superAdminRouter.post('/create-team', teamController.createTeam);
superAdminRouter.post('/teams', teamController.getAllTeams);
superAdminRouter.post('/delete-team', teamController.deleteTeam);
superAdminRouter.put('/updates', teamController.updateTeam);

// ==================
// Task Controller Routes
// ==================

superAdminRouter.post('/tasks', taskController.getAllTasks);
superAdminRouter.post('/task-name', taskController.getAllTasksIdsAndNames);

// ==================
// Project Controller Routes
// ==================

superAdminRouter.post('/projects', projectController.getAllProjects);
superAdminRouter.post('/project-name', projectController.getAllProjectsIdsAndNames);

// comment
superAdminRouter.post('/add-comment', taskController.addComment);
superAdminRouter.post('/allcomments', taskController.getComments);

// Get all user IDs and Names
superAdminRouter.post('/user-name', userController.getAllUserIdsAndNames);

// get all organization wise list

superAdminRouter.post('/all-org', superAdminController.getAllOrganizations);

module.exports = superAdminRouter;
