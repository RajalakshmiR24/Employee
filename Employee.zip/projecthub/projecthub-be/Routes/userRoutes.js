const express = require('express');
const userRouter = express.Router();
const userController = require('../Controllers/userController'); 
const teamController = require('../Controllers/teamController'); 
const projectController = require('../Controllers/projectController'); 
const taskController = require('../Controllers/taskController'); 
const commonController = require('../Controllers/common/commonController');

const { findRoleByHash, checkUser, verifyToken,  } = require('../Middlewares/auth');
userRouter.use(findRoleByHash); 
// userRouter.use(verifyToken); 

userRouter.use(checkUser); 


userRouter.post('/profile',userController.getUserById);
userRouter.post('/position',userController.getUserPosition);
userRouter.post('/accept-position',userController.acceptPosition);

//teams
userRouter.post('/assigned-teams', teamController.getAllAssignedTeams);

//projects
userRouter.post('/project_id', projectController.getProjectDetailsById);


//tasks
userRouter.post('/assigned-tasks', taskController.getAllAssignedTasks);
userRouter.post('/tasks', taskController.getAllTasks);
userRouter.post('/change-status', taskController.changeTaskStatus);

userRouter.post('/columns', commonController.getAllColumns);

// comment
userRouter.post('/add-comment', taskController.addComment);
userRouter.post('/allcomments', taskController.getComments);

module.exports = userRouter;


