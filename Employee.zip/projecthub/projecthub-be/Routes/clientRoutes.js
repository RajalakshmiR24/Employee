const express = require('express');
const clientRouter = express.Router();
const clientController = require('../Controllers/ClientController'); 
const taskController = require('../Controllers/taskController'); 
const commonController = require('../Controllers/common/commonController');


const { findRoleByHash, checkUser, verifyToken, checkClient } = require('../Middlewares/auth');

clientRouter.use(findRoleByHash); 
// clientRouter.use(verifyToken); 

clientRouter.use(checkClient); 



clientRouter.post('/profile',clientController.getClientById);
clientRouter.post('/client-projects',clientController.viewAccessedProjects);

clientRouter.post('/tasks', taskController.getAllTasks);
clientRouter.post('/columns', commonController.getAllColumns);
//comments
clientRouter.post('/add-comment', taskController.addComment);
clientRouter.post('/allcomments', taskController.getComments);

module.exports = clientRouter;


