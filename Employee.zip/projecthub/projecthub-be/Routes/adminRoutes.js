const express = require('express');
const adminRouter = express.Router();
const adminController = require('../Controllers/adminController'); 
const teamController = require('../Controllers/teamController'); 
const taskController = require('../Controllers/taskController');
const userController = require('../Controllers/userController');
const projectController = require('../Controllers/projectController');

const commonController = require('../Controllers/common/commonController');


const { findRoleByHash, checkAdmin, verifyToken } = require('../Middlewares/auth');

adminRouter.use(findRoleByHash); 
// adminRouter.use(verifyToken); 

adminRouter.use(checkAdmin); 

//dashboard
adminRouter.post('/dashboard', commonController.getDashboardCounts);

//common
adminRouter.post('/all-entities', commonController.getAllByRole);


// Admin-related routes
adminRouter.post('/profile', adminController.getAdminById);
adminRouter.post('/create', adminController.createUserClient);


adminRouter.post('/create-position', commonController.createPosition);
adminRouter.post('/all-positions', commonController.getAllPositions);
adminRouter.post('/assign-position', commonController.assignPosition);


adminRouter.post('/task', adminController.createTaskAdmin);
adminRouter.post('/add-datas', adminController.handleExcelUploadByAdmin);

//columns

adminRouter.post('/create-column', adminController.createColumn);
adminRouter.put('/column', adminController.updateColumn);
adminRouter.delete('/column', adminController.deleteColumn);

adminRouter.post('/columns', commonController.getAllColumns);

// Team-related routes
adminRouter.post('/create-team', teamController.createTeam);
adminRouter.put('/update-team', teamController.updateTeam);
adminRouter.post('/teams', teamController.getAllTeams);
adminRouter.post('/delete-team', teamController.deleteTeam);
adminRouter.put('/updates', teamController.updateTeam);
adminRouter.post('/team-name', teamController.getAllTeamsIdsAndNames);



adminRouter.post('/create-task', taskController.createTask);
adminRouter.post('/tasks', taskController.getAllTasks);
adminRouter.post('/task-name', taskController.getAllTasksIdsAndNames);

adminRouter.post('/user-name', userController.getAllUserIdsAndNames);

//projects
adminRouter.post('/projects', projectController.getAllProjects);
adminRouter.post('/create-project', projectController.createProject);
adminRouter.delete('/delete-project', projectController.deleteProject);
adminRouter.put('/update-project', projectController.updateProject);
adminRouter.post('/project-name', projectController.getAllProjectsIdsAndNames);
adminRouter.post('/accessProject', projectController.accessProject);


// comment
adminRouter.post('/add-comment', taskController.addComment);
adminRouter.post('/allcomments', taskController.getComments);

module.exports = adminRouter;
