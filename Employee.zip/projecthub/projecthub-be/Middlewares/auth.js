const Token = require('../Models/token');
const Admin = require('../Models/Admin');
const SuperAdmin = require('../Models/SuperAdmin');
const Client = require('../Models/Client');
const User = require('../Models/User');
const axios = require('axios');
const crypto = require("crypto");



exports.verifyToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) {
    return res.status(200).json({ code: 400, message: 'Token is required.' });
  }
  console.log("Received Token:", token);
  try {
    const storedToken = await Token.findOne({ access_token: token });
    if (!storedToken) {
      return res.status(200).json({ code: 404, error: 'Token not found in database.' });
    }
    if (storedToken.used) {
      return res.status(200).json({ code: 403, error: 'This token has already been used and is no longer valid.' });
    }

    
    storedToken.used = true;
    await storedToken.save();

    
    let user = await Token.findOne({ userhash: storedToken.userhash });

    if (!user) {
      return res.status(200).json({ code: 401, error: 'User not found.' });
    }

    const role = storedToken.role || user.role;

    req.user = user;
    req.role = role;

    
    const allowedRoles = ['superAdmin', 'Admin', 'User', 'Client'];

    if (!allowedRoles.includes(role)) {
      return res.status(200).json({ code: 403, error: 'Access denied. Invalid role.' });
    }

    
    if (['superAdmin', 'Admin', 'Client', 'User'].includes(role)) {
      const oidcIssuer = process.env.OIDC_ISSUER_AUTH;
      const externalUrl = `${oidcIssuer}/account/me`;

      try {
        
        const externalResponse = await axios.get(externalUrl, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        req.hash = externalResponse.data.hash;  
        req.externalData = externalResponse.data; 
         
        // console.log(req.externalData,"++++++++++++++++++++++++" )

      } catch (error) {
        console.error('Error fetching from external API:', error.message);
        return res.status(200).json({ code: 500, error: error.message });
      }
    }

    
    next();
  } catch (error) {
    console.error('Error:', error.message);
    return res.status(200).json({ code: 500, error: error.message });
  }
};


exports.checkPhoneNumberExists = async (req, res, next) => {
  const { phone_number } = req.body;

  try {

    const adminExists = await Admin.findOne({ phone_number });
    if (adminExists) {
      return res.status(200).json({ code: 400, error: 'Phone number already exists in Admin' });
    }


    const userExists = await User.findOne({ phone_number });
    if (userExists) {
      return res.status(200).json({ code: 400, error: 'Phone number already exists in User' });
    }


    const clientExists = await Client.findOne({ phone_number });
    if (clientExists) {
      return res.status(200).json({ code: 400, error: 'Phone number already exists in Client' });
    }


    const superAdminExists = await SuperAdmin.findOne({ phone_number });
    if (superAdminExists) {
      return res.status(200).json({ code: 400, error: 'Phone number already exists in SuperAdmin' });
    }


    next();
  } catch (error) {
    return res.status(200).json({ code: 500, error: 'Internal Server Error' });
  }
};

exports.checkAdmin = async (req, res, next) => {
  try {
    const hash = req.hash;

    if (!hash) {
      return res.status(200).json({
        code: 400,
        error: 'Hash is required.',
      });
    }


    let admin = await Admin.findOne({ hash });
    if (!admin) {
      return res.status(200).json({
        code: 403,
        error: 'Only Admin can perform this action',
      });
    }


    if (!admin.isVerifiedBySuperAdmin) {
      return res.status(200).json({
        code: 403,
        error: 'Admin is not verified by SuperAdmin. Access denied.',
      });
    }


    req.admin = admin;
    req.added_by = admin.admin_id;
    req.role = admin.role
    req.name = admin.name



    next();
  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};

exports.checkSuperAdmin = async (req, res, next) => {
  try {
    const hash = req.hash;

    if (!hash) {
      return res.status(200).json({
        code: 400,
        error: 'Hash is required.',
      });
    }

    let superAdmin = await SuperAdmin.findOne({ hash });
    if (!superAdmin || superAdmin.role !== 'superAdmin') {
      return res.status(200).json({
        code: 403,
        error: 'Only superAdmin can perform this action',
      });
    }


    req.superAdmin = superAdmin;
    req.added_by = superAdmin.superAdmin_id;
    req.role = superAdmin.role;
    req.name = superAdmin.name

    

    next();
  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};


exports.checkUser = async (req, res, next) => {
  try {
    const hash = req.hash;

    if (!hash) {
      return res.status(200).json({
        code: 400,
        error: 'Hash is required.',
      });
    }

    let user = await User.findOne({ hash });
    if (!user) {
      return res.status(200).json({
        code: 403,
        error: 'Only User can perform this action',
      });
    }

    req.user = user;
    req.userId = user.user_id;
    req.role = user.role;
    req.name = user.name


    next();
  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};


exports.checkClient = async (req, res, next) => {
  try {
    const hash = req.hash;

    if (!hash) {
      return res.status(200).json({
        code: 400,
        error: 'Hash is required.',
      });
    }

    let client = await Client.findOne({ hash });
    if (!client) {
      return res.status(200).json({
        code: 403,
        error: 'Only client can perform this action',
      });
    }

    req.client = client;
    req.clientId = client.client_id;
    req.role = client.role;
    req.name = client.name


    next();
  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};

exports.findRoleByHash = async (req, res, next) => {
  const userHash = req.headers['user-hash'];

  if (!userHash) {
    return res.status(200).json({ code: 400, error: 'User hash is required.' });
  }

  try {
    let user = await User.findOne({ hash: userHash }) ||
      await Admin.findOne({ hash: userHash }) ||
      await Client.findOne({ hash: userHash }) ||
      await SuperAdmin.findOne({ hash: userHash });

    if (!user) {
      return res.status(200).json({ code: 404, error: 'User not found.' });
    }

    req.hash = user.hash;

    next();
  } catch (error) {
    console.error('Error:', error.message);
    return res.status(200).json({ code: 500, error: error.message });
  }
};


exports.maskId = (id) => {
  const idString = id.toString();
  const idLength = idString.length;

  if (idLength > 8) {
    const middleMask = '*'.repeat(idLength - 8);
    return idString.slice(0, 4) + middleMask + idString.slice(-4);
  } else {
    return idString;
  }
};

exports.maskFields = (obj) => {
  const maskedObj = { ...obj.toObject() };

  ['_id', 'user_id', 'admin_id', 'phone_number', 'created_by', 'client_id', 'hash', 'added_by_admin_id'].forEach(field => {
    if (maskedObj[field]) {
      maskedObj[field] = exports.maskId(maskedObj[field]); 
    }
  });

  return maskedObj;
};


exports.hashPhoneNumber = (phone_number) => {
  return crypto.createHash("sha256").update(phone_number).digest("hex");
};

