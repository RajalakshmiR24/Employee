const Team = require("../Models/Team");
const Admin = require("../Models/Admin");
const SuperAdmin = require("../Models/SuperAdmin");
const mongoose = require('mongoose');
const User = require("../Models/User");
const Client = require("../Models/Client");
const Project = require("../Models/Project");


exports.createTeam = async (req, res) => {
  try {
    const { teamName } = req.body;
    const created_by = req.added_by;
    const role = req.role;

    
    if (!teamName) {
      return res.status(200).json({
        code: 400,
        error: "Team name is required.",
      });
    }

    
    const newTeam = new Team({
      teamName,
      created_by: {
        _id: created_by,
        type: role === 'Admin' ? 'Admin' : 'superAdmin',
        role: role === 'superAdmin' ? role : undefined, 
      },
    });

    
    await newTeam.save();

    
    const user = role === 'Admin' 
      ? await Admin.findOne({ admin_id: created_by }) 
      : await SuperAdmin.findOne({ superAdmin_id: created_by });

    
    if (!user) {
      return res.status(200).json({
        code: 404,
        error: role === 'Admin' ? "Admin not found." : "SuperAdmin not found.",
      });
    }

    
    if (role === 'Admin') {
      user.teams = [newTeam._id]; 
    } else {
      user.teams = [{
        teamName: newTeam.teamName,
        team_id: newTeam._id, 
      }];
    }

    
    await user.save();

    res.status(201).json({
      code: 201,
      message: "Team created successfully",
    });
  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};


exports.updateTeam = async (req, res) => {
  try {
    const {
      teamId,
      teamName,
      memberName,
      superAdmin,
      tasks,
      members,
      projects,
      dueTime,
      projectId,
      projectName,
      userId,
      taskId,
      taskName
    } = req.body;

    if (!teamId) {
      return res.status(200).json({
        code: 400,
        error: "Team ID is required.",
      });
    }

    const updatedTeam = await Team.findOne({ team_id: teamId });

    if (!updatedTeam) {
      return res.status(200).json({
        code: 404,
        error: "Team not found.",
      });
    }

    const oldTeamName = updatedTeam.teamName;

    if (teamName) updatedTeam.teamName = teamName;
    if (superAdmin) updatedTeam.superAdmin = superAdmin;

    if (members && Array.isArray(members)) {
      members.forEach(member => {
        const memberExists = updatedTeam.members.some(m => m.member_id === member.member_id);
        if (!memberExists) {
          updatedTeam.members.push(member);
        }
      });
    } else if (userId) {
      const memberExists = updatedTeam.members.some(m => m.member_id === userId);
      if (!memberExists) {
        updatedTeam.members.push({ member_id: userId, role: 'User', name: memberName });
      }
    }

    if (tasks && Array.isArray(tasks)) {
      tasks.forEach(task => {
        const taskExists = updatedTeam.tasks.some(t => t.task_id === task.task_id);
        if (!taskExists) {
          updatedTeam.tasks.push(task);
        }
      });
    } else if (taskId) {
      const taskExists = updatedTeam.tasks.some(t => t.task_id === taskId);
      if (!taskExists) {
        updatedTeam.tasks.push({ task_id: taskId, taskName: taskName });
      }
    }

    if ((!updatedTeam.projects || updatedTeam.projects.length === 0) && projects && Array.isArray(projects)) {
      updatedTeam.projects = projects;
    } else if (projectId) {
      const projectExists = updatedTeam.projects.some(p => p.project_id === projectId);
      if (!projectExists) {
        updatedTeam.projects.push({ project_id: projectId, projectName: projectName });

        // Update the Project schema with the team information
        const project = await Project.findOne({ project_id: projectId });
        if (project) {
          const teamExists = project.teams.some(t => t.team_id === teamId);
          if (!teamExists) {
            project.teams.push({ team_id: teamId, teamName: updatedTeam.teamName });
            await project.save();
          }
        } else {
          return res.status(200).json({
            code: 404,
            error: "Project not found.",
          });
        }
      }
    }

    if (dueTime && !updatedTeam.dueTime) {
      updatedTeam.dueTime = dueTime;
    }

    await updatedTeam.save();

    if (teamName && oldTeamName !== teamName) {
      await Admin.updateMany(
        { teams: oldTeamName },
        { $set: { "teams.$": teamName } }
      );

      await User.updateMany(
        { teams: oldTeamName },
        { $set: { "teams.$": teamName } }
      );

      await Client.updateMany(
        { teams: oldTeamName },
        { $set: { "teams.$": teamName } }
      );
    }

    await SuperAdmin.updateMany(
      { "teams.team_id": teamId },
      { $pull: { teams: { team_id: teamId } } }
    );

    const currentTime = new Date();
    const dueTimeDate = new Date(updatedTeam.dueTime);
    if (currentTime >= dueTimeDate) {
      return res.status(200).json({
        code:400,
        error: "Due time has passed. Here are the tasks and projects for the team:",
        tasks: updatedTeam.tasks,
        projects: updatedTeam.projects,
      });
    }

    res.status(200).json({
      message: "Team updated successfully",
    });

  } catch (error) {
    console.error("Error updating team:", error);
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};


exports.getAllTeams = async (req, res) => {
  try {
    const createdById = req.added_by; // Admin ID
    const role = req.role; // User role

    if (!createdById && role !== 'superAdmin') {
      return res.status(200).json({code:400,
        error: "Admin ID is required for Admin role",
      });
    }

    let teams;

    if (role === 'superAdmin') {
      // SuperAdmin can see all teams
      teams = await Team.find()
        .select('team_id created_by teamName projects tasks members createdAt updatedAt');
    } else if (role === 'Admin') {
      // Admin can see teams created by them
      teams = await Team.find({ "created_by._id": createdById })
        .select('team_id created_by teamName projects tasks members createdAt updatedAt');
    } else {
      // If the role is neither superAdmin nor Admin, return an error or handle as needed
      return res.status(200).json({
        code:404,
        error: "Access denied: insufficient permissions.",
      });
    }

    if (teams.length === 0) {
      return res.status(200).json({
        code: 404,
        error: "No teams found for this user",
      });
    }

    const formattedTeams = teams.map(team => ({
      created_by: {
        role: team.created_by.role,
      },
      team_id: team.team_id,
      teamName: team.teamName,
      tasks: team.tasks,
      members: team.members,
      projects: team.projects, 
      createdAt: team.createdAt,
      updatedAt: team.updatedAt,
    }));

    res.status(200).json(formattedTeams);
  } catch (error) {
    console.error("Error fetching teams:", error);
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};


exports.deleteTeam = async (req, res) => {
  try {
    const createdById = req.added_by;
    const role = req.role;
    const { teamId } = req.body;

    if (!createdById) {
      return res.status(200).json({
        code:400,
        error: "Admin ID is required",
      });
    }

    if (!teamId) {
      return res.status(200).json({
        code: 400,
        error: "Team ID is required.",
      });
    }

    
    const team = role === 'SuperAdmin' 
      ? await Team.findOne({ team_id: teamId }) 
      : await Team.findById(teamId);

    if (!team) {
      return res.status(200).json({
        code: 404,
        error: "Team not found",
      });
    }

    const teamName = team.teamName;

    
    await Team.deleteOne({ _id: team._id });

    
    if (role === 'SuperAdmin') {
      await Admin.updateMany({ teams: teamName }, { $pull: { teams: teamName } });
      await User.updateMany({ teams: teamName }, { $pull: { teams: teamName } });
      await Client.updateMany({ teams: teamName }, { $pull: { teams: teamName } });
      await SuperAdmin.updateMany(
        { "teams.team_id": teamId },
        { $pull: { teams: { team_id: teamId } } }
      );
    }

    res.status(200).json({
      code: 200,
      message: "Team deleted successfully",
    });

  } catch (error) {
    console.error("Error deleting team:", error);
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};


exports.getAllAssignedTeams = async (req, res) => {
  try {
    const memberId = req.userId;

    if (!memberId) {
      return res.status(200).json({
        code:400,
        error: "User ID is required",
      });
    }

    
    const teams = await Team.find({ "members.member_id": memberId })
      .populate({
        path: 'tasks.task_id', 
        select: 'taskName description start_date end_date status priority', 
      })
      .populate({
        path: 'projects.project_id', 
        select: 'projectName project_description start_date end_date project_status', 
      })
      .populate({
        path: 'members.member_id', 
        select: 'name role phone_number', 
      })
      .exec();

    if (teams.length === 0) {
      return res.status(200).json({
        code:404,
        error: "No data available",
      });
    }

    
    const formattedTeams = teams.map(team => ({
      created_by: {
        role: team.created_by.role,
      },
      team_id: team.team_id,
      teamName: team.teamName,
      tasks: team.tasks.map(task => ({
        task_id: task.task_id, 
        taskName: task.taskName,
      })),
      members: team.members.map(member => ({
        member_id: member.member_id, 
        role: member.role,
        name: member.name,
      })),
      projects: team.projects.map(project => ({
        project_id: project.project_id, 
        projectName: project.projectName,
        project_description: project.project_id.project_description,
        start_date: project.project_id.start_date,
        end_date: project.project_id.end_date,
        project_status: project.project_id.project_status,
      })),
      createdAt: team.createdAt,
      updatedAt: team.updatedAt,
    }));

    res.status(200).json(formattedTeams);
  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};

exports.getAllTeamsIdsAndNames = async(req,res)=>{
  try {
    const added_by_admin_id = req.added_by;

    const teams = await Team.find({"created_by._id": added_by_admin_id}, { team_id: 1, teamName: 1, _id: 0 }); 
    res.status(200).json(teams); 
  } catch (error) {
    res.status(200).json({code:500, error: error.message });
  }
}


