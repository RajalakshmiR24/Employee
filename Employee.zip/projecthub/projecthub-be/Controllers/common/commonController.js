const Admin = require("../../Models/Admin");
const Client = require("../../Models/Client");
const Project = require("../../Models/Project");
const SuperAdmin = require("../../Models/SuperAdmin");
const Task = require("../../Models/Task");
const User = require("../../Models/User");

exports.getAllByRole = async (req, res) => {
  const added_by_admin_id = req.added_by;
  const role = req.role;

  try {
    let users = [], admins = [], clients = [];

    if (role === "superAdmin") {
      [users, admins, clients] = await Promise.all([
        User.find().select('-_id -hash -createdAt -updatedAt -__v'),
        Admin.find().select('-_id -hash -createdAt -updatedAt -__v -board -organization._id'),
        Client.find().select('-_id -hash -createdAt -updatedAt -__v'),
      ]);
    } else if (role === "Admin") {
      [users, clients] = await Promise.all([
        User.find({ added_by_admin_id }).select('-_id -hash -createdAt -updatedAt -__v'),
        Client.find({ added_by_admin_id }).select('-_id -hash -createdAt -updatedAt -__v'),
      ]);
    } else {
      return res.status(200).json({ code: 403, error: "Access forbidden" });
    }

    if ((!users || users.length === 0) && (!admins || admins.length === 0) && (!clients || clients.length === 0)) {
      return res.status(200).json({ code: 404, message: "No data found" });
    }

    let responseMessage = {};
    if (users && users.length > 0) responseMessage.users = users;
    if (admins && admins.length > 0) responseMessage.admins = admins;
    if (clients && clients.length > 0) responseMessage.clients = clients;

    if (role === "superAdmin") {
      if (users.length === 0 && admins.length === 0 && clients.length === 0) {
        responseMessage = { message: "No data found for users, admins, and clients" };
      } else if (admins.length === 0) {
        responseMessage.admins = "Admins not found";
      } else if (clients.length === 0) {
        responseMessage.clients = "Clients not found";
      }
    } else if (role === "Admin") {
      if (users.length === 0 && clients.length === 0) {
        responseMessage = { message: "No data found for users and clients" };
      } else if (clients.length === 0) {
        responseMessage.clients = "Clients not found";
      }
    }

    return res.status(200).json(responseMessage);

  } catch (error) {
    console.error(error);
    return res.status(500).json({ code: 500, error: error.message });
  }
};

exports.createPosition = async (req, res) => {
  const { role } = req;
  const { position } = req.body;

  if (!position) {
    return res.status(200).json({code:400, error: "Position is required." });
  }

  
  const positionRegex = /^[A-Za-z\s]+$/; 
  const minLength = 3;
  const maxLength = 50;

  if (!positionRegex.test(position)) {
    return res.status(200).json({
      code:400,
      error: "Position can only contain alphabetic characters and spaces.",
    });
  }

  if (position.length < minLength || position.length > maxLength) {
    return res.status(200).json({
      code:400,
      error: `Position must be between ${minLength} and ${maxLength} characters.`,
    });
  }

  try {
    let existingPosition;
    let entity;

    
    if (role === "Admin") {
      existingPosition = await Admin.findOne({
        "positions.position": position,
      });
      entity = await Admin.findOne();
    } else if (role === "superAdmin") {
      existingPosition = await SuperAdmin.findOne({
        "positions.position": position,
      });
      entity = await SuperAdmin.findOne();
    } else {
      return res.status(200).json({code:403, error: "Unauthorized role." });
    }

    if (existingPosition) {
      return res.status(200).json({
        code:400,
        error: `The position "${position}" already exists.`,
      });
    }

    if (!entity) {
      return res.status(200).json({
        code:404,
        error: `${role.charAt(0).toUpperCase() + role.slice(1)} not found.`,
      });
    }

    entity.positions.push({ position: position, userIds: [] });
    await entity.save();

    res.status(200).json({
      message: `Position "${position}" created successfully.`,
    });
  } catch (error) {
    res.status(200).json({code:500, error: error.message });
  }
};

exports.getAllPositions = async (req, res) => {
  const userId = req.added_by;
  const role = req.role;

  try {
    let entity;

    if (role === "superAdmin") {
      entity = await SuperAdmin.findOne({ superAdmin_id: userId });
      if (!entity) {
        return res
          .status(200)
          .json({ code: 404, error: "SuperAdmin not found." });
      }
    } else if (role === "Admin") {
      entity = await Admin.findOne({ admin_id: userId });
      if (!entity) {
        return res
          .status(200)
          .json({ code: 404, error: "Admin not found." });
      }
    } else {
      return res.status(200).json({ code: 403, error: "Unauthorized role." });
    }

    const positions = entity.positions;

    if (positions.length === 0) {
      return res.status(200).json({ code: 404, message: "No positions found." });
    }

    return res.status(200).json({
      positions: positions,
    });
  } catch (error) {
    res.status(200).json({ error: error.message });
  }
};

exports.assignPosition = async (req, res) => {
  const added_by_admin_id = req.added_by;
  const role = req.role;

  try {
    const { position, userIds } = req.body;

    if (!position) {
      return res
        .status(200)
        .json({ code: 400, error: "Position is required." });
    }

    if (Array.isArray(userIds)) {
      return res.status(200).json({
        code: 400,
        error: "userIds must not be an array. Only one userId can be passed.",
      });
    }

    const userId = userIds;

    let entity;
    if (role === "Admin") {
      entity = await Admin.findOne({ admin_id: added_by_admin_id });
      if (!entity) {
        return res.status(200).json({ code: 404, error: "Admin not found." });
      }
    } else if (role === "superAdmin") {
      entity = await SuperAdmin.findOne({ superAdmin_id: added_by_admin_id });
      if (!entity) {
        return res
          .status(200)
          .json({ code: 404, error: "SuperAdmin not found." });
      }
    } else {
      return res.status(200).json({ code: 403, error: "Unauthorized role." });
    }

    const positionObj = entity.positions.find((p) => p.position === position);
    if (!positionObj) {
      return res.status(200).json({
        code: 404,
        error: `Position "${position}" does not exist.`,
      });
    }

    const conflictingUser = await User.findOne({
      "position.position_name": position,
      added_by_admin_id: added_by_admin_id,
    });

    if (conflictingUser) {
      return res.status(200).json({
        code: 400,
        error: `Position "${position}" is already assigned to user ${conflictingUser.name}.`,
      });
    }

    const user = await User.findOne({
      user_id: userId,
      added_by_admin_id: added_by_admin_id,
    });

    if (!user) {
      return res.status(200).json({
        code: 404,
        error: `You do not have access to assign a position to this user.`,
      });
    }
    

    if (user.position && user.position.position_name === position) {
      return res.status(200).json({
        code: 400,
        error: `User ${user.name} is already assigned to the position "${position}".`,
      });
    }

    user.position = {
      position_name: position,
      assigned_by: req.user
        ? req.user.user_id
        : `${entity.name}, (${role.charAt(0).toUpperCase() + role.slice(1)})`,
      assigned_date: new Date(),
    };
    await user.save();

    if (!positionObj.userIds.includes(user.user_id)) {
      positionObj.userIds.push(user.user_id.toString());
    }

    await entity.save();

    res.status(200).json({
      message: `User assigned to position "${position}".`,
    });
  } catch (error) {
    console.error("Error", error);
    res.status(200).json({ code: 500, error: error.message });
  }
};

exports.getAllColumns = async (req, res) => {
  const { added_by: added_by_admin_id, role, userId, clientId } = req;

  try {
    if (role === "superAdmin") {
      const admins = await Admin.find();
      const allColumns = admins.map((admin) => admin.board).flat();
      
      const uniqueColumns = [
        ...new Map(allColumns.map((col) => [col.column_name, col])).values(),
      ];
      return res.status(200).json({ columns: uniqueColumns });
    }

    if (role === "Admin") {
      const superAdmin = await Admin.findOne({ role: "superAdmin" });
      const superAdminColumns = superAdmin ? superAdmin.board : [];

      const admin = await Admin.findOne({ admin_id: added_by_admin_id });
      if (!admin) {
        return res.status(200).json({ code: 400, error: "Admin not found" });
      }
      const adminColumns = admin.board;

      const combinedColumns = [...superAdminColumns, ...adminColumns];
      
      const uniqueColumns = [
        ...new Map(combinedColumns.map((col) => [col.column_name, col])).values(),
      ];
      return res.status(200).json({ columns: uniqueColumns });
    }

    if (role === "User") {
      const tasks = await Task.find({ "assigned_to.user_id": userId });
      const assignerIds = tasks.map((task) => task.assigner_id);

      const admins = await Admin.find({ admin_id: { $in: assignerIds } });
      const userBoards = admins.map((admin) => admin.board).flat();

      
      const uniqueColumns = [
        ...new Map(userBoards.map((col) => [col.column_name, col])).values(),
      ];
      return res.status(200).json({ columns: uniqueColumns });
    }

    if (role === "Client") {
      const admin = await Admin.findOne({ clients: clientId });
      if (!admin) {
        return res.status(200).json({ error: "Client's admin not found" });
      }
      
      const uniqueColumns = [
        ...new Map(admin.board.map((col) => [col.column_name, col])).values(),
      ];
      return res.status(200).json({ columns: uniqueColumns });
    }

    return res.status(200).json({ code: 400, error: "Invalid role" });
  } catch (err) {
    return res.status(200).json({ code: 500, error: err.message });
  }
};


exports.getDashboardCounts = async (req, res) => {
  const role = req.role;
  const admin_id = req.added_by;

  try {
    let totalUsers, projectsInProgress, tasksCompletedToday;

    if (role === "superAdmin") {
      
      totalUsers = await User.countDocuments();
      projectsInProgress = await Project.countDocuments({
        project_status: "In Progress",
      });
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);

      tasksCompletedToday = await Task.countDocuments({
        status: "Completed",
        updated_at: { $gte: startOfDay, $lte: endOfDay },
      });
    } else if (role === "Admin") {
      
      totalUsers = await User.countDocuments({ added_by_admin_id: admin_id });
      projectsInProgress = await Project.countDocuments({
        created_by: admin_id,
        project_status: "In Progress",
      });
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);

      tasksCompletedToday = await Task.countDocuments({
        assigner_id: admin_id,
        status: "Completed",
        updated_at: { $gte: startOfDay, $lte: endOfDay },
      });
    }

    res.status(200).json({
      success: true,
      data: {
        totalUsers,
        projectsInProgress,
        tasksCompletedToday,
      },
    });
  } catch (error) {
    res.status(200).json({
      code:500,
      success: false,
      error: error.message,
    });
  }
};
