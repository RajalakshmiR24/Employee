const Token = require('../Models/token');
const SuperAdmin = require('../Models/SuperAdmin');
const Admin = require('../Models/Admin');
const Client = require('../Models/Client');
const User = require('../Models/User');

const login = (req, res, next) => {
  next();
};



const logout = (req, res, next) => {
  const issuer = process.env.OIDC_ISSUER_AUTH;
  const logoutUrl = `${issuer}/account/session/end`;
  res.redirect(logoutUrl);

  next();
};


const authenticate = (err, req, res, next) => {
  if (err) {
    console.error('Authentication error:', err);
    return res.status(200).send('Authentication failed. Please try again.');
  }
  next();
};


const verifySession = (req, res, next) => {

  try {
    if (req.details && req.details.Auth_token && req.details.role ) {
      
      return res.status(200).json({
        code: 200,
        projecthubtoken: req.details.Auth_token,
        role:req.details.role
      });
    } else {
      return res.status(200).json({ code: 400, error: "Token or hash not found." });
    }
  } catch (error) {
    return res.status(200).json({ code: 500, error: error.message });
  }
};


const saveUserSession = async (req, tokenSet, userinfo) => {
  try {
    const { phone_number, hash, name, role } = userinfo;
    const { access_token, expires_at, id_token, refresh_token } = tokenSet;

    
    const roleModels = {
      superAdmin: SuperAdmin,
      Admin: Admin,
      User: User,
      Client: Client,
    };

    
    const createNewUserAndSession = async (model, role) => {
      const newUser = new model({
        phone_number,
        hash,
        name,
        role,
      });
      await newUser.save();

      const newTokenSession = new Token({
        userhash: hash,
        access_token,
        refresh_token,
        expires_at,
        id_token,
        role,
      });
      await newTokenSession.save();
    };

    
    for (const [userRole, model] of Object.entries(roleModels)) {
      const existingUser = await model.findOne({ hash });

      if (existingUser) {
        
        await model.updateOne({ hash }, { $set: { name } });

        const newTokenSession = new Token({
          userhash: hash,
          access_token,
          refresh_token,
          expires_at,
          id_token,
          role: userRole,
        });
        await newTokenSession.save();
        return userRole; 
      }
    }

    
    if (role in roleModels) {
      await createNewUserAndSession(roleModels[role], role);
      return role; 
    }

  } catch (err) {
    console.error('Error saving user session:', err);
  }
};


const checkRole = async (req, res) => {
  try {
    const role = req.role;
    if (!role) {
      return res.status(200).json({
        code: 400,
        error: "Role not found for the provided hash.",
      });
    }
    
    return res.status(200).json({
      code: 200,
      role: role,
    });
  } catch (error) {
    return res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};

const getRoleDetails = async (req, res) => {
  try {
    const hash = req.hash;
    let roleData;
    let role;
    roleData = await SuperAdmin.findOne({ hash: hash })
      .populate('teams')
      .populate('projects')
      .exec();
    if (roleData) role = 'superAdmin';

    if (!roleData) {
      roleData = await Admin.findOne({ hash: hash })
        .populate('projects')
        .populate('teams')
        .exec();
      if (roleData) {
        if (!roleData.isVerifiedBySuperAdmin) {
          return res.status(200).json({
            code: 403,
            error: 'Admin is not verified by SuperAdmin. Access denied.',
          });
        }
        role = 'Admin';
      }
    }
    if (!roleData) {
      roleData = await User.findOne({ hash: hash })
        .populate('teams')
        .populate('projects')
        .exec();
      if (roleData) role = 'User';
    }
    if (!roleData) {
      roleData = await Client.findOne({ hash: hash })
        .populate('projects')
        .exec();
      if (roleData) role = 'Client';
    }
    if (!roleData) {
      return res.status(200).json({
        code: 404,
        error: "Role not found.",
      });
    }
    let positionDetails = {};
    if (!roleData.position && roleData.position_accepted === false) {
      positionDetails.message = "The user has no position assigned.";
    } else if (!roleData.position_accepted) {
      positionDetails = {
        ...roleData.position,
        status: "Pending",
        message: "The user has no position assigned [or] The position is assigned but not yet accepted.",
      };
    } else {
      positionDetails = {
        ...roleData.position,
        status: "Accepted",
        message: "The position has been assigned and accepted.",
      };
    }


    if (!roleData.position && !roleData.position_accepted) {
      delete positionDetails.status;
    }

    res.status(200).json({
      code: 200,
      role,
      name: roleData.name,
      teams: roleData.teams && roleData.teams.length > 0 ? roleData.teams : "No data",
      projects: roleData.projects && roleData.projects.length > 0 ? roleData.projects : "No data",
      position: positionDetails,
    });
  } catch (error) {
    res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};




module.exports = {
  login,
  logout,
  authenticate,
  verifySession,
  saveUserSession,
  getRoleDetails,checkRole

};
