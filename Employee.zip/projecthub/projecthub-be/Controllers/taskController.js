const Admin = require("../Models/Admin");
const Project = require("../Models/Project");
const SuperAdmin = require("../Models/SuperAdmin");
const Team = require("../Models/Team");

const Task = require("../Models/Task");
const User = require("../Models/User");
const { v4: uuidv4 } = require('uuid');
const Client = require("../Models/Client");

exports.createTask = async (req, res) => {
  try {
    const {
      taskName,
      description,
      assigned_to,
      project,
      team,
      start_date,
      end_date,
      priority,
      status,
    } = req.body;
    const role = req.role;
    const createdBy = req.added_by;

    
    if (role !== 'Admin') {
      return res.status(200).json({ code: 403, error: 'Access denied. Only admins can create tasks.' });
    }

    
    if (!taskName || !project || !team) {
      return res.status(200).json({ code:400, error: 'Task name, project, and team are required.' });
    }

    
    const teamDetails = await Team.findOne({ team_id: team }).lean();
    if (!teamDetails) {
      return res.status(200).json({code:400, error: 'Invalid team specified.' });
    }

    
    const validUsers = teamDetails.members.map(member => member.member_id);
    const invalidAssignees = assigned_to.filter(userId => !validUsers.includes(userId));
    if (invalidAssignees.length > 0) {
      return res.status(200).json({
        code:400,
        error: 'Some assigned users are not part of the specified team.',
        invalidAssignees,
      });
    }

    
    const users = await User.find({ user_id: { $in: assigned_to } });
    const projects = await Project.find({ project_id: project });

    
    const newTask = new Task({
      task_id: uuidv4(),
      taskName,
      description,
      assigner_id: createdBy,
      assigned_to: assigned_to.map(user => {
        const foundUser = users.find(u => u.user_id === user);
        return {
          user_id: user,
          name: foundUser ? foundUser.name : null,
          assigned_at: new Date(),
        };
      }),
      project: {
        project_id: project,
        projectName: projects[0] ? projects[0].projectName : null,
      },
      team: {
        team_id: team,
        teamName: teamDetails.teamName,
      },
      start_date,
      end_date,
      priority,
      status,
    });

    
    const savedTask = await newTask.save();

    
    const projectUpdateResult = await Project.updateOne(
      { project_id: project },
      {
        $set: { project_status: 'Task Assigned' },
        $addToSet: {
          tasks: {
            task_id: savedTask.task_id,
            taskName: savedTask.taskName,
            assigned_to: savedTask.assigned_to.map(user => user.user_id),
          },
        },
      }
    );
    

    return res.status(201).json({ message: 'Task created successfully.' });
  } catch (error) {
    return res.status(200).json({ error: error.message });
  }
};


exports.getAllAssignedTasks = async (req, res) => {
  try {
    const assignedToUserId = req.userId;

    if (!assignedToUserId) {
      return res.status(200).json({code:400, error: "User ID is required" });
    }

    const tasks = await Task.find({
      "assigned_to.user_id": assignedToUserId,
    });

    res.status(200).json({
      success: true,
      tasks,
    });
  } catch (error) {
    console.error("Error fetching assigned tasks:", error);
    res.status(200).json({
      code: 500,
      success: false,
      error: error.message,
    });
  }
};

exports.getAllTasksIdsAndNames = async (req, res) => {
  try {
    const role = req.role;
    const createdBy = req.added_by;

    if (!createdBy && role !== "superAdmin") {
      return res.status(200).json({code:400, error: "No assigner id provided" });
    }
    let tasks;
    if (role === "superAdmin") {
      tasks = await Task.find({}, { task_id: 1, taskName: 1, _id: 0 });
    } else if (role === "Admin") {
      tasks = await Task.find(
        { assigner_id: createdBy },
        { task_id: 1, taskName: 1, _id: 0 }
      );
    } else {
      return res.status(200).json({ code:403,error: "Forbidden: Invalid role" });
    }

    if (tasks.length === 0) {
      return res.status(200).json({ code: 404, error: "No tasks found" });
    }

    res.status(200).json(tasks);
  } catch (error) {
    console.error("Error retrieving tasks:", error);
    res
      .status(200)
      .json({ code:500, error: error.message });
  }
};

exports.getAllTasks = async (req, res) => {
  try {
    const userId = req.userId;
    const clientId = req.clientId;

    const assigner_id = req.added_by;
    const role = req.role;

    let tasks;
    if (role === "superAdmin") {
      tasks = await Task.find();
    } else if (role === "Admin") {
      tasks = await Task.find({ assigner_id: assigner_id });
    } else if (role === "User") {
      tasks = await Task.find({ "assigned_to.user_id": userId });
    } else if (role === "Client") {
      const client = await Client.findOne({ client_id: clientId });
      if (!client) {
        return res.status(200).json({ code:404, error: "Client not found" });
      }
      const projects = await Project.find({ project_id: client.project_ids });
      const projectIds = projects.map(project => project.project_id);

      tasks = await Task.find({ "project.project_id": { $in: projectIds } });
    } else {
      return res.status(200).json({code:403, error: "Access denied. Insufficient permissions." });
    }
    res.status(200).json(tasks);
  } catch (error) {
    res.status(200).json({ code:500, error: error.message });
  }
};

exports.changeTaskStatus = async (req, res) => {
  try {
    const { taskId, newStatus } = req.body;

    
    const admin = await Admin.findOne({ "board.column_name": newStatus });
    if (!admin) {
      return res.status(200).json({code:400, error: "Invalid status. Status must match an existing column name." });
    }

    const task = await Task.findOne({ task_id: taskId });
    if (!task) {
      return res.status(200).json({ code:400,error: "Task not found" });
    }

    
    task.status = newStatus;
    task.updated_at = Date.now();
    await task.save();

    
    const project = await Project.findOne({ "tasks.task_id": taskId });
    if (!project) {
      return res.status(200).json({code:404, error: "Parent project not found" });
    }

    
    const taskStatuses = project.tasks.map(t => t.status);
    project.project_status =
      taskStatuses.every(status => status === "Completed") ? "Completed" :
      taskStatuses.some(status => status === "In Progress") ? "In Progress" :
      newStatus;

    project.updated_at = Date.now();
    await project.save();

    res.status(200).json({
      message: "Task status and project status updated successfully",
      task,
      project,
    });
  } catch (error) {
    res
      .status(200)
      .json({ code:500, error: error.message });
  }
};

exports.addComment = async (req, res) => {
  const user_id = req.added_by || req.userId || req.clientId;  
  const role =  req.role;
  const name = req.name;
  const { task_id, message } = req.body;

  if (!message || !user_id ) {
    return res.status(200).json({code:400, error: 'User ID, comment message, name, and role are required' });
  }

  try {
    const task = await Task.findOne({ task_id });

    if (!task) {
      return res.status(200).json({code:404, error: 'Task not found' });
    }

    const newComment = {
      comment_id: uuidv4(),
      user_id,  
      name,
      role,
      message,
    };

    task.comments.push(newComment);

    await task.save();

    res.status(201).json({ message: 'Comment added successfully', comment: newComment });
  } catch (error) {
    console.error(error);
    res.status(200).json({ code:500, error: error.message});
  }
};
exports.getComments = async (req, res) => {
  const { task_id } = req.body;

  try {
    const task = await Task.findOne({ task_id });

    if (!task) {
      return res.status(200).json({code:404,error: 'Task not found' });
    }

    res.status(200).json({ comments: task.comments });
  } catch (error) {
    console.error(error);
    res.status(200).json({  code:500, error: error.message});
  }
};




