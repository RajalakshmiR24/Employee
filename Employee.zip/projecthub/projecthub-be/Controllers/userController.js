const crypto = require("crypto");
const User = require("../Models/User");
const Admin = require("../Models/Admin");

const checkUniqueWebsite = async (website) => {
  const existingAdmin = await Admin.findOne({
    "organization.organization_website": website,
  });
  return existingAdmin;
};

exports.convertUserToAdmin = async (req, res) => {
  try {
    const { newCompanyName, newCompanyWebsite, newCompanyAddress } = req.body;
    const user_id = req.added_by;
    const user = await User.findOne({ user_id });
    if (!user) {
      return res.status(200).json({ code: 404, error: "User not found" });
    }

    if (
      user.team_ids.length > 0 ||
      user.project_ids.length > 0 ||
      user.tasks.length > 0 ||
      user.position.position_taskName ||
      user.position.assigned_by ||
      user.position.assigned_date
    ) {
      return res.status(200).json({
        code: 400,
        error:
          "Cannot convert user to client because this user already in a team.",
      });
    }

    if (newCompanyWebsite) {
      const existingWebsite = await checkUniqueWebsite(newCompanyWebsite);
      if (existingWebsite && existingWebsite.admin_id) {
        return res
          .status(200)
          .json({
            code: 400,
            error: "Company website already taken by another admin",
          });
      }
    }

    const newAdmin = new Admin({
      name: user.name,
      phone_number: user.phone_number,
      hash: user.hash,
      token: user.token,
      positions: user.positions,
      teams: user.teams,
      projects: user.projects,
      tasks: user.tasks,
      isVerifiedBySuperAdmin: false,
      organization: {
        organization_name: newCompanyName,
        organization_address: newCompanyAddress,
        organization_phone: user.phone_number,
        organization_website: newCompanyWebsite,
      },
    });

    await newAdmin.save();

    await User.deleteOne({ user_id });

    return res.status(200).json({
      code: 200,
      message: "Request sent to superadmin.",
    });
  } catch (err) {
    return res.status(200).json({ code: 500, error: err.message });
  }
};

exports.getUserPosition = async (req, res) => {
  try {
    const userId = req.body.userId;
    const user = await User.findOne({ user_id: userId });

    if (!user) {
      return res.status(200).json({ code: 404, error: "User not found" });
    }

    if (!user.position) {
      return res
        .status(200)
        .json({ code: 404, error: "No position assigned to this user" });
    }

    return res.status(200).json({
      position: user.position,
      assignedBy: user.positionAssignedBy,
      assignedDate: user.positionAssignedDate,
      status: user.position_accepted,
    });
  } catch (err) {
    return res.status(200).json({ code: 500, error: err.message });
  }
};

exports.acceptPosition = async (req, res) => {
  try {
    const userId = req.userId;
    const {  accept } = req.body;

    if (typeof accept !== "boolean") {
      return res
        .status(200)
        .json({ code:400, error: "Invalid value for accept. It should be a boolean." });
    }

    const user = await User.findOne({ user_id: userId });

    if (!user) {
      return res.status(200).json({ code: 404, error: "User not found" });
    }

    if (!user.position) {
      return res
        .status(200)
        .json({ code: 400, error: "No position assigned to user" });
    }

    user.position_accepted = accept;
    await user.save();

    return res.status(200).json({
      message: accept ? "Position accepted" : "Position declined",
      position_accepted: user.position_accepted,
    });
  } catch (err) {
    return res.status(200).json({ code: 500, error: err.message });
  }
};


exports.getUserById = async (req, res) => {
  const user_id = req.userId;

  try {
    const user = await User.findOne({ user_id: user_id })
      .select("user_id name phone_number role position position_accepted createdAt updatedAt")
      .lean();

    if (!user) {
      return res.status(200).json({ code: 400, error: "User not found." });
    }

    delete user.user_id;

    return res.status(200).json({
      success: true,
      data: {
        user_id: user.user_id,
        name: user.name,
        phone_number: user.phone_number,
        role: user.role,
        position: user.position, 
        position_accepted: user.position_accepted, 
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
        team_ids: user.team_ids, 
        project_ids: user.project_ids, 
        tasks: user.tasks, 
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(200).json({
      code:500,
      error: error.message,
    });
  }
};


exports.getAllUserIdsAndNames = async (req, res) => {
  try {
    const added_by_admin_id = req.added_by;

    const users = await User.find({ added_by_admin_id: added_by_admin_id }, { user_id: 1, name: 1, _id: 0 });

    if (users.length === 0) {
      return res.status(200).json({code:404, error: 'No users found for the provided admin ID.' });
    }

    res.status(200).json(users);
  } catch (error) {
    res.status(200).json({code:500,  error: error.message });
  }
};



