const {
  checkPhoneNumberExists,
  hashPhoneNumber,
  maskFields,
} = require("../Middlewares/auth");
const Admin = require("../Models/Admin");
const Client = require("../Models/Client");
const Task = require("../Models/Task");
const User = require("../Models/User");
const crypto = require("crypto");

exports.createTaskAdmin = async (req, res) => {
  try {
    const {
      taskName,
      description,
      assigned_to,
      start_date,
      end_date,
      priority,
    } = req.body;

    if (
      !taskName ||
      !description ||
      !assigned_to ||
      !start_date ||
      !end_date ||
      !priority
    ) {
      return res.status(200).json({
        code: 400,
        error: "Please fill all required fields.",
      });
    }

    if (!Array.isArray(assigned_to) || assigned_to.length === 0) {
      return res.status(200).json({
        code: 400,
        error: "Assigned to must be an array with at least one user ID.",
      });
    }

    const existingTask = await Task.findOne({
      taskName,
      "assigned_by.admin_id": req.user.admin_id,
    });
    if (existingTask) {
      return res.status(200).json({
        code: 400,
        error:
          "Task name must be unique for the same admin. A task with this name already exists.",
      });
    }

    const users = await User.find({ user_id: { $in: assigned_to } });
    if (users.length !== assigned_to.length) {
      return res.status(200).json({
        code: 400,
        error: "One or more user IDs in assigned_to are invalid.",
      });
    }

    const admin = await Admin.findOne({ admin_id: req.user.admin_id });
    if (!admin) {
      return res.status(200).json({
        code: 403,
        error: "Only admin can perform this action.",
      });
    }

    const assigners = [
      {
        role: "admin",
        admin_id: admin.admin_id,
        assigned_at: new Date(),
      },
    ];

    const newTask = new Task({
      taskName,
      description,
      assigned_by: assigners,
      assigned_to: assigned_to.map((user) => ({
        user_id: user,
        assigned_at: new Date(),
      })),
      start_date,
      end_date,
      priority,
      board: {
        column: "To Do",
        position: 0,
      },
    });

    const savedTask = await newTask.save();

    admin.tasks.push(savedTask._id);
    await admin.save();

    for (let userId of assigned_to) {
      const user = await User.findOne({ user_id: userId });
      if (user) {
        user.tasks.push(savedTask._id);
        await user.save();
      }
    }

    return res.status(200).json({
      code: 201,
      message: "Task created successfully.",
    });
  } catch (error) {
    console.error(error.message);

    return res.status(200).json({
      code: 500,
      error: error.message,
    });
  }
};

exports.handleExcelUploadByAdmin = [
  checkPhoneNumberExists,
  async (req, res) => {
    try {
      const { excelData } = req.body;
      const added_by_admin_id = req.added_by;
      const role = req.role;
      const name = req.name;

      if (!excelData || !Array.isArray(excelData)) {
        return res.status(200).json({
          code: 400,
          error: "Excel data is required and must be an array.",
        });
      }

      let results = { success: [], errors: [] };

      for (let record of excelData) {
        const { name, phone_number, role, SheetName, position_name } = record;

        if (role !== "User" && role !== "Client") {
          results.errors.push({
            record,
            error: `Invalid role \"${role}\". Role must be either \"User\" or \"Client\".`,
            sheet: SheetName,
          });
          continue;
        }

        try {
          const existingEntry =
            role === "User"
              ? await User.findOne({ phone_number })
              : await Client.findOne({ phone_number });

          if (existingEntry) {
            results.errors.push({
              record,
              error: `A ${role} with the phone number ${phone_number} already exists.`,
              sheet: SheetName,
            });
            continue;
          }

          const hashedPhoneNumber = crypto
            .createHash("sha256")
            .update(phone_number.toString())
            .digest("hex");

          let newEntry;
          const positionData = position_name
            ? {
                position_name,
                assigned_by: `${req.name}, (${req.role})`,
                assigned_date: new Date(),
              }
            : null;

          if (role === "User") {
            newEntry = new User({
              name,
              phone_number,
              hash: hashedPhoneNumber,
              role,
              added_by_admin_id,
              ...(positionData && { position: positionData }),
            });
          } else {
            newEntry = new Client({
              name,
              phone_number,
              hash: hashedPhoneNumber,
              role,
              added_by_admin_id,
            });
          }

          await newEntry.save();

          // Update Admin's clients or users array
          const admin = await Admin.findOne({ admin_id: added_by_admin_id });

          if (!admin) {
            results.errors.push({
              record,
              error: `Admin with ID ${added_by_admin_id} not found.`,
              sheet: SheetName,
            });
            continue;
          }

          if (role === "User") {
            admin.users.push(newEntry.user_id.toString());
          } else {
            admin.clients.push(newEntry.client_id.toString());
          }

          await admin.save();

          // Update position in admin's record
          if (positionData) {
            let positionObj = admin.positions.find(
              (p) => p.position === position_name
            );

            if (!positionObj) {
              positionObj = { position: position_name, userIds: [] };
              admin.positions.push(positionObj);
            }

            if (!positionObj.userIds.includes(newEntry.user_id)) {
              positionObj.userIds.push(newEntry.user_id.toString());
            }

            await admin.save();
          }

          results.success.push({ ...newEntry.toObject(), sheet: SheetName });
        } catch (dbError) {
          results.errors.push({
            record,
            error: `Database error: ${dbError.message}`,
            sheet: SheetName,
          });
        }
      }

      const errorMessages = results.errors
        .map(
          (error, index) =>
            `Error ${index + 1}: ${error.error} (Sheet: ${
              error.sheet || "N/A"
            }, Record: ${JSON.stringify(error.record)})`
        )
        .join("\n");

      const totalRecords = results.success.length + results.errors.length;
      const message = `Data processing complete. ${results.success.length} records saved successfully. ${results.errors.length} records failed.\n\nDetailed Errors:\n${errorMessages}`;

      res.status(201).json({
        code: 201,
        message,
        results,
        totalRecords,
      });
    } catch (error) {
      res.status(200).json({ code: 500, error: error.message });
    }
  },
];



exports.createUserClient = [
  checkPhoneNumberExists,
  async (req, res) => {
    const { name, phone_number, role } = req.body;
    const added_by_admin_id = req.added_by;

    if (!name || !phone_number || !role) {
      return res.status(200).json({
        code: 400,
        error: "Name, phone number, and role are required",
      });
    }

    try {
      const hash = hashPhoneNumber(phone_number);
      let newEntity, idField, updateField;

      if (role === "User") {
        newEntity = new User({
          name,
          phone_number,
          hash,
          role: "User",
          added_by_admin_id,
        });
        idField = "user_id";
        updateField = "users";
      } else if (role === "Client") {
        newEntity = new Client({
          name,
          phone_number,
          hash,
          role: "Client",
          added_by_admin_id,
        });
        idField = "client_id";
        updateField = "clients";
      } else {
        return res.status(200).json({
          code: 400,
          error: 'Invalid role. Role must be one of "User" or "Client".',
        });
      }

      await newEntity.save();

      // Update the Admin schema
      const admin = await Admin.findOne({ admin_id: added_by_admin_id });
      if (!admin) {
        return res.status(200).json({
          code: 404,
          error: "Admin not found",
        });
      }

      admin[updateField].push(newEntity[idField]);
      await admin.save();

      return res.status(201).json({
        code: 201,
        message: `${role} created successfully`,
      });
    } catch (error) {
      return res.status(200).json({
        code: 500,
        error: error.message,
      });
    }
  },
];


exports.getAdminById = async (req, res) => {
  const admin_id = req.added_by;

  try {
    const admin = await Admin.findOne({ admin_id: admin_id })
      .select(
        "admin_id name phone_number role token isVerifiedBySuperAdmin verification_description createdAt updatedAt organization"
      )
      .lean();

    if (!admin) {
      return res.status(200).json({ code: 400, error: "Admin not found." });
    }

    delete admin.admin_id;

    return res.status(200).json({
      success: true,
      data: admin,
    });
  } catch (error) {
    return res.status(200).json({ code: 500, error: error.message });
  }
};

exports.createColumn = async (req, res) => {
  const added_by_admin_id = req.added_by;
  const { columnName, position } = req.body;

  if (!columnName) {
    return res
      .status(200)
      .json({ code: 400, error: "Column name is required" });
  }

  if (position === undefined || position < 1) {
    return res
      .status(200)
      .json({ code: 400, error: "Valid position (>= 1) is required" });
  }

  try {
    const admin = await Admin.findOne({ admin_id: added_by_admin_id });

    if (!admin) {
      return res.status(200).json({ code: 404, error: "Admin not found" });
    }

    const boardLength = admin.board.length;

    // Ensure position is within valid range but not the first or last position
    if (position >= boardLength) {
      return res.status(200).json({
        code: 400,
        error: "Position cannot be at the first or last position",
      });
    }

    const newColumn = {
      column_created_by: added_by_admin_id,
      column_name: columnName,
      position: position,
    };

    // Adjust positions for columns after the inserted position
    admin.board.forEach((column, index) => {
      if (index > 0 && index < boardLength - 1 && column.position >= position) {
        column.position += 1;
      }
    });

    // Insert the new column at the specified position
    admin.board.splice(position, 0, newColumn);

    // Ensure positions for first and last remain intact
    admin.board[0].position = 0;
    admin.board[boardLength].position = boardLength;

    await admin.save();

    return res
      .status(201)
      .json({ message: "Column created successfully" });
  } catch (err) {
    return res
      .status(200)
      .json({ code:500, error: err.message });
  }
};


exports.getAllColumns = async (req, res) => {
  const added_by_admin_id = req.added_by;

  try {
    const admin = await Admin.findOne({ admin_id: added_by_admin_id });

    if (!admin) {
      return res.status(200).json({ code: 404, error: "Admin not found" });
    }

    return res.status(200).json({ columns: admin.board });
  } catch (err) {
    return res
      .status(200)
      .json({ code:500, error: err.message });
  }
};

exports.updateColumn = async (req, res) => {
  const added_by_admin_id = req.added_by;
  const { columnId, columnName, position } = req.body;

  if (!columnId || !columnName) {
    return res
      .status(200)
      .json({ code: 400, error: "Column ID and column name are required" });
  }

  try {
    const admin = await Admin.findOne({ admin_id: added_by_admin_id });

    if (!admin) {
      return res.status(200).json({ code: 404, error: "Admin not found" });
    }

    const columnIndex = admin.board.findIndex(
      (col) => col._id.toString() === columnId
    );

    if (columnIndex === -1) {
      return res.status(200).json({ code: 404, error: "Column not found" });
    }

    admin.board[columnIndex].column_name = columnName;

    if (position !== undefined) {
      if (admin.board[columnIndex].position !== position) {
        const oldPosition = admin.board[columnIndex].position;
        if (oldPosition < position) {
          admin.board.forEach((column) => {
            if (column.position > oldPosition && column.position <= position) {
              column.position -= 1;
            }
          });
        } else {
          admin.board.forEach((column) => {
            if (column.position >= position && column.position < oldPosition) {
              column.position += 1;
            }
          });
        }
        admin.board[columnIndex].position = position;
      }
    }

    await admin.save();

    return res.status(200).json({
      message: "Column updated successfully",
      column: admin.board[columnIndex],
    });
  } catch (err) {
    return res
      .status(200)
      .json({ code:500, error: err.message });
  }
};

exports.deleteColumn = async (req, res) => {
  const added_by_admin_id = req.added_by;
  const { columnId } = req.body;

  if (!columnId) {
    return res.status(200).json({ code: 400, error: "Column ID is required" });
  }

  try {
    const admin = await Admin.findOne({ admin_id: added_by_admin_id });

    if (!admin) {
      return res.status(200).json({ code: 404, error: "Admin not found" });
    }

    const columnIndex = admin.board.findIndex(
      (col) => col._id.toString() === columnId
    );

    if (columnIndex === -1) {
      return res.status(200).json({ code: 404, error: "Column not found" });
    }

    admin.board.splice(columnIndex, 1);
    admin.board.forEach((column, index) => {
      column.position = index;
    });

    await admin.save();

    return res.status(200).json({ message: "Column deleted successfully" });
  } catch (err) {
    return res
      .status(200)
      .json({ code:500, error: err.message });
  }
};
