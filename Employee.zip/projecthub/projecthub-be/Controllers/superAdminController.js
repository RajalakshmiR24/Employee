const SuperAdmin = require("../Models/SuperAdmin");
const User = require("../Models/User");
const Admin = require("../Models/Admin");
const {
  checkPhoneNumberExists,
  hashPhoneNumber,
  maskFields,
} = require("../Middlewares/auth");
const Client = require("../Models/Client");
const crypto = require("crypto");

exports.createSuperAdmin = [
  checkPhoneNumberExists,
  async (req, res) => {
    try {
      const { phone_number, name } = req.body;

      const existingSuperAdmin = await SuperAdmin.findOne();
      if (existingSuperAdmin) {
        return res.status(200).json({
          code: 400,
          error:
            "A SuperAdmin already exists. Only one SuperAdmin can be created.",
        });
      }

      const hash = hashPhoneNumber(phone_number);

      const newSuperAdmin = new SuperAdmin({
        phone_number,
        hash,
        name,
      });

      await newSuperAdmin.save();

      return res.status(201).json({
        code: 201,
        message: "SuperAdmin created successfully.",
      });
    } catch (error) {
      return res.status(200).json({ code: 500, error: error.message });
    }
  },
];

exports.manageAdmins = async (req, res) => {
  try {
    const { action, admin_id, isVerifiedBySuperAdmin } = req.body;

    if (action === "getUnverified") {
      const admins = await Admin.find({ isVerifiedBySuperAdmin: false });

      return res.status(200).json({
        code: 200,
        message: "Admins with unverified status retrieved successfully.",
        data: admins,
      });
    } else if (action === "Verified") {
      if (admin_id === undefined || isVerifiedBySuperAdmin === undefined) {
        return res.status(200).json({
          code: 400,
          error: "Admin ID and verification status are required.",
        });
      }

      const admin = await Admin.findOne({ admin_id });
      if (!admin) {
        return res.status(200).json({
          code: 404,
          error: "Admin not found.",
        });
      }

      if (admin.isVerifiedBySuperAdmin === isVerifiedBySuperAdmin) {
        return res.status(200).json({
          code: 400,
          error: `Admin verification status is already ${isVerifiedBySuperAdmin ? "true" : "false"
            }.`,
        });
      }

      admin.isVerifiedBySuperAdmin = isVerifiedBySuperAdmin;
      await admin.save();

      return res.status(200).json({
        code: 200,
        message: `Admin verification status updated to ${isVerifiedBySuperAdmin ? "true" : "false"
          }.`,
      });
    } else {
      return res.status(200).json({
        code: 400,
        error: "Invalid action provided.",
      });
    }
  } catch (err) {
    return res.status(200).json({
      code: err.code,
      error: err.message,
    });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find();

    if (!users || users.length === 0) {
      return res.status(200).json({ code: 404, error: "No users found." });
    }

    res.status(200).json({ code: 200, users });
  } catch (err) {
    res.status(200).json({
      code: 500,
      error: err.message,
    });
  }
};

exports.createUserAdminClient = [
  checkPhoneNumberExists,
  async (req, res) => {
    const {
      name,
      phone_number,
      role,
      organization_name,
      organization_address,
      organization_website,
    } = req.body;
    const added_by_admin_id = req.added_by;

    if (!name || !phone_number) {
      return res.status(200).json({
        code: 400,
        error: "Name and phone number are required",
      });
    }

    try {
      const hash = hashPhoneNumber(phone_number);

      if (role === "User") {
        const newUser = new User({
          name,
          phone_number,
          hash,
          role: "User",
          added_by_admin_id,
        });

        await newUser.save();

        await SuperAdmin.updateOne({}, { $push: { users: newUser.user_id } });

        return res.status(201).json({
          code: 201,
          message: "User created successfully",
        });
      } else if (role === "Admin") {
        if (
          !organization_name ||
          !organization_address ||
          !organization_website
        ) {
          return res.status(200).json({
            code: 400,
            error: "Organization details are required for admin",
          });
        }

        const newAdmin = new Admin({
          name,
          phone_number,
          hash,
          role: "Admin",
          isVerifiedBySuperAdmin: true,
          added_by_admin_id,
          board: [
            {
              column_created_by: added_by_admin_id,
              column_name: "New Task",
              position: 0,
            },
            {
              column_created_by: added_by_admin_id,
              column_name: "Scheduled",
              position: 1,
            },
            {
              column_created_by: added_by_admin_id,
              column_name: "In Progress",
              position: 2,
            },
            {
              column_created_by: added_by_admin_id,
              column_name: "Completed",
              position: 3,
            },
          ],
          organization: {
            organization_name,
            organization_address,
            organization_website,
          },
        });

        await newAdmin.save();

        await SuperAdmin.updateOne(
          {},
          { $push: { admins: newAdmin.admin_id } }
        );

        return res.status(201).json({
          code: 201,
          message: "Admin created successfully",
        });
      } else if (role === "Client") {
        const newClient = new Client({
          name,
          phone_number,
          hash,
          role: "Client",
          added_by_admin_id,
        });

        await newClient.save();

        await SuperAdmin.updateOne(
          {},
          { $push: { clients: newClient.client_id } }
        );

        return res.status(201).json({
          code: 201,
          message: "Client created successfully",
        });
      } else {
        return res.status(200).json({
          code: 400,
          error:
            'Invalid role. Role must be one of "user", "admin", or "client"',
        });
      }
    } catch (error) {
      return res.status(200).json({
        code: 500,
        error: error.message,
      });
    }
  },
];

exports.handleExcelUploadBySuperAdmin = [
  checkPhoneNumberExists,
  async (req, res) => {
    try {
      const { excelData } = req.body;
      const added_by_admin_id = req.added_by;

      if (!excelData || !Array.isArray(excelData)) {
        return res.status(200).json({
          code: 400,
          error: "Excel data is required and must be an array.",
        });
      }

      let results = { success: [], errors: [] };

      const assigningAdmin =
        (await Admin.findOne({ admin_id: added_by_admin_id })) ||
        (await SuperAdmin.findOne({ superAdmin_id: added_by_admin_id }));

      if (!assigningAdmin) {
        return res.status(200).json({
          code: 404,
          error: "Admin or SuperAdmin not found for the provided ID.",
        });
      }

      const assignedByName = assigningAdmin.name;

      for (let record of excelData) {
        const {
          name,
          phone_number,
          role,
          SheetName,
          organization_name,
          organization_address,
          organization_website,
          position_name,
        } = record;

        if (role !== "User" && role !== "Client" && role !== "Admin") {
          results.errors.push({
            record,
            error: `Invalid role "${role}". Role must be either "User", "Client" or "Admin".`,
            sheet: SheetName,
          });
          continue;
        }

        try {
          const existingEntry =
            role === "User"
              ? await User.findOne({ phone_number })
              : role === "Client"
                ? await Client.findOne({ phone_number })
                : await Admin.findOne({ phone_number });

          if (existingEntry) {
            results.errors.push({
              record,
              error: `A ${role} with the phone number ${phone_number} already exists.`,
              sheet: SheetName,
            });
            continue;
          }

          const hashedPhoneNumber = crypto
            .createHash("sha256")
            .update(phone_number.toString())
            .digest("hex");

          let newEntry;
          const positionData = position_name
            ? {
              position_name,
              assigned_by: `${assignedByName}, (${assigningAdmin.role})`,
              assigned_date: new Date(),
            }
            : null;

          if (role === "User") {
            newEntry = new User({
              name,
              phone_number,
              hash: hashedPhoneNumber,
              role,
              added_by_admin_id,
              ...(positionData && { position: positionData }),
            });
          } else if (role === "Client") {
            newEntry = new Client({
              name,
              phone_number,
              hash: hashedPhoneNumber,
              role,
              added_by_admin_id,
            });
          } else {
            newEntry = new Admin({
              name,
              phone_number,
              hash: hashedPhoneNumber,
              role,
              added_by_admin_id,
              isVerifiedBySuperAdmin: true,
              board: [
                {
                  column_created_by: added_by_admin_id,
                  column_name: "New Task",
                  position: 0,
                },
                {
                  column_created_by: added_by_admin_id,
                  column_name: "Scheduled",
                  position: 1,
                },
                {
                  column_created_by: added_by_admin_id,
                  column_name: "In Progress",
                  position: 2,
                },
                {
                  column_created_by: added_by_admin_id,
                  column_name: "Completed",
                  position: 3,
                },
              ],
              organization: {
                organization_name,
                organization_address,
                organization_website,
              },
            });
          }

          await newEntry.save();

          const entityType = role.toLowerCase() + "s";
          const idField = role.toLowerCase() + "_id";

          await SuperAdmin.updateOne(
            {},
            { $push: { [entityType]: newEntry[idField] } }
          );

          if (positionData) {
            const positionExists = assigningAdmin.positions.find(
              (p) => p.position === position_name
            );
            if (!positionExists) {
              assigningAdmin.positions.push({
                position: position_name,
                userIds: [newEntry.user_id.toString()],
              });
            } else {
              positionExists.userIds.push(newEntry.user_id.toString());
            }
            await assigningAdmin.save();
          }

          results.success.push({ ...newEntry.toObject(), sheet: SheetName });
        } catch (dbError) {
          results.errors.push({
            record,
            error: `Database error: ${dbError.message}`,
            sheet: SheetName,
          });
        }
      }

      const errorMessages = results.errors
        .map(
          (error, index) =>
            `Error ${index + 1}: ${error.error} (Sheet: ${error.sheet || "N/A"
            }, Record: ${JSON.stringify(error.record)})`
        )
        .join("\n");

      const totalRecords = results.success.length + results.errors.length;
      const message = `Data processing complete. ${results.success.length} records saved successfully. ${results.errors.length} records failed.\n\nDetailed Errors:\n${errorMessages}`;

      res.status(201).json({
        code: 201,
        message,
        results,
        totalRecords,
      });
    } catch (error) {
      res.status(200).json({ code: 500, error: error.message });
    }
  },
];

exports.getSuperAdminById = async (req, res) => {
  const superAdmin_id = req.added_by;


  try {
    const superAdmin = await SuperAdmin.findOne({
      superAdmin_id: superAdmin_id,
    })
      .select(
        "superAdmin_id name phone_number role positions teams projects tasks messages users clients admins createdAt updatedAt"
      )

    if (!superAdmin) {
      return res
        .status(200)
        .json({ code: 400, error: "Super Admin not found." });
    }

    return res.status(200).json({
      success: true,
      data: superAdmin,
    });
  } catch (error) {
    return res.status(200).json({ code: 500, error: error.message });
  }
};

exports.getAllOrganizations = async (req, res) => {
  try {
    const admins = await Admin.find().select('-__v -updatedAt -createdAt -organization._id -positions -_id -hash -board')  // Exclude board
      .populate('organization')
      .exec();
    if (!admins || admins.length === 0) {
      return res.status(200).json({
        code:404,
        message: 'No Organizations found',
      });
    }
    return res.status(200).json({
      data: admins,
    });
  } catch (error) {
    return res.status(200).json({
      code:500,
      error: error.message,
    });
  }
};
