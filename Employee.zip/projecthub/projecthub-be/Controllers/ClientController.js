const Client = require("../Models/Client");
const Project = require("../Models/Project");
const User = require('../Models/User');


exports.getClientById = async (req, res) => {
    const client_id = req.clientId;
  
    try {
      const client = await Client.findOne({ client_id })
        .select("client_id name phone_number role added_by_admin_id messages createdAt updatedAt")
        .populate("messages", "content") 
        .lean();
  
      if (!client) {
        return res.status(200).json({ code: 400, error: "Client not found." });
      }
    
      return res.status(200).json({
        success: true,
        data: client,
      });
    } catch (error) {
      console.error(error);
      return res.status(200).json({  code:500, error:error.message });
    }
  };
  

  exports.viewAccessedProjects = async (req, res) => {
    try {
      const client_id = req.clientId;
      const client = await Client.findOne({ client_id: client_id });
  
      if (!client) {
        return res.status(200).json({ code: 404, error: 'Client not found' });
      }
  
      const projectIds = client.project_ids;
      if (!projectIds || projectIds.length === 0) {
        return res.status(200).json({ code: 404, error: 'No projects associated with this client' });
      }
  
      
      const projects = await Project.find(
        { project_id: { $in: projectIds } },
        {
          tasks: 0, 
          created_by: 0, 
        }
      );
  
      if (projects.length === 0) {
        return res.status(200).json({ code: 404, error: 'No projects found for this client' });
      }
  
      
      const sanitizedProjects = projects.map((project) => {
        const sanitizedTeams = project.teams.map((team) => ({
          teamName: team.teamName,
        }));
  
        return {
          ...project.toObject(), 
          teams: sanitizedTeams, 
        };
      });
  
      return res.status(200).json({ projects: sanitizedProjects });
    } catch (error) {
      return res.status(200).json({ code: 500, error: error.message });
    }
  };
  


