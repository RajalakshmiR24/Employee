const Admin = require('../../Models/Admin');
const Client = require('../../Models/Client');
const Project = require('../../Models/Project');
const Task = require('../../Models/Task');
const User = require('../../Models/User');

exports.getDashboardCounts = async (req, res) => {
    const  admin_id = req.added_by
   
     try {
       
       const totalUsers = await User.countDocuments({added_by_admin_id : admin_id} );
       const projectsInProgress = await Project.countDocuments({created_by:admin_id});
       const startOfDay = new Date();
       startOfDay.setHours(0, 0, 0, 0);
   
       const endOfDay = new Date();
       endOfDay.setHours(23, 59, 59, 999);
   
       const tasksCompletedToday = await Task.countDocuments({
        assigner_id:admin_id,
         status: 'Completed',
         updated_at: { $gte: startOfDay, $lte: endOfDay },
       });
   
       
       res.status(200).json({
         success: true,
         data: {
           totalUsers,
           projectsInProgress,
           tasksCompletedToday,
         },
       });
     } catch (error) {
       console.error('Error fetching dashboard counts:', error);
       res.status(200).json({
         code:500,
         success: false,
         error: error.message,
       });
     }
};
   
