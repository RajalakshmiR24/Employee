const Admin = require('../Models/Admin');
const Client = require('../Models/Client');
const Project = require('../Models/Project');
const SuperAdmin = require('../Models/SuperAdmin');
const User = require('../Models/User');


exports.createProject = async (req, res) => {
  try {
    const createdBy = req.added_by;  
    const role = req.role;

    
    if (role !== 'Admin') {
      return res.status(200).json({  error: 'Access denied. Only admins can create projects.' });
    }

    const { projectName, project_description, start_date, end_date, tasks, teams } = req.body;

    
    if (!projectName || !project_description || !start_date || !end_date) {
      return res.status(200).json({code:400, error: 'Missing required fields' });
    }

    
    const newProject = new Project({
      projectName,
      project_description,
      start_date,
      end_date,
      project_status: "Not Started",  
      tasks: tasks || [],
      created_by: createdBy,
      teams: teams || [],
    });

    await newProject.save();

    
    const admin = await Admin.findOne({ admin_id: createdBy });
    if (!admin) {
      return res.status(200).json({
        code:404,
        error: "Admin not found.",
      });
    }

    

    return res.status(201).json({
      message: 'Project created successfully',
    });
  } catch (error) {
    console.error(error);
    return res.status(200).json({ code:500, error: error.message });
  }
};


exports.getAllProjects = async (req, res) => {
  try {
    const createdBy = req.added_by;
    const role = req.role;

    let projects;

    if (role === 'superAdmin') {
      
      projects = await Project.find({});
    } else if (role === 'Admin') {
      
      projects = await Project.find({ created_by: createdBy });
    } else {
      return res.status(200).json({ error: 'Forbidden' });
    }

    
    const projectsWithOrgDetails = await Promise.all(
      projects.map(async (project) => {
        
        const admin = await Admin.findOne({ admin_id: project.created_by }).select('organization');

        return {
          ...project.toObject(), 
          organization: admin ? admin.organization : null, 
        };
      })
    );

    res.status(200).json({ projects: projectsWithOrgDetails });
  } catch (error) {
    res.status(200).json({ code: 500, error: error.message });
  }
};



exports.getAllProjectsIdsAndNames = async (req, res) => {
  try {
    const createdBy = req.added_by;
    const role = req.role;

    let projects;

    if (role === 'superAdmin') {
      projects = await Project.find({}, { project_id: 1, projectName: 1, _id: 0 });
    } else if (role === 'Admin') {
      projects = await Project.find({ created_by: createdBy }, { project_id: 1, projectName: 1, _id: 0 });
    } else {
      return res.status(200).json({ code:403,error: 'Forbidden' });
    }

    if (projects.length === 0) {
      return res.status(200).json({ code:404, message: 'No projects found.' });
    }

    res.status(200).json(projects);
  } catch (error) {
    res.status(200).json({ code: 500, error: error.message });
  }
};


exports.updateProject = async (req, res) => {
  try {
    const { editingProjectId, formData } = req.body;
    const { projectName, project_description, start_date, end_date, tasks, teams, project_status } = formData;

    
    if (!projectName || !project_description || !start_date || !end_date) {
      return res.status(200).json({ code: 400, error: 'Missing required fields' });
    }

    const createdBy = req.added_by;  
    const role = req.role;

    
    if (role !== 'Admin') {
      return res.status(200).json({ error: 'Access denied. Only admins can update projects.' });
    }

    
    if (!editingProjectId) {
      return res.status(200).json({ code:400,error: 'Project ID is required' });
    }

    
    const project = await Project.findOne({ project_id: editingProjectId, created_by: createdBy });

    if (!project) {
      return res.status(200).json({ code: 404, error: 'Project not found' });
    }

    
    project.projectName = projectName;
    project.project_description = project_description;
    project.start_date = start_date;
    project.end_date = end_date;
    project.project_status = project_status || project.project_status;
    project.tasks = tasks || project.tasks;
    project.teams = teams || project.teams;

    
    await project.save();

    return res.status(200).json({
      message: 'Project updated successfully',
    });
  } catch (error) {
    console.error(error);
    return res.status(200).json({ code: 500, error: error.message });
  }
};


exports.deleteProject = async (req, res) => {
  try {
    const createdBy = req.added_by;  
    const role = req.role;

    
    const { projectId } = req.body;

    if (!projectId) {
      return res.status(200).json({code:400, error: 'Project ID is required' });
    }

    
    if (role !== 'Admin') {
      return res.status(200).json({ error: 'Access denied. Only admins can delete projects.' });
    }

    const deletedProject = await Project.findOneAndDelete({ created_by: createdBy },{ project_id: projectId });

    if (!deletedProject) {
      return res.status(200).json({code:404, error: 'Project not found' });
    }

    res.status(200).json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(200).json({ error: 'Server error' });
  }
};


exports.getProjectDetailsById = async (req, res) => {
  try {
    const user_id = req.userId;
    const { project_id } = req.body;

    // Fetch the project details
    const project = await Project.findOne({ project_id }).select('-created_by');
    if (!project) {
      return res.status(200).json({ code: 404, error: 'Project not found' });
    }

    // Fetch the user details
    const user = await User.findOne({ user_id });
    if (!user) {
      return res.status(200).json({ code: 404, error: 'User not found' });
    }

    // Check for position-related conditions
    if (user.position_accepted !== true) {
      return res.status(200).json({
        code: 403,
        error: 'User must have accepted the position to view project details.',
      });
    }

    // Validate tasks array
    if (user.tasks && user.tasks.length > 0) {
      const invalidTask = user.tasks.some(task => {
        return !task.task_id || !task.project_id || !task.name || !task.status || !task.priority || !task.due_date;
      });
      if (invalidTask) {
        return res.status(200).json({
          code: 400,
          error: 'Tasks array contains invalid objects. Each task must have task_id, project_id, name, status, priority, and due_date.',
        });
      }
    }


    // Return the project details
    res.status(200).json(project);
  } catch (error) {
    res.status(200).json({ code: 500, error: error.message });
  }
};



exports.accessProject = async(req, res)=> {
  try {
const added_by_admin_id = req.added_by;
    const { client_id, project_id } = req.body;
    const client = await Client.findOne({added_by_admin_id:added_by_admin_id},{ client_id: client_id });

    if (!client) {
      return res.status(200).json({code:404, error: 'Client not found' });
    }

    
    const project = await Project.findOne({ project_id:project_id });

    if (!project) {
      return res.status(200).json({code:400, error: 'Project not found' });
    }

    
    if (client.project_ids && client.project_ids.includes(project_id)) {
      return res.status(200).json({ code:400, error: 'Project already accessed to client' });
    }

    
    client.project_ids = client.project_ids ? [...client.project_ids, project_id] : [project_id];
    await client.save();

    return res.status(200).json({
      message: 'Project successfully accessed.',
    });
  } catch (error) {
    console.error(error);
    return res.status(200).json({code:500, error: error.message });
  }
}
