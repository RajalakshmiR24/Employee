const { Schema, model, default: mongoose } = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const Team = require('./Team');
const Project = require('./Project');
const User = require('./User');  
const Client = require('./Client');  
const Admin = require('./Admin');  

const superAdminSchema = new Schema({
  superAdmin_id: {
    type: String,
    default: uuidv4,
    unique: true,
  },
  
  phone_number: {
    type: String,
    required: [true, 'Phone number is required'],
    trim: true,
    minlength: [10, 'Phone number must be at least 10 digits'],
    maxlength: [15, 'Phone number cannot exceed 15 digits'],
    match: [/^[6-9][0-9]{9}$/, 'Phone number must start with 6, 7, 8, or 9 and contain only digits'],
  },
  hash: {
    type: String,
  },
  name: {
    type: String,
    required: [true, 'Name is required'],
    minlength: [3, 'Name must be at least 3 characters'],
    maxlength: [100, 'Name cannot exceed 100 characters'],
    match: [/^[A-Za-z\s]+$/, 'Name must only contain alphabets and spaces and cannot start with spaces'],
  },
  token: {
    type: String,
  },
  positions: [
    {
      position: { type: String },
      userIds: [{ type: String },{ _id: false }],
    },
  ],

  role: {
    type: String,
    enum: ['superAdmin'],
    default: 'superAdmin',
  },
  
  users: [
    {
    type: String,
    }
  ],
  clients: [
    {
    type: String,
    }
  ],
  admins: [
    {
    type: String,
    }
  ],

}, { timestamps: true });

const SuperAdmin = model('SuperAdmin', superAdminSchema);

module.exports = SuperAdmin;
