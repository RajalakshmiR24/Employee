const { Schema, model } = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const teamSchema = new Schema({
  team_id: {
    type: String,
    default: uuidv4,
    unique: true,
  },
  teamName: {
    type: String,
    required: [true, 'Team name is required'],
    trim: true,
    minlength: [3, 'Team name must be at least 3 characters'],
    maxlength: [100, 'Team name cannot exceed 100 characters'],
    validate: {
      validator: function (value) {
        
        return /^[a-zA-Z][a-zA-Z0-9 ]*$/.test(value);
      },
      message: 'Team name must start with a letter and can only contain alphanumeric characters and spaces.',
    },
  },
  created_by: {
    _id: {
      type: String,
    },
    role: {
      type: String,
      enum: ['Admin', 'superAdmin'],
    },
  },
  tasks: [
    {
      taskName: {
        type: String,
      },
      task_id: {
        type: String,
      },
    },
  ],
  members: [
    {
      member_id: {
        type: String,
      },
      role: {
        type: String,
        enum: ['User', 'Client'],
      },
      name: {
        type: String,
        required: [true, 'Member name is required'],
        trim: true,
        minlength: [2, 'Name must be at least 2 characters long'],
        maxlength: [50, 'Name cannot exceed 50 characters'],
        validate: {
          validator: function (value) {
            
            return /^[a-zA-Z][a-zA-Z ]*$/.test(value);
          },
          message: 'Name must start with a letter and can only contain alphabetic characters and spaces.',
        },
      },
      joined_at: {
        type: Date,
        default: Date.now,
      },
    },
  ],
  projects: [
    {
      projectName: {
        type: String,
      },
      project_id: {
        type: String,
      },
    },
  ],
}, { 
  timestamps: true,
  validateBeforeSave: true,  
});


teamSchema.path('projects').validate(function (projects) {
  return projects.length <= 2;
}, 'A team can have a maximum of 2 projects.');


teamSchema.path('members').validate(function (members) {
  return members.length <= 6;
}, 'A team can have a maximum of 6 members.');

const Team = model('Team', teamSchema);

module.exports = Team;
