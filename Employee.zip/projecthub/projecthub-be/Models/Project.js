const { Schema, model } = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const projectSchema = new Schema({
  project_id: {
    type: String,
    default: uuidv4,
    unique: true,
  },
  projectName: {
    type: String,
    required: [true, 'Project name is required'],
    minlength: [3, 'Project name must be at least 3 characters long'],
    maxlength: [200, 'Project name cannot exceed 200 characters'],
  },
  project_description: {
    type: String,
    required: [true, 'Project description is required'],
    minlength: [10, 'Project description must be at least 10 characters long'],
    maxlength: [1000, 'Project description cannot exceed 1000 characters'],
  },
  start_date: {
    type: Date,
    required: [true, 'Start date is required'],
    validate: {
      validator: function(value) {
        
        return value >= new Date();
      },
      message: 'Start date cannot be in the past',
    },
  },
  end_date: {
    type: Date,
    validate: {
      validator: function(value) {
        
        return !value || value >= new Date();
      },
      message: 'End date cannot be in the past',
    },
  },
  project_status: {
    type: String,
    default: function() {
      
      const now = new Date();
      if (!this.start_date) return 'Not Started'; 
      if (this.start_date > now) return 'Not Started'; 
      if (!this.end_date) return 'In Progress'; 
      if (this.end_date < now) return 'Completed'; 
      return 'In Progress'; 
    },
  },
  created_at: {
    type: Date,
    default: Date.now,
  },
  updated_at: {
    type: Date,
    default: Date.now,
  },
  tasks: [
    {
      task_id: String,
      taskName: String,
      assigned_to: [String],
    },
  ],

  created_by: {
    type: String,
  },
  teams: [{
    team_id: {
      type: String,
    },
    teamName: {
      type: String,
    },
  }],
}, { timestamps: true });

projectSchema.pre('save', function (next) {
  this.updated_at = Date.now();
  next();
});

const Project = model('Project', projectSchema);

module.exports = Project;
