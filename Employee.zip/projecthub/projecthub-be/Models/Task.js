const { Schema, model } = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const taskSchema = new Schema({
  task_id: {
    type: String,
    default: uuidv4,
    unique: true,
  },
  taskName: {
    type: String,
    unique: true,
    required: [true, 'Task name is required'],
    minlength: [3, 'Task name must be at least 3 characters long'],
    maxlength: [200, 'Task name cannot exceed 200 characters'],
    match: [/^[A-Za-z0-9\s.,!?'-]+$/, 'Task name can only contain letters, numbers, spaces, and common punctuation'], 
  },
  description: {
    type: String,
    required: [true, 'Task description is required'],
    minlength: [10, 'Task description must be at least 10 characters long'],
    maxlength: [1000, 'Task description cannot exceed 1000 characters'],
  },
  assigner_id: {
      type: String,
  },
  assigned_to: [{
    name:{
      type: String,
      required: [true, 'User ID is required for assigned to'],

    },
    user_id: {
      type: String,
      required: [true, 'User ID is required for assigned to'],
    },
    assigned_at: {
      type: Date,
      default: Date.now,
    },
  }],
  project: [{
    project_id: {
      type: String,
    },
    projectName: {
      type: String,
    },
  }],
  team: [{
    team_id: {
      type: String,
    },
    teamName: {
      type: String,
    },
  }],
  start_date: {
    type: Date,
    required: [true, 'Start date is required'],
  },
  end_date: {
    type: Date,
    required: [true, 'End date is required'],
  },
  status: {
    type: String,
    required: [true, 'Task status is required'],
    default: 'To Do',
  },
  priority: {
    type: String,
    required: [true, 'Task priority is required'],
  },
  created_at: {
    type: Date,
    default: Date.now,
  },
  updated_at: {
    type: Date,
    default: Date.now,
  },
  comments: [{
    comment_id: {
      type: String,
      default: uuidv4,
    },
    name: {
      type: String,
    },
    role:{
      type: String,
    },
    user_id: {
      type: String,  
      required: true,
    },
    message: {
      type: String,
      required: [true, 'Comment message is required'],
      minlength: [2, 'Comment message must be at least 3 characters long'],
      maxlength: [500, 'Comment message cannot exceed 500 characters'],
      match: [/^[\w\s.,!?'-]+$/, 'Comment message contains invalid characters.'], 
    },
    created_at: {
      type: Date,
      default: Date.now,
    },
  }],

}, { timestamps: true });

taskSchema.pre('save', function (next) {
  
  this.comments.forEach(comment => {
    if (!comment.comment_id) {
      comment.comment_id = uuidv4();
    }
  });

  
  this.comments = this.comments.filter(comment => comment.comment_id != null);

  
  this.updated_at = Date.now();
  next();
});

const Task = model('Task', taskSchema);

module.exports = Task;
