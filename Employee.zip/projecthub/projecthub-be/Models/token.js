const mongoose = require('mongoose');

const tokenSchema = new mongoose.Schema({
  userhash: { type: String, required: true },
  access_token: { type: String, required: true },
  refresh_token: { type: String, required: true },
  expires_at: { type: Number, required: true },
  id_token: { type: String, required: true },
  role: { 
    type: String, 
    enum: ['superAdmin', 'Admin', 'Client', 'User'], 
    default: 'user'  
  },
}, { timestamps: true });

const Token = mongoose.model('Token', tokenSchema);
module.exports = Token;
