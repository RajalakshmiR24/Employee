const { Schema, model } = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const organizationSchema = new Schema({
  organization_id: {
    type: String,
    default: uuidv4,
    unique: true,
  },
  organization_name: {
    type: String,
    required: [true, 'Organization name is required'],
    trim: true,
    minlength: [3, 'Organization name must be at least 3 characters'],
    maxlength: [100, 'Organization name cannot exceed 100 characters'],
    unique: true,
  },
  organization_address: {
    type: String,
    required: [true, 'Organization address is required'],
    trim: true,
  },
  organization_website: {
    type: String,
    required: [true, 'Organization website is required'],
    unique: true,
    match: [/^(https?:\/\/)?([\w\d-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/, 'Invalid website format'],
  },
}, { _id: true });

const boardColumnSchema = new Schema({
  column_created_by:{
    type: String,
    required: [true, 'Column name is required'],
  },
  column_name: {
    type: String,
    required: [true, 'Column name is required'],
  },
  position: {
    type: Number,
  },
}, { _id: false });

const adminSchema = new Schema({
  admin_id: {
    type: String,
    default: uuidv4,
    unique: true,
  },
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    minlength: [3, 'Name must be at least 3 characters'],
    maxlength: [50, 'Name cannot exceed 50 characters'],
  },
  phone_number: {
    type: String,
    required: [true, 'Phone number is required'],
    trim: true,
    minlength: [10, 'Phone number must be at least 10 digits'],
    maxlength: [15, 'Phone number cannot exceed 15 digits'],
    match: [/^[6-9][0-9]{9}$/, 'Phone number must start with 6, 7, 8, or 9 and contain only digits'],
  },
  hash: {
    type: String,
  },
  token: {
    type: String,
  },
  isVerifiedBySuperAdmin: {
    type: Boolean,
    required: [true, 'isVerifiedBySuperAdmin is required'],
    default: false,
  },

  positions: [
    {
      position: { type: String },
      userIds: [{ type: String }, { _id: false }]
    }
  ],


  role: {
    type: String,
    enum: ['Admin'],
    default: 'Admin'
  },
  
  added_by_admin_id: {
    type: String,
  },
  users: [
    {
    type: String,
    }
  ],
  clients: [
    {
    type: String,
    }
  ],
  board: [boardColumnSchema],

  organization: organizationSchema,
}, { timestamps: true });

const Admin = model('Admin', adminSchema);

module.exports = Admin;
