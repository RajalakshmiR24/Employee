import styled from "styled-components";

export const ToolsWrapper = styled.div`
  height: 978px;
  width: 60px;
  left: 219px; 
  top: 0px;
  border-radius: 0px;
  position: fixed;
  background: #F5F8FA;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 24px;
`;

export const Title = styled.div`
  font-size: 18px;
  font-weight: 400;
  line-height: 21px;
  color: #222222;
  margin-top: 0;
  margin-bottom: 16px;
  display: none;
`;

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const LinkWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  padding: 1px;
  position: relative;
  cursor: pointer;
  margin-top: 1px;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: white;
  }

  &:hover > div {
    visibility: visible;
    opacity: 1;
  }
`;

export const LinkIconWrapper = styled.div`
  font-size: 20px;
  color: gray;
  transition: color 0.3s ease;
`;

export const Tooltip = styled.div`
  visibility: hidden;
  position: absolute;
  top: -25px;
  left: 20%;
  transform: translateX(-50%);
  background-color: white;
  color: black;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  opacity: 0;
  transition: opacity 0.3s ease;
`;

export const HideButton = styled.button`
  background-color: #0094FF;
  color: white;
  font-size: 12px;
  padding: 10px;
  border: none;
  border-radius: 50%;
  position: fixed;
  bottom: 20px;
  left: 219px;
  cursor: pointer;
  transition: all 0.3s ease;
`;

export const ArrowIconWrapper = styled.div`
  transform: rotate(${(props) => (props.isOpen ? "180deg" : "0deg")});
  transition: transform 0.3s ease;
`;

