import { useState, useContext } from "react";
import {
  Container,
  LinkIconWrapper,
  LinkWrapper,
  Title,
  ToolsWrapper,
  Tooltip,
} from "./styles";
import { FaTasks, FaUserCircle } from "react-icons/fa";
import { Link } from "react-router-dom";
import { RoleContext } from "../../Context/RoleContext"; 

const Tools = () => {
  const [selectedLink, setSelectedLink] = useState(null);
  const { role, setstart } = useContext(RoleContext); 
  
  
  const handleLinkClick = (index) => {
    setSelectedLink(index);
    setstart(index); 
  };

  const links = [
    {
      path: `/ProjectHub/${role}/tasks`,
      icon: <FaTasks />,
      tooltip: "Tasks",
      show: true, 
    },
    {
      path: `/ProjectHub/${role}/profile`,
      icon: <FaUserCircle />,
      tooltip: "Profile",
      show: true, 
    },
  ];

  return (
    <ToolsWrapper>
      <Title>Tools</Title>
      
      <Container>
        {links
          .filter((link) => link.show) 
          .map((link, index) => (
            <Link key={index} to={link.path}>
              <LinkWrapper
                onClick={() => handleLinkClick(index)}
                style={{
                  color: selectedLink === index ? "#0094FF" : "#222222",
                }}
              >
                <LinkIconWrapper>{link.icon}</LinkIconWrapper>
                <Tooltip>{link.tooltip}</Tooltip>
              </LinkWrapper>
            </Link>
          ))}
      </Container>
    </ToolsWrapper>
  );
};

export default Tools;
