import styled from "styled-components";

export const LayoutContainer = styled.div`
  display: flex;
  flex-direction: column;

  @media (min-width: 768px) {
    flex-direction: row;
  }
`;

export const Sidebar = styled.div`
  width: 100%;
  
  @media (min-width: 768px) {
    width: 25%;
  }
`;

export const MainContent = styled.div`
  // display: flex;
  flex-direction: column;
  width: 100%;

  @media (min-width: 768px) {
    width: 75%;
  }
`;

export const ToolsNavbar = styled.div`

  @media (min-width: 768px) {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }
`;

export const OutletContainer = styled.div`
  flex-grow: 1;
  // padding: 1rem;
  overflow-y: auto;

  @media (min-width: 768px) {
    padding: 2rem;
  }
`;
