import styled from "styled-components";

export const NavbarWrapper = styled.div`
  height: 50px;
  width: 75%;
  box-shadow: 0px 2px 4px #f0f1f2;
  position: fixed;
  top: 0;
  left: 10;
  right:0;
  display: flex;
  align-items: center;
  padding: 0 20px;
  background-color: #ffffff;
  z-index: 999;

  @media (max-width: 768px) {
    padding: 0 10px;
  }
`;

export const ButtonWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;

  @media (max-width: 768px) {
    gap: 5px;
  }
`;

export const ContentsWrapper = styled.div`
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 10px;

  @media (max-width: 768px) {
    gap: 5px;
  }
`;

export const InputWrapper = styled.div`
  position: relative;

  input {
    width: 150px;

    @media (max-width: 768px) {
      width: 100px;
    }
  }
`;

export const Notification = styled.div`
  position: relative;
`;
