import React from "react";
import styled from "styled-components";

const ModalWrapper = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

const ModalContent = styled.div`
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  width: 400px;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  font-size: 12px;
  position: absolute;
  top: 10px;
  right: 10px;
  cursor: pointer;
`;

const Modal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <ModalWrapper onClick={onClose}>
      <ModalContent onClick={(e) => e.stopPropagation()}>
        <CloseButton onClick={onClose}>×</CloseButton>
        <h3>Create Task</h3>
        <form>
          <label>Task Name</label>
          <input type="text" placeholder="Task name" style={{ width: '100%', marginBottom: '10px' }} />
          <label>Task Description</label>
          <textarea placeholder="Task description" style={{ width: '100%', marginBottom: '10px' }} />
          <button type="submit" style={{ background: '#0094FF', color: '#fff', padding: '10px 20px' }}>
            Create Task
          </button>
        </form>
      </ModalContent>
    </ModalWrapper>
  );
};

export default Modal;
