import {
  NavbarWrapper,
  ButtonWrapper,
  ContentsWrapper,
  InputWrapper,
} from "./styles";
import { Button, Input } from "../../Components/styles";

const Navbar = () => {
  return (
    <NavbarWrapper>
      <ButtonWrapper>
        <Button
          width="70px"
          height="30px"
          color="#fff"
          bg="#0094FF"
          text="Add new"
        />
        <Button
          width="87px"
          height="30px"
          color="#222222"
          bg="#F5F8FA"
          text="Kanban board"
        />
      </ButtonWrapper>

      <ContentsWrapper>
        <InputWrapper>
          <Input
            name="search"
            placeholder="Search..."
            color="#8C939F"
            width="150px"
            height="30px"
            bg="#F5F8FA"
          />
        </InputWrapper>
      </ContentsWrapper>
    </NavbarWrapper>
  );
};

export default Navbar;
