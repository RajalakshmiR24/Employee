import React from "react";
import { Outlet } from "react-router-dom";
import Sidebars from "./Sidebar/Sidebar";
import Tools from "./Tools/Tools";
import { LayoutContainer, Sidebar, MainContent, ToolsNavbar, OutletContainer } from "./styles";

const AdminLayout = () => {
  return (
    <LayoutContainer>
      <Sidebar>
        <Sidebars />
      </Sidebar>

      <MainContent>
        <ToolsNavbar>
          <Tools />
        </ToolsNavbar>

        <OutletContainer>
          <Outlet />
        </OutletContainer>
      </MainContent>
    </LayoutContainer>
  );
};

export default AdminLayout;
