import styled from "styled-components";


export const SidebarWrapper = styled.div`
  width: ${({ collapsed }) => (collapsed ? "50px" : "219px")};
  height: 100vh;
  background: #0f1d40;
  position: fixed;
  top: 0;
  left: 0;
  transition: width 0.3s ease;
`;

export const Logo = styled.div`
  height: 32px;
  width: 131px;
  margin-left: 16px;
  margin-top: 26px;
  border-radius: 0px;
`;

export const InputWrapper = styled.div`
  height: 32px;
  width: 187px;
  margin-left: 16px;
  border-radius: 4px;
  margin-top: 28px;
  position: relative;
`;

export const Input = styled.input`
  height: 100%;
  width: 100%;
  border-radius: 4px;
  border: 0;
  outline: 0;
  color: #000;
  padding: 0 10px;
`;

export const Container = styled.div`
  width: 100%;
  margin: auto;
`;

export const LinkWrapper = styled.div`
  width: 100%;
  height: 34px;
  display: flex;
  align-items: center;
  margin-top: 20px;
  color: #ffffff;
  background: #2d4071;
  cursor: pointer;
`;

export const UserSvgWrapper = styled.div`
  height: 25px;
  width: 25px;
  margin-left: 16px;

  svg {
    width: 100%;
    height: 100%;
  }
`;

export const Link = styled.div`
  color: #fff;
  font-family: "Roboto";
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
  margin-left: 15px;
  list-style-type: none;  

`;

export const SeachSvgWrapper = styled.div`
  height: 12px;
  width: 12px;
  position: absolute;
  top: 7px;
  right: 11px;

  svg {
    height: 100%;
    width: 100%;
  }
`;

export const Wrapper = styled.div`
  width: 100%;
  margin: auto;
  margin-top: 20px;
  color: #fff;
  font-family: "Roboto";
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;

  svg {
    width: 10px;
    height: 5px;
    margin-left: 23px;

    path {
      fill: #fff;
    }
  }
`;

export const DropLink = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;


  p {
    margin-left: 20px;
  cursor: pointer;

  }
`;

export const DropDownWrapper = styled.div`
  color: #8c939f;
  font-family: "Roboto";
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
`;

export const Overlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const ModalWrapper = styled.div`
  width: 400px;
  background: #ffffff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
`;

export const ModalContent = styled.div`
  padding: 20px;
`;

export const ModalHeader = styled.div`
  padding: 16px;
  background: #f5f8fa;
  border-bottom: 1px solid #dfe3e6;
  font-family: "Roboto";
  font-weight: 500;
  font-size: 12px;
  color: #0f1d40;
`;

export const ModalBody = styled.div`
  padding: 16px;

  p {
    margin: 8px 0;
    font-size: 12px;
    color: #ff0000;
  }

  input {
    width: calc(100% - 20px);
    padding: 8px;
    margin-bottom: 16px;
    border: 1px solid #dfe3e6;
    border-radius: 4px;
  }

  label {
    font-size: 12px;
    margin-bottom: 8px;
    display: block;
  }

  select {
    width: 100%;
    padding: 8px;
    border: 1px solid #dfe3e6;
    border-radius: 4px;
  }
`;

export const ModalFooter = styled.div`
  padding: 16px;
  background: #f5f8fa;
  border-top: 1px solid #dfe3e6;
  display: flex;
  justify-content: flex-end;

  button {
    padding: 8px 16px;
    border-radius: 4px;
    border: none;
    cursor: pointer;
    margin-left: 8px;

    &:nth-child(1) {
      background: #ffffff;
      border: 1px solid #dfe3e6;
      color: #0f1d40;
    }

    &:nth-child(2) {
      background: #2d4071;
      color: #ffffff;
    }
  }
`;

export const ToggleButton = styled.div`
  position: absolute;
  top: 50%;
  right: ${({ collapsed }) => (collapsed ? "-15px" : "-25px")};
  transform: translateY(-50%);
  width: 30px;
  height: 30px;
  background: #2d4071;
  color: #fff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: #1e2f59;
  }
`;



export const SubmenuWrapper = styled.div`
  position: absolute;
  top: 290px;
  left: 105px;
  padding: 3px;
  border-radius: 4px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  z-index: 100;
  font-size: 12px;
  
`;

export const SubmenuItem = styled.div`
  padding: 8px 16px;
  cursor: pointer;

  &:hover {
    background-color: #1e2f59;
  }
`;


export const SubMenuWrapper = styled.div`
  position: absolute;
  top: 40px;
  left: 100%;
  padding: 8px 0;
  border-radius: 4px;
  background-color: #2d4071;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  z-index: 100;
  font-size: 12px;
  display: none;

  &:hover {
    display: block;
  }
`;



export const SubMenu = styled.div`
  position: relative;
  &:hover ${SubMenuWrapper} {
    display: block;
  }
`;
