import { useState, useEffect, useMemo, useRef } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import axiosInstance from "../../utils/axiosInstance";
import {
  Container,
  LinkWrapper,
  SidebarWrapper,
  Link,
  Wrapper,
  DropLink,
  ToggleButton,
} from "./styles";

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  
  const [roleData, setRoleData] = useState({
    name: "User",
    role: "",
    teams: ["No teams yet"],
    projects: ["No projects yet"],
    position: { status: undefined },
  });

  const fetchRef = useRef(false); 

  
  const fetchRoleData = async () => {
    try {
      const { data } = await axiosInstance.post("/api/projecthub/auth/get-details");
      const { name = "User", role = "", teams = [], projects = [], position = {} } = data;
      setRoleData({
        name: name.charAt(0).toUpperCase() + name.slice(1),
        role,
        teams: Array.isArray(teams) ? teams : ["No teams yet"],
        projects: Array.isArray(projects) ? projects : ["No projects yet"],
        position,
      });
    } catch (error) {
      alert(error.message || error.error)
    }
  };

  useEffect(() => {
    
    if (!fetchRef.current) {
      fetchRoleData();
      fetchRef.current = true; 
    }
  }, []);

  const toggleSidebar = () => setCollapsed(!collapsed);

  
  const getPathByRole = useMemo(() => {
    if (!roleData.role) return "/projecthub";

    const { role, position } = roleData;
    const basePath = `/projecthub/${role.toLowerCase()}`;
    const status = position?.status;

    switch (role) {
      case "User":
        return status === "Accepted" || status === "Pending" ? `${basePath}/tasks` : basePath;
      case "Admin":
        return `${basePath}/dashboard`;
      case "superAdmin":
        return `${basePath}/dashboard`;
      case "Client":
        return `${basePath}/clientprojects`;
      default:
        return "/projecthub";
    }
  }, [roleData]);

  
  const handleItemClick = (path) => navigate(path);

  
  const handleLogout = () => {
    const apiUrl = process.env.REACT_APP_PROJECTHUB_SERVER || window.location.origin;
    window.location.href = `${apiUrl}/api/projecthub/auth/projecthub-logout`;
    setTimeout(() => {
      localStorage.removeItem('projecthubtoken');
      localStorage.removeItem('role');
      navigate('/projecthub');
    }, 1000);
  };

  return (
    <SidebarWrapper collapsed={collapsed}>
      <ToggleButton onClick={toggleSidebar}>{collapsed ? ">" : "<"}</ToggleButton>

      {!collapsed && (
        <Container>
          <Wrapper>
            <p
              style={{
                fontWeight: "bold",
                fontSize: "1.2rem",
                margin: "1rem 0",
                cursor: "pointer",
              }}
              onClick={() => navigate(getPathByRole)}
            >
              {roleData.name
                ? `${roleData.role === "User" ? `${roleData.name} (${roleData.position?.position_name || "User"})` : `${roleData.name} (${roleData.role})`}`
                : "Welcome"}
            </p>
          </Wrapper>

          {roleData.role !== "Client" && (
            <LinkWrapper>
              <NavLink to={getPathByRole}>
                <Link>{roleData.role === "User" ? "Tasks" : "Dashboard"}</Link>
              </NavLink>
            </LinkWrapper>
          )}

          {["superAdmin", "Admin", "User"].includes(roleData.role) && (
            <>
              <Wrapper>
                <DropLink onClick={() => handleItemClick(`/projecthub/${roleData.role.toLowerCase()}/teams`)}>
                  <p>Teams</p>
                </DropLink>
              </Wrapper>

              {roleData.role !== "User" && (
                <Wrapper>
                  <DropLink onClick={() => handleItemClick(`/projecthub/${roleData.role.toLowerCase()}/projects`)}>
                    <p>Projects</p>
                  </DropLink>
                </Wrapper>
              )}
            </>
          )}

          {(roleData.role === "Admin" || roleData.role === "superAdmin") && (
            <Wrapper>
              <DropLink>
                <NavLink to={`/projecthub/${roleData.role}/members`}>
                  <Link>Members</Link>
                </NavLink>
              </DropLink>
            </Wrapper>
          )}

          {roleData.role === "superAdmin" && (
            <Wrapper>
              <DropLink>
                <NavLink to={`/projecthub/${roleData.role}/organization`}>
                  <Link> Organization</Link>
                </NavLink>
              </DropLink>
            </Wrapper>
          )}

          {roleData.role === "Client" && (
            <LinkWrapper>
              <NavLink to={`/projecthub/${roleData.role}/clientprojects`}>
                <Link>Projects</Link>
              </NavLink>
            </LinkWrapper>
          )}

          <Wrapper>
            <DropLink onClick={handleLogout}>
              <p>Logout</p>
            </DropLink>
          </Wrapper>
        </Container>
      )}
    </SidebarWrapper>
  );
};

export default Sidebar;
