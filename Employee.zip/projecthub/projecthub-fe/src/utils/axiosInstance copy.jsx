import axios from 'axios';


const axiosInstance = axios.create({
  baseURL: process.env.REACT_APP_PROJECTHUB_SERVER || window.location.origin,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});


axiosInstance.interceptors.request.use(
  (config) => {
    const projecthubtoken = localStorage.getItem('projecthubtoken');

    if (projecthubtoken) {
      config.headers.Authorization = `Bearer ${projecthubtoken}`;
    } else {
      console.warn('No projecthubtoken found, Authorization header not set');
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);


axiosInstance.interceptors.response.use(
  (response) => {

    return response;
  },
  (error) => {
    const originalRequest = error.config;

    if (error.response) {
      const { status, data } = error.response;


      if (status === 401 && !originalRequest._retry) {
        originalRequest._retry = true;
        alert('Session expired. Please log in again.');
        localStorage.removeItem('projecthubtoken');
        localStorage.removeItem('role');

        window.location.href = '/projecthub';
      }


      if (status === 400 && data.message) {
        alert(`Error: ${data.message}`);
        localStorage.removeItem('projecthubtoken');
        localStorage.removeItem('role');

        window.location.href = '/projecthub';
      }


      if (status === 500) {
        alert('Server error. Please try again later.');
        localStorage.removeItem('projecthubtoken');
        localStorage.removeItem('role');

        window.location.href = '/projecthub';
      }


    }


    return Promise.reject(error);
  }
);

export default axiosInstance;
