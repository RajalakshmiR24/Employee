import axios from "axios";

const userHash = "240ad2d581c2f6bf025553302554287292ce6e588ec146ef31803110a0014e91"; 

const axiosInstance = axios.create({
  baseURL: process.env.REACT_APP_PROJECTHUB_SERVER,
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
    'user-hash': `${userHash}`,
  },
});


axiosInstance.interceptors.request.use(
  (config) => {
    const userHash = localStorage.getItem("user-hash");
    if (userHash) {
      config.headers["user-hash"] = userHash;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response) => {
    if (response.data && [403, 301, 404].includes(response.data.code)) {
    }
    return response;
  },
  (error) => {
    const originalRequest = error.config;

    if (
      error.response &&
      error.response.status === 401 &&
      !originalRequest._retry
    ) {
      originalRequest._retry = true;

      return Promise.reject(error);
    }

    if (error.response) {
      const { status, data } = error.response;

      if (status === 403 || status === 404) {
      } else if (status === 400 && data.message) {
      } else if (status === 500) {
      }
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;
