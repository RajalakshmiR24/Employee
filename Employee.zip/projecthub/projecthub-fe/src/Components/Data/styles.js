// Datas.styles.js
import styled from 'styled-components';

export const Container = styled.div`
  max-width: 600px;
  margin: 20px auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #f9f9f9;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`;

export const Title = styled.h2`
  text-align: center;
  color: #333;
  margin-bottom: 20px;
`;

export const FileInput = styled.input`
  display: block;
  margin: 20px auto;
  padding: 10px;
  // border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 12px;
`;

export const ErrorMessage = styled.p`
  color: red;
  text-align: center;
  margin-top: 10px;
  font-size: 12px;
`;

export const Button = styled.button`
  display: block;
  margin: 20px auto;
  padding: 10px 20px;
  font-size: 12px;
  background-color: ${({ disabled }) => (disabled ? '#ccc' : '#007bff')};
  color: white;
  border: none;
  border-radius: 5px;
  cursor: ${({ disabled }) => (disabled ? 'not-allowed' : 'pointer')};
  transition: background-color 0.3s;

  &:hover {
    background-color: ${({ disabled }) => (disabled ? '#ccc' : '#0056b3')};
  }
`;

export const SuccessMessage = styled.div`
  color: green;
  text-align: center;
  margin-top: 10px;
  font-size: 12px;
`;

export const Message = styled.div`
  margin-top: 10px;
  text-align: center;
  color: ${({ isError }) => (isError ? 'red' : 'green')};
  font-size: 12px;
`;