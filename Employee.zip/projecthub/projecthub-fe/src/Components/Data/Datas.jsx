import React, { useState, useContext } from 'react';
import * as XLSX from 'xlsx';
import axiosInstance from '../../utils/axiosInstance';
import { RoleContext } from '../../Context/RoleContext';
import {
  Container, FileInput,
  ErrorMessage,
  Button,
  Message
} from './styles';

const Datas = () => {
  const { role, setstart } = useContext(RoleContext);
  const [excelData, setExcelData] = useState([]);
  const [typeError, setTypeError] = useState(null);
  const [submitMessage, setSubmitMessage] = useState('');

  const clearErrorMessage = () => {
    setTimeout(() => setTypeError(null), 2000);
  };

  const handleFileChange = (e) => {
    const fileTypes = [
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv',
    ];

    const selectedFile = e.target.files[0];

    if (selectedFile) {
      if (fileTypes.includes(selectedFile.type)) {
        setTypeError(null);
        let reader = new FileReader();
        reader.readAsArrayBuffer(selectedFile);
        reader.onload = (e) => {
          parseExcelData(e.target.result);
        };
      } else {
        setTypeError('Please select only Excel file types.');
        clearErrorMessage();
      }
    }
  };

  const parseExcelData = (fileContent) => {
    try {
      const workbook = XLSX.read(fileContent, { type: 'buffer' });
      const allData = [];

      workbook.SheetNames.forEach((sheetName) => {
        const worksheet = workbook.Sheets[sheetName];
        const data = XLSX.utils.sheet_to_json(worksheet);

        if (data.length > 0) {
          const sheetData = data.map((row) => ({
            ...row,
            SheetName: sheetName,
          }));
          allData.push(...sheetData);
        }
      });

      if (allData.length === 0) {
        throw new Error('No data found in any of the sheets.');
      }

      setExcelData(allData);
      setSubmitMessage(`Excel workbook parsed successfully! ${allData.length} rows extracted.`);
      
      // Set start to true after data is parsed
      setstart(true);

    } catch (error) {
      setTypeError(error.message ||  error.error);
      clearErrorMessage();
    }
  };

  const handleSubmit = async () => {
    try {
      if (!excelData.length) {
        setSubmitMessage('No data to submit. Please upload a valid Excel file.');
        return;
      }
      const response = await axiosInstance.post(`/api/projecthub/${role}/add-datas`, {
        excelData,
      });
      const {code,error} = response.data;

      if (code && error) {
        alert(error);
        return;
      }
      const { errors, message } = response.data;
      // setSubmitMessage(message);
      alert(message);
      // alert(success);
      if (errors.length > 0) {
        const errorMessages = errors.map(
          (err) => `Sheet: ${err.sheet}, Record: ${err.record.name}, Error: ${err.error}`
        );
        setTypeError(errorMessages.join('\n'));
        clearErrorMessage();
      } else {
        setTypeError(null);
      }

      setExcelData([]);

      // Set start to true after data is submitted
      setstart(true);

      // Clear the submit message after 3 seconds
      setTimeout(() => {
        setSubmitMessage('');
      }, 3000);
    } catch (error) {
      alert(error.message || error.error)
      clearErrorMessage();
    }
  };

  return (
    <Container>
      <FileInput type="file" accept=".xlsx, .xls, .csv" onChange={handleFileChange} />
      {typeError && <ErrorMessage>{typeError}</ErrorMessage>}
      {submitMessage && <Message isError={!excelData.length}>{submitMessage}</Message>}
      <Button onClick={handleSubmit} disabled={!excelData.length}>
        Submit Data
      </Button>
    </Container>
  );
};

export default Datas;
