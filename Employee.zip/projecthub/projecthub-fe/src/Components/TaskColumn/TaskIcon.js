import React from "react";
import styled from "styled-components";

const AddTaskButton = styled.button`
  background-color: #007bff;
  color: #fff;
  font-size: 20px;
  font-weight: bold;
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);

  &:hover {
    background-color: #0056b3;
  }
`;

const ColumnCenter = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  width: 100%;
`;

const TaskIcon = ({ onClick }) => {
  return (
    <ColumnCenter>
      <AddTaskButton onClick={onClick}>+</AddTaskButton>
    </ColumnCenter>
  );
};

export default TaskIcon;
