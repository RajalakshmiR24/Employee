import React, { useCallback, useContext, useState } from "react";
import { Column } from "./styles";
import TaskCard from "../TaskCard";
import TaskIcon from "./TaskIcon";
import axiosInstance from "../../utils/axiosInstance";
import { RoleContext } from "../../Context/RoleContext";
import AddTaskModal from "../Modal/AddTaskModal";

const TaskColumn = ({ data, onDrop }) => {
  const { role, setstart } = useContext(RoleContext);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedColumnName, setSelectedColumnName] = useState("");
  const [, setTasks] = useState([]);

  const handleDrop = useCallback(
    async (event) => {
      if (role !== "User") return;

      event.preventDefault();

      const taskId = event.dataTransfer.getData("taskId");
      const newStatus = data.label;

      if (!taskId) {
        return;
      }

      try {
        const response = await axiosInstance.post(`/api/projecthub/${role}/change-status`, {
          taskId: taskId,
          newStatus: newStatus,
        });
        const { code, error } = response.data;

        if (code && error) {
          alert(error);
          return;
        }
        setstart && setstart(true);

        onDrop && onDrop(event, data, { id: taskId, status: newStatus });
      } catch (error) {
        alert(error.message || error.error)
      }
    },
    [data, onDrop, role, setstart]
  );

  const handleColumnDragOver = (event) => {
    if (role === "User") {
      event.preventDefault();
    }
  };

  const handleModalToggle = useCallback((columnName) => {
    setSelectedColumnName(columnName);
    setIsModalOpen(true);
  }, []);

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedColumnName("");
  };

  return (
    <Column onDrop={handleDrop} onDragOver={handleColumnDragOver}>
      {data.items.map((item, index) => (
        <TaskCard
          key={`${item.id}-${index}`}
          data={item}
          draggable={role === "User"}
          onDragStart={(event, card) =>
            role === "User" && onDrop && onDrop(event, data, card)
          }
        />
      ))}
      {role === "Admin" && data.label !== "Completed" && (
        <TaskIcon onClick={() => handleModalToggle(data.label)} />
      )}
      {isModalOpen && (
        <AddTaskModal
          onAddTask={(newTask) => {
            setTasks((prevTasks) => [...prevTasks, newTask]);
          }}
          onClose={handleCloseModal}
          columnStatus={selectedColumnName}
        />
      )}
    </Column>
  );
};

export default TaskColumn;
