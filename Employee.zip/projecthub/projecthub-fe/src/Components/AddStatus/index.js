import React, { useState } from 'react';
import { Header, StatusWrapper, Input } from './styles';
import { ReactComponent as PlusSvg } from '../../assets/plusBtn.svg';
import axiosInstance from '../../utils/axiosInstance';

const AddStatus = () => {
  const [wordEntered, setWordEntered] = useState('');
  const [position, setPosition] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleFilter = (event) => {
    setWordEntered(event.target.value);
  };

  const handlePositionChange = (event) => {
    setPosition(event.target.value);
  };

  const handleCreateStatus = async () => {
    if (!wordEntered.trim()) {
      setError('Status name is required');
      return;
    }

    if (position === '' || isNaN(position) || parseInt(position) < 0) {
      setError('A valid position is required');
      return;
    }

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await axiosInstance.post('/api/projecthub/admin/create-column', {
        columnName: wordEntered,
        position: parseInt(position),
      });
      const {code,error} = response.data;

      if (code && error) {
        alert(error);
        return;
      }
      if (response.data.code === 400) {
        setError(response.data.error);
      } else {
        setSuccess('Status created successfully');
        setWordEntered('');
        setPosition(''); // Clear position input
      }
    } catch (err) {
      setError('Failed to create status. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <StatusWrapper>
      <Header>
        {wordEntered.length === 0 ? <PlusSvg /> : ''}
        <Input
          onChange={handleFilter}
          value={wordEntered}
          placeholder="Create status"
        />
        <Input
          onChange={handlePositionChange}
          value={position}
          placeholder="Enter position"
          type="number"
          min="0"
        />
        <button onClick={handleCreateStatus} disabled={loading}>
          {loading ? 'Creating...' : 'Add'}
        </button>
      </Header>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {success && <p style={{ color: 'green' }}>{success}</p>}
    </StatusWrapper>
  );
};

export default AddStatus;
