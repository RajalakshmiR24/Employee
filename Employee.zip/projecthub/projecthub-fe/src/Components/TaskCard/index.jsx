import React, { memo, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { Wrapper, Cover, Title, DateStyled } from "./styles";
import { RoleContext } from "../../Context/RoleContext";
import { formatDistanceToNow, format } from "date-fns";

const getRandomLightColor = () => {
  const r = Math.floor(Math.random() * 128 + 127);
  const g = Math.floor(Math.random() * 128 + 127);
  const b = Math.floor(Math.random() * 128 + 127);
  return `rgb(${r}, ${g}, ${b})`;
};

const TaskCard = memo(({ data, onDragStart }) => {
  const { date, status, title, id, description, start, due, team, project, user } = data;
  const navigate = useNavigate();
  const { role, setStart } = useContext(RoleContext); 

  const calculateProfessionalDate = (date) => {
    const taskDate = new Date(date);
    const dayOfWeek = format(taskDate, "EEEE");
    const timeAgo = formatDistanceToNow(taskDate, { addSuffix: true });
    return `${dayOfWeek}, ${timeAgo}`;
  };

  const randomColor = getRandomLightColor();

  const handleCardClick = () => {
    const rolePath = role?.toLowerCase() || "default";
    navigate(`/projecthub/${rolePath}/task/${encodeURIComponent(title)}`, {
      state: { data, id, description, start, due, team, project, user },
    });
    setStart(true); 
  };

  const handleDragStart = (event) => {
    if (role === "User" && onDragStart) {
      event.dataTransfer.setData("taskId", id);
      event.dataTransfer.setData("currentStatus", status);
      onDragStart(event, data);
    }
  };

  return (
    <Wrapper
      draggable={role === "User"}
      onDragStart={role === "User" ? handleDragStart : undefined}
      onClick={handleCardClick}
      style={{ backgroundColor: randomColor }}
    >
      <Cover />
      <Title
        style={{
          textDecoration: status === "Completed" ? "line-through" : "none",
        }}
      >
        {title}
      </Title>
      <DateStyled>{calculateProfessionalDate(date)}</DateStyled>
    </Wrapper>
  );
});

export default TaskCard;
