import React, { useState, useContext, useEffect } from "react";
import {
  ModalOverlay,
  ModalContent,
  ModalHeader,
  Form,
  Input,
  TextArea,
  Select,
  Button,
} from "./styles";
import { RoleContext } from "../../Context/RoleContext";
import axiosInstance from "../../utils/axiosInstance";

const AddTaskModal = ({ onAddTask, onClose, columnStatus }) => {
  const { role, setstart } = useContext(RoleContext);
  const [taskName, setTaskName] = useState("");
  const [description, setDescription] = useState("");
  const [assignedTo, setAssignedTo] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [priority, setPriority] = useState("");
  const [status] = useState(columnStatus);
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState("");
  const [teams, setTeams] = useState([]); 
  const [selectedTeam, setSelectedTeam] = useState(""); 

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.post(`/api/projecthub/${role}/user-name`);
        const { code, error } = response.data;

        if (code && error) {
          alert(error);
          return;
        }
        setUsers(response.data);
      } catch (error) {
        alert(error.message || error.error)
      }
    };

    const fetchProjects = async () => {
      try {
        const response = await axiosInstance.post(`/api/projecthub/${role}/project-name`);
        const { code, error } = response.data;

        if (code && error) {
          alert(error);
          return;
        }
        if (Array.isArray(response.data)) {
          setProjects(response.data);
        } else {
          console.error("Unexpected response format for projects:", response.data);
        }
      } catch (error) {
        alert(error.message || error.error)
      }
    };

    const fetchTeams = async () => {
      try {
        const response = await axiosInstance.post(`/api/projecthub/${role}/team-name`);
        const { code, error } = response.data;

        if (code && error) {
          alert(error);
          return;
        }
        if (Array.isArray(response.data)) {
          setTeams(response.data);
        } else {
          console.error("Unexpected response format for teams:", response.data);
        }
      } catch (error) {
        alert(error.message || error.error)
      }
    };

    fetchUsers();
    fetchProjects();
    fetchTeams(); 
    setstart(true);

  }, [role,setstart]);

  const handleSubmit = async (event) => {
    event.preventDefault();

    const taskData = {
      taskName,
      description,
      assigned_to: assignedTo ? [assignedTo] : [],
      project: selectedProject,
      team: selectedTeam, 
      start_date: startDate,
      end_date: endDate,
      priority,
      status,
    };

    try {
      const apiUrl = `/api/projecthub/${role}/create-task`;
      const response = await axiosInstance.post(apiUrl, taskData); 

      const { code, error } = response.data; 

      if (code && error) {
        alert(error);
        return;
      }

      onAddTask(taskData);
      onClose();
    } catch (error) {
      alert(error.message || error.error)
    }
  };

  return (
    <ModalOverlay>
      <ModalContent>
        <ModalHeader>Add Task</ModalHeader>
        <Form onSubmit={handleSubmit}>
          <Input
            type="text"
            placeholder="Task Name"
            value={taskName}
            onChange={(e) => setTaskName(e.target.value)}
            required
          />
          <TextArea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
          <Select value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)} required>
            <option value="">Assign To</option>
            {users.map((user) => (
              <option key={user.user_id} value={user.user_id}>
                {user.name}
              </option>
            ))}
          </Select>
          <Select value={selectedProject} onChange={(e) => setSelectedProject(e.target.value)} required>
            <option value="">Select Project</option>
            {projects.map((project) => (
              <option key={project.project_id} value={project.project_id}>
                {project.projectName}
              </option>
            ))}
          </Select>
          <Select value={selectedTeam} onChange={(e) => setSelectedTeam(e.target.value)} required>
            <option value="">Select Team</option>
            {teams.map((team) => (
              <option key={team.team_id} value={team.team_id}>
                {team.teamName}
              </option>
            ))}
          </Select>
          <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
          <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} required />
          <Input
            type="text"
            placeholder="Priority"
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            required
          />
          <Input type="text" placeholder="Status" value={status} readOnly />
          <Button type="submit">Add Task</Button>
          <Button type="button" cancel onClick={onClose}>Cancel</Button>
        </Form>
      </ModalContent>
    </ModalOverlay>
  );
};

export default AddTaskModal;
