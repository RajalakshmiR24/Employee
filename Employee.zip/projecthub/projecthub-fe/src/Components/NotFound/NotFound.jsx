import React, { useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom"; 
import { NotFoundWrapper, Message, ButtonGroup, Button } from "./styles";

const NotFound = () => {
  const navigate = useNavigate();

  
  const clearAuthAndRedirect = useCallback(async() => {
    const projecthubtoken = localStorage.getItem("projecthubtoken");
    const role = localStorage.getItem("role");
    if (projecthubtoken || role) {
      localStorage.removeItem("projecthubtoken");
      localStorage.removeItem("role");
    }
    navigate("/projecthub");
  },[navigate]);

  useEffect(() => {
    clearAuthAndRedirect();
  }, [clearAuthAndRedirect]);  

  return (
    <NotFoundWrapper>
      <Message>
        <h1>Hmmm...</h1>
        <p>
          We couldn't find this page. Maybe there is a mistake in the URL
          address? Anyway, you can go to our Homepage and start your journey
          again, or if you want to use our software, you can go directly to the
          Login page. Hope you're not gonna end up on this page again. :)
        </p>
      </Message>
      <ButtonGroup>
        <Button
          text="Go to Homepage"
          width="150px"
          height="40px"
          bg="#007bff"
          color="#fff"
          onClick={clearAuthAndRedirect} 
        />
      </ButtonGroup>
    </NotFoundWrapper>
  );
};

export default NotFound;
