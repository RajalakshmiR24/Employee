import styled from "styled-components";

export const NotFoundWrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  height: 100vh;
  background-color: #f8f9fa;
  font-family: "Roboto", sans-serif;
`;

export const Message = styled.div`
  max-width: 600px;
  margin-bottom: 20px;

  h1 {
    font-size: 36px;
    font-weight: bold;
    color: #343a40;
    margin-bottom: 10px;
  }

  p {
    font-size: 12px;
    line-height: 1.5;
    color: #6c757d;
  }
`;

export const ButtonGroup = styled.div`
  display: flex;
  gap: 20px;
`;

export const Button = ({ text, width, height, bg, color }) => {
    return (
      <button
        style={{
          width,
          height,
          backgroundColor: bg,
          color,
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        {text}
      </button>
    );
  };
  