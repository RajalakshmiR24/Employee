import React from 'react';
import { ModalContainer, ModalContent, CloseButton } from './styles'; 

const ProjectModal = ({ project, onClose }) => {
  if (!project) return null;

  return (
    <ModalContainer>
      <ModalContent>
        <h2>{project.projectName}</h2>
        <p><strong>Description:</strong> {project.project_description}</p>
        <p><strong>Start Date:</strong> {new Date(project.start_date).toLocaleDateString()}</p>
        <p><strong>End Date:</strong> {new Date(project.end_date).toLocaleDateString()}</p>
        <p><strong>Status:</strong> {project.project_status}</p>
        
        {/* Organization details */}
        {project.organization && (
          <>
            <h3>Organization Details</h3>
            <p><strong>Name:</strong> {project.organization.organization_name}</p>
            <p><strong>Address:</strong> {project.organization.organization_address}</p>
            <p><strong>Website:</strong> <a href={project.organization.organization_website} target="_blank" rel="noopener noreferrer">{project.organization.organization_website}</a></p>
          </>
        )}

        {/* Team details */}
        {project.teams && project.teams.length > 0 && (
          <>
            <h3>Teams</h3>
            <ul>
              {project.teams.map((team) => (
                <li key={team.team_id}>{team.teamName}</li>
              ))}
            </ul>
          </>
        )}

        {project.tasks && project.tasks.length > 0 && (
          <>
            <h3>Tasks</h3>
            <ul>
              {project.tasks.map((task) => (
                <li key={task.task_id}>{task.taskName}</li>
              ))}
            </ul>
          </>
        )}

        <CloseButton onClick={onClose}>Close</CloseButton>
      </ModalContent>
    </ModalContainer>
  );
};

export default ProjectModal;
