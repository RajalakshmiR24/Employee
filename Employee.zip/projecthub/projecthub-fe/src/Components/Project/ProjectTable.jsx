import React, { useState, useEffect, useContext, useCallback, useRef } from 'react';
import {
  Container,
  Title,
  Table,
  TableHeader,
  TableRow,
  TableCell,
  Button,
  Input,
  Error,
} from './styles';
import { RoleContext } from '../../Context/RoleContext';
import axiosInstance from '../../utils/axiosInstance';
import ProjectModal from './Modal/ProjectModal'; 

const ProjectTable = () => {
  const { role, setstart } = useContext(RoleContext);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    projectName: '',
    project_description: '',
    start_date: '',
    end_date: '',
  });
  const [editingProjectId, setEditingProjectId] = useState(null);
  const [selectedProject, setSelectedProject] = useState(null); 
  const [showModal, setShowModal] = useState(false); 

  const fetchRef = useRef(false);  

  
  const getEndpoint = useCallback((action) => {
    return `/api/projecthub/${role === 'Admin' ? 'admin' : 'superadmin'}/${action}`;
  }, [role]);

  const fetchProjects = useCallback(async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.post(getEndpoint('projects'));
      const { code, error } = response.data;

      if (code && error) {
        alert(error);
        return;
      }
      setProjects(Array.isArray(response.data.projects) ? response.data.projects : []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [getEndpoint]); 

  useEffect(() => {
    if (!fetchRef.current) {
      fetchProjects();
      fetchRef.current = true;
    }
    setstart(true);
  }, [role, fetchProjects, setstart]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let response;

      if (editingProjectId) {
        response = await axiosInstance.put(getEndpoint('update-project'), {
          editingProjectId,
          formData,  
        });
        const { code, error } = response.data;

        if (code && error) {
          alert(error);
          return;
        }
      } else {
        response = await axiosInstance.post(getEndpoint('create-project'), formData);
      }
      const { code, error } = response.data;

      if (code && error) {
        alert(error);
        return;
      }
      const updatedProject = response.data.project;

      if (editingProjectId) {
        setProjects((prevProjects) =>
          prevProjects.map((project) =>
            project._id === editingProjectId ? updatedProject : project
          )
        );
      } else {
        setProjects((prevProjects) => [...prevProjects, updatedProject]);
      }

      setFormData({
        projectName: '',
        project_description: '',
        start_date: '',
        end_date: '',
      });
      setShowForm(false);
      setEditingProjectId(null);
      fetchProjects();  

    } catch (err) {
      setError('Error creating or updating project');
      console.error(err);
    }
  };

  const toggleForm = () => {
    setShowForm((prev) => !prev);
    setEditingProjectId(null); 
  };

  const handleEdit = (project) => {
    setFormData({
      projectName: project.projectName,
      project_description: project.project_description,
      start_date: project.start_date,
      end_date: project.end_date,
    });
    setEditingProjectId(project.project_id);
    setShowForm(true);
  };

  const handleDelete = async (projectId) => {
    try {
      const response = await axiosInstance.delete(getEndpoint('delete-project'), { data: { projectId } });
      const { code, error } = response.data;

      if (code && error) {
        alert(error);
        return;
      }
      setProjects((prevProjects) => prevProjects.filter((project) => project.project_id !== projectId));
    } catch (err) {
      setError('Error deleting project');
      console.error(err);
    }
  };

  const handleView = (project) => {
    setSelectedProject(project);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedProject(null);
  };

  return (
    <Container>
      <Title>Project List</Title>
      {role !== 'superAdmin' && (
        <Button onClick={toggleForm}>
          {showForm ? 'Close Form' : 'Create New Project'}
        </Button>
      )}
      {error && <Error>{error}</Error>}

      {/* Conditionally render the table or form */}
      {!showForm ? (
        <Table>
          <TableHeader>
            <tr>
              <TableCell>#</TableCell>
              <TableCell>Project Name</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Start Date</TableCell>
              <TableCell>End Date</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </tr>
          </TableHeader>
          <tbody>
            {loading ? (
              <TableRow>
                <TableCell colSpan="7" style={{ textAlign: 'center' }}>
                  Loading...
                </TableCell>
              </TableRow>
            ) : projects.length === 0 ? (
              <TableRow>
                <TableCell colSpan="7" style={{ textAlign: 'center' }}>
                  No projects available.
                </TableCell>
              </TableRow>
            ) : (
              projects.map((project, index) => (
                project ? (
                  <TableRow key={project.project_id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{project.projectName}</TableCell>
                    <TableCell>{project.project_description}</TableCell>
                    <TableCell>{new Date(project.start_date).toLocaleDateString()}</TableCell>
                    <TableCell>{new Date(project.end_date).toLocaleDateString()}</TableCell>
                    <TableCell>{project.project_status}</TableCell>
                    <TableCell>
                      {role === 'superAdmin' ? (
                        <Button onClick={() => handleView(project)}>View</Button>
                      ) : (
                        <>
                          <Button onClick={() => handleEdit(project)}>Edit</Button>
                          <Button onClick={() => handleDelete(project.project_id)}>Delete</Button>
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                ) : null
              ))
            )}
          </tbody>
        </Table>
      ) : (
        <form onSubmit={handleSubmit}>
          <h2>{editingProjectId ? 'Edit Project' : 'Create New Project'}</h2>
          <Input
            type="text"
            name="projectName"
            value={formData.projectName}
            onChange={handleInputChange}
            placeholder="Project Name"
            required
          />
          <Input
            type="text"
            name="project_description"
            value={formData.project_description}
            onChange={handleInputChange}
            placeholder="Project Description"
            required
          />
          <Input
            type="date"
            name="start_date"
            value={formData.start_date}
            onChange={handleInputChange}
            required
          />
          <Input
            type="date"
            name="end_date"
            value={formData.end_date}
            onChange={handleInputChange}
            required
          />
          <Button type="submit">{editingProjectId ? 'Update Project' : 'Create Project'}</Button>
        </form>
      )}

      {/* Modal for viewing project details */}
      {showModal && (
        <ProjectModal project={selectedProject} onClose={handleCloseModal} />
      )}
    </Container>
  );
};

export default ProjectTable;
