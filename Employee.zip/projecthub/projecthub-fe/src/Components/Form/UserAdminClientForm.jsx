import React, { useState, useContext } from "react";
import { Container, InputField, SelectField, Button } from "./styles";
import { RoleContext } from "../../Context/RoleContext";
import axiosInstance from "../../utils/axiosInstance";

const UserAdminClientForm = () => {
    const { role: currentRole } = useContext(RoleContext);
    const [selectedrole, setselectedrole] = useState("");
    const [formData, setFormData] = useState({
        name: "",
        phone_number: "",
        organization_name: "",
        organization_address: "",
        organization_website: "",
        role: "",
    });

    const handleRoleChange = (e) => {
        const newRole = e.target.value;
        setselectedrole(newRole);
        setFormData((prevState) => ({
            ...prevState,
            role: newRole,
        }));
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const apiEndpoint = `/api/projecthub/${currentRole}/create`;

        try {
            const response = await axiosInstance.post(apiEndpoint, formData);

            const { code, error, message } = response.data;

            if (code && error) {
                displayMessage(error);
                return;
            }

            displayMessage(message);

            
            setFormData({
                name: "",
                phone_number: "",
                organization_name: "",
                organization_address: "",
                organization_website: "",
                role: "",
            });
            setselectedrole("");

        } catch (error) {
            displayMessage(error.message || error.error);
        }
    };

    
    const displayMessage = (message) => {
        
        const messageContainer = document.createElement('div');
        messageContainer.innerText = message;
        messageContainer.style.position = 'fixed';
        messageContainer.style.top = '20px';
        messageContainer.style.left = '50%';
        messageContainer.style.transform = 'translateX(-50%)';
        messageContainer.style.backgroundColor = '#28a745'; 
        messageContainer.style.padding = '10px';
        messageContainer.style.color = '#fff';
        messageContainer.style.borderRadius = '5px';
        messageContainer.style.zIndex = '9999';
        document.body.appendChild(messageContainer);

        
        setTimeout(() => {
            messageContainer.remove();
        }, 3000);
    };


    return (
        <Container>
            <form onSubmit={handleSubmit}>
                <SelectField name="role" value={selectedrole} onChange={handleRoleChange}>
                    <option value="">Select role</option>
                    <option value="User">User</option>
                    {currentRole !== "Admin" && <option value="Admin">Admin</option>}
                    <option value="Client">Client</option>
                </SelectField>


                <InputField
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Name"
                    required
                />

                <InputField
                    type="text"
                    name="phone_number"
                    value={formData.phone_number}
                    onChange={handleInputChange}
                    placeholder="Phone Number"
                    maxLength={10}
                    minLength={10}
                    required
                />

                {selectedrole === "Admin" && (
                    <>
                        <InputField
                            type="text"
                            name="organization_name"
                            value={formData.organization_name}
                            onChange={handleInputChange}
                            placeholder="Organization Name"
                            required
                        />

                        <InputField
                            type="text"
                            name="organization_address"
                            value={formData.organization_address}
                            onChange={handleInputChange}
                            placeholder="Organization Address"
                            required
                        />

                        <InputField
                            type="text"
                            name="organization_website"
                            value={formData.organization_website}
                            onChange={handleInputChange}
                            placeholder="Organization Website"
                            required
                        />
                    </>
                )}

                <Button type="submit">Submit</Button>
            </form>
        </Container>
    );
};

export default UserAdminClientForm;
