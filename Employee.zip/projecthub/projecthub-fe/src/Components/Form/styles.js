// StyledComponents.js
import styled from "styled-components";

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
`;

export const InputLabel = styled.label`
  margin-top: 10px;
  font-size: 12px;
  font-weight: bold;
`;

export const InputField = styled.input`
  padding: 10px;
  margin-top: 5px;
  width: 300px;
  font-size: 12px;
  border-radius: 5px;
  border: 1px solid #ccc;
`;

export const SelectField = styled.select`
  padding: 10px;
  margin-top: 10px;
  width: 320px;
  font-size: 12px;
  border-radius: 5px;
  border: 1px solid #ccc;
`;

export const Button = styled.button`
  padding: 10px 20px;
  margin-top: 20px;
  font-size: 12px;
  border-radius: 5px;
  background-color: #4caf50;
  color: white;
  border: none;
  cursor: pointer;

  &:hover {
    background-color: #45a049;
  }
`;
