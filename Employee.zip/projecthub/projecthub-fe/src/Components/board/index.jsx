import React, { useState, useCallback, useEffect, useContext } from "react";
import {
  TaskCount,
  TaskContent,
  Header,
  TasksWrapper,
  Title,
  Wrapper,
  TitleWrapper,
} from "./styles";
import axiosInstance from "../../utils/axiosInstance";
import TaskColumn from "../TaskColumn";
import {
  addCardToColumn,
  removeCardFromColumn,
  moveCardInColumn,
} from "../../helpers/index";
import { RoleContext } from "../../Context/RoleContext";

const Board = () => {
  const [boardData, setBoardData] = useState([]);
  const [currentCard, setCurrentCard] = useState(null);
  const [currentColumn, setCurrentColumn] = useState(null);
  const [error, setError] = useState(null);
  const { role, setstart } = useContext(RoleContext);

  const fetchColumnsAndTasks = useCallback(async () => {
    if (!role) {
      return;
    }

    try {
      const columnsResponse = await axiosInstance.post(`/api/projecthub/${role}/columns`);
      const tasksResponse = await axiosInstance.post(`/api/projecthub/${role}/tasks`);
      const { code, error } = columnsResponse.data || tasksResponse.data;

      if (code && error) {
        alert(error);
        return;
      }

      const columns = columnsResponse.data.columns
        .sort((a, b) => a.position - b.position) // Sort columns by position
        .map((column) => ({
          id: column._id,
          label: column.column_name,
          items: [],
        }));

      tasksResponse.data.forEach((task) => {
        const columnIndex = columns.findIndex(
          (col) => col.label.toLowerCase() === task.status.toLowerCase()
        );
        if (columnIndex !== -1) {
          columns[columnIndex].items.push({
            id: task.task_id,
            title: task.taskName,
            date: task.start_date,
            status: task.status,
            style: task.priority,
            start: task.start_date,
            due: task.end_date,
            description: task.description,
            assigned_to: task.assigned_to,
            project: task.project,
            team: task.team,
          });
        }
      });

      setBoardData(columns);
    } catch (err) {
      console.error("Error fetching columns and tasks:", err);
      setError(
        err.response?.data?.message ||
          "Failed to fetch data. Please check your connection and try again."
      );
    }
  }, [role]);

  useEffect(() => {
    fetchColumnsAndTasks();
    setstart(true);
  }, [fetchColumnsAndTasks, setstart]);

  const handleDrop = useCallback(
    (event, column, card) => {
      if (role !== "User") return;
      event.stopPropagation();

      if (!(currentCard && currentColumn)) return;

      const toIndex = card ? column.items.indexOf(card) : column.items.length;
      const fromIndex = currentColumn.items.indexOf(currentCard);
      const isSameColumn = column.id === currentColumn.id;

      setBoardData((prevState) =>
        prevState.map((prevCol) => {
          if (isSameColumn && prevCol.id === currentColumn.id) {
            return moveCardInColumn(currentColumn, fromIndex, toIndex);
          }

          if (prevCol.id === currentColumn.id) {
            return removeCardFromColumn(currentColumn, fromIndex);
          }

          if (prevCol.id === column.id) {
            return addCardToColumn(column, toIndex, currentCard);
          }

          return prevCol;
        })
      );
      setCurrentCard(null);
      setCurrentColumn(null);
    },
    [currentCard, currentColumn, role]
  );

  const handleDragStart = useCallback(
    (_, column, card) => {
      if (role !== "User") return;
      setCurrentCard(card);
      setCurrentColumn(column);
    },
    [role]
  );

  const handleDragOver = useCallback(
    (event) => {
      if (role !== "User") return;
      event.preventDefault();
    },
    [role]
  );

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <TaskContent>
      {/* <----------- Header ----------------> */}
      <Header>
        {boardData.map(({ id, label, items }) => (
          <TitleWrapper key={id}>
            <Wrapper>
              <Title>{label}</Title>
              <TaskCount>{items.length}</TaskCount>
            </Wrapper>
          </TitleWrapper>
        ))}
      </Header>

      {/* <----------- Columns of Task ----------------> */}
      <TasksWrapper>
        {boardData.map((item) => (
          <TaskColumn
            key={item.id}
            data={item}
            onDrop={handleDrop}
            onDragStart={handleDragStart}
            onDragOver={handleDragOver}
            isDraggable={role === "User"}
          />
        ))}
      </TasksWrapper>
    </TaskContent>
  );
};

export default Board;
