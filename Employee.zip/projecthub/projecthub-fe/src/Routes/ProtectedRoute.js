import React from "react";
import { Navigate } from "react-router-dom";

const isAuthenticated = () => {
  // const projecthubtoken = localStorage.getItem("projecthubtoken");
  const projecthubtoken = localStorage.getItem("user-hash");

  return !!projecthubtoken; 
};

const ProtectedRoute = ({ children }) => {

  if (!isAuthenticated()) {
    localStorage.removeItem('projecthubtoken');
    return <Navigate to="/projecthub" />;
  }

  return children;  
};

export default ProtectedRoute;
