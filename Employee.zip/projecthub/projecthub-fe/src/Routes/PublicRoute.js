import React from "react";
import { Navigate } from "react-router-dom";

const PublicRoute = ({ element }) => {
  // const isAuthenticated = !!localStorage.getItem("projecthubtoken");
  const isAuthenticated = !!localStorage.getItem("user-hash");


  if (isAuthenticated) {
    return <Navigate to="/projecthub" />;
  }

  return element;
};

export default PublicRoute;
