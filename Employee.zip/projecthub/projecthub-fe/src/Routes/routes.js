import { createBrowserRouter, Navigate } from "react-router-dom";

import Task from "../Pages/MainPage/index";

import NotFound from "../Components/NotFound/NotFound";
import Landing from "../Pages/LandingPage/Landing";
import Projects from "../Pages/Projects/Projects";

import Auth from "../Pages/Auth/Auth";
import Profile from "../Pages/Profile/Profile";
import EntitiesMember from "../Pages/Entities/EntitiesTable/MemberEntity";

import Dashboard from "../Pages/Dashboard/Dashboard";
import Teams from "../Pages/Teams/Teams";
import TaskDetails from "../Pages/TaskDetails/TaskDetails";
import UserTeams from "../Pages/Teams/UserTeams/UserTeams";
import ClientProject from "../Pages/ClientProject/client";
import Organization from "../Pages/Organization/Organizations";

import ProtectedRoute from "./ProtectedRoute";
import PublicRoute from "./PublicRoute";
import SuperAdminLayout from "../Layouts/SuperAdminLayout";
import AdminLayout from "../Layouts/AdminLayout";
import UserLayout from "../Layouts/UserLayout";
import ClientLayout from "../Layouts/ClientLayout";



const superAdminRoutes = [
  { index: true, element: <Dashboard /> },
  { path: "dashboard", element: <Dashboard /> },
  { path: "organization", element: <Organization /> },
  { path: "tasks", element: <Task /> },
  { path: "task/:taskName", element: <TaskDetails /> },
  { path: "members", element: <EntitiesMember /> },
  { path: "projects", element: <Projects /> },
  { path: "teams", element: <Teams /> },
  { path: "profile", element: <Profile /> },
];

const adminRoutes = [
  { index: true, element: <Dashboard /> },
  { path: "dashboard", element: <Dashboard /> },
  { path: "tasks", element: <Task /> },
  { path: "task/:taskName", element: <TaskDetails /> },
  { path: "members", element: <EntitiesMember /> },
  { path: "projects", element: <Projects /> },
  { path: "teams", element: <Teams /> },
  { path: "profile", element: <Profile /> },
];

const userRoutes = [
  { index: true, element: <Task /> },
  { path: "tasks", element: <Task /> },
  { path: "task/:taskName", element: <TaskDetails /> },
  { path: "projects", element: <Projects /> },
  { path: "userteams", element: <UserTeams /> },
  { path: "profile", element: <Profile /> },
];

const clientRoutes = [
  { index: true, element: <ClientProject /> },
  { path: "clientprojects", element: <ClientProject /> },
  { path: "task/:taskName", element: <TaskDetails /> },
  { path: "tasks", element: <Task /> },
  { path: "profile", element: <Profile /> },
];

export default createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/projecthub" />,
  },
  {
    path: "/projecthub",
    element: <Landing />,
  },

  {
    path: "/projecthub/auth/start",
    element: (
      <PublicRoute element={<Auth/>} />
       
    ),
  },
  {
    path: "/projecthub/superAdmin",
    element: (
      <ProtectedRoute role="superAdmin" >
        <SuperAdminLayout />
      </ProtectedRoute>
    ),
    children: superAdminRoutes,
  },
  {
    path: "/projecthub/Admin",
    element: (
      <ProtectedRoute role="Admin">
        <AdminLayout />
      </ProtectedRoute>
    ),
    children: adminRoutes,
  },
  {
    path: "/projecthub/User",
    element: (
      <ProtectedRoute role="User">
        <UserLayout />
      </ProtectedRoute>
    ),
    children: userRoutes,
  },
  {
    path: "/projecthub/Client",
    element: (
      <ProtectedRoute role="Client">
        <ClientLayout />
      </ProtectedRoute>
    ),
    children: clientRoutes,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);
