export const TASK_TYPE = 'task'
export const COLUMN_STATUS = {
    newTask:"newTask",
    inProgress:"inProgress",
    scheduled:"scheduled",
    completed:"completed"
}