import React from "react";
import { RouterProvider } from "react-router-dom";
import router  from "./Routes/routes";
// import Listener from "./utils/KeyEventListener";

const App = () => {
  return (
    <div>
          {/* <Listener />   */}

      <RouterProvider router={router} />
    </div>
  );
};

export default App;
