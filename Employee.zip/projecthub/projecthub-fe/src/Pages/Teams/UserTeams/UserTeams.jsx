import React, { useEffect, useState } from "react";
import {
  TableWrapper,
  Table,
  TableHeader,
  TableHeaderCell,
  TableBody,
  TableRow,
  TableCell,
} from "./styles";
import axiosInstance from "../../../utils/axiosInstance";

const UserTeams = () => {
  const [teams, setTeams] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [loadingProject, setLoadingProject] = useState(false);
  const fetchTeams = async () => {
    try {
      const response = await axiosInstance.post(
        "/api/projecthub/user/assigned-teams"
      );
      // const {code,error} = response.data;

      // if (code && error) {
      //   alert(error);
      //   return;
      // }
      if (response.data) {
        setTeams(response.data);
      }
    } catch (error) {
      alert(error.message || error.error)
    }
  };
  useEffect(() => {
    fetchTeams();
  }, []);

  const handleProjectClick = async (projectId) => {
    setLoadingProject(true);
    try {
      const response = await axiosInstance.post(
        "/api/projecthub/user/project_id",
        {
          project_id: projectId,
        }
      );
      const {code,error} = response.data;

      if (code && error) {
        alert(error);
        return;
      }
      if (response.data) {
        setSelectedProject(response.data);
      }
    } catch (error) {
      alert(error.message || error.error)
    } finally {
      setLoadingProject(false);
    }
  };

  return (
    <TableWrapper>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHeaderCell>#</TableHeaderCell> {/* Index Column */}
            <TableHeaderCell>Team Name</TableHeaderCell>
            <TableHeaderCell>Members</TableHeaderCell>
            <TableHeaderCell>Projects</TableHeaderCell>
          </TableRow>
        </TableHeader>
        <TableBody>
          {teams.length > 0 ? (
            teams.map((team, idx) => (
              <TableRow key={team.team_id}>
                <TableCell>{idx + 1}</TableCell> {/* Display index */}
                <TableCell>{team.teamName}</TableCell>
                <TableCell>
                  {team.members.map((member, memberIdx) => (
                    <div key={memberIdx}>
                      {member.name} - {member.role}
                    </div>
                  ))}
                </TableCell>
                <TableCell>
                  {team.projects.map((project, projectIdx) => (
                    <button
                      key={projectIdx}
                      onClick={() => handleProjectClick(project.project_id)}
                    >
                      {project.projectName}
                    </button>
                  ))}
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan="4">No teams available.</TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
      {loadingProject && <div>Loading project details...</div>}{" "}
      {/* Loading indicator */}
      {selectedProject && (
        <div>
          <h2>Project Details</h2>
          <p>
            <strong>Name:</strong> {selectedProject.projectName}
          </p>
          <p>
            <strong>Description:</strong> {selectedProject.project_description}
          </p>
          <p>
            <strong>Status:</strong> {selectedProject.project_status}
          </p>
          <p>
            <strong>Start Date:</strong>{" "}
            {new Date(selectedProject.start_date).toLocaleDateString()}
          </p>
          <p>
            <strong>End Date:</strong>{" "}
            {new Date(selectedProject.end_date).toLocaleDateString()}
          </p>
        </div>
      )}
    </TableWrapper>
  );
};

export default UserTeams;
