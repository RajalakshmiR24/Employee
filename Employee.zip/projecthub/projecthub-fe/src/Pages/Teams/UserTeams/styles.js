import styled from "styled-components";


export const TableWrapper = styled.div`
  width: 100%;
  overflow-x: auto;
  margin-top: 20px;
`;


export const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
  background-color: white;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  overflow: hidden;
`;


export const TableHeader = styled.thead`
  background-color: #12277bff; 
  color: white;
  font-weight: 600;
  font-size: 12px;
  text-transform: uppercase;
`;


export const TableHeaderCell = styled.th`
  padding: 12px;
  text-align: left;
  border-bottom: 2px solid #ddd;
`;


export const TableBody = styled.tbody``;


export const TableRow = styled.tr`
  &:nth-child(even) {
    background-color: #f9f9f9; 
  }
`;


export const TableCell = styled.td`
  padding: 10px;
  font-size: 12px;
  color: #333;
  border-bottom: 1px solid #ddd;
  word-break: break-word; 
`;


export const ActionDropdownWrapper = styled.div`
  position: relative;
  display: flex;
  justify-content: center;
`;


export const ActionDropdown = styled.div`
  cursor: pointer;
  padding: 6px 12px;
  background-color: #12277bff;
  color: white;
  border-radius: 5px;
  font-size: 12px;
  transition: background-color 0.3s ease;
  

`;





export const DropdownItem = styled.div`
  padding: 8px 12px;
  font-size: 12px;
  color: #333;
  cursor: pointer;
  
  &:hover {
    background-color: #f5f8fa;
  }
`;


export const DropdownItemText = styled.span`
  display: block;
  padding: 4px 0;
`;

