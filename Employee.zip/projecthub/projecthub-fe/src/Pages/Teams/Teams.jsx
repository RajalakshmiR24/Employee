import { useState, useEffect, useCallback, useMemo, useContext, useRef } from "react";
import axiosInstance from "../../utils/axiosInstance";
import {
  Container,
  Title,
  Table,
  TableHeader,
  TableRow,
  TableCell,
  Button,
  Input,
  Error,
  ModalOverlay,
  ModalContainer,
  ModalHeader,
  ModalTitle,
  ModalCloseButton,
  ModalBody,
} from "./styles";
import { RoleContext } from "../../Context/RoleContext";

const Teams = () => {
  const [teams, setTeams] = useState([]);
  const [teamName, setTeamName] = useState("");
  const [editingTeam, setEditingTeam] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  const [members, setMembers] = useState([]);
  const [currentPage] = useState(1);
  const [teamsPerPage] = useState(10);
  const [showModal, setShowModal] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const { role, setstart } = useContext(RoleContext);

  const fetchRef = useRef(false); 

  const fetchData = useCallback(async () => {
    if (fetchRef.current) return;

    if (role !== 'Admin' && role !== 'superAdmin') {
      return;
    }

    try {
      setLoading(true);
      fetchRef.current = true;

      const endpoint = `/api/projecthub/${role === 'Admin' ? 'admin' : 'superadmin'}`;

      const [teamsResponse, tasksResponse, projectsResponse, membersResponse] =
        await Promise.all([
          axiosInstance.post(`${endpoint}/teams`),
          axiosInstance.post(`${endpoint}/task-name`),
          axiosInstance.post(`${endpoint}/project-name`),
          axiosInstance.post(`${endpoint}/user-name`),
        ]);

      if (Array.isArray(teamsResponse.data)) {
        setTeams(
          teamsResponse.data.map((team) => ({
            ...team,
            tasks: Array.isArray(team.tasks) ? team.tasks : [],
            projects: Array.isArray(team.projects) ? team.projects : [],
            members: Array.isArray(team.members) ? team.members : [],
          }))
        );
      }

      setTasks(Array.isArray(tasksResponse.data) ? tasksResponse.data : []);
      setProjects(Array.isArray(projectsResponse.data) ? projectsResponse.data : []);
      setMembers(Array.isArray(membersResponse.data) ? membersResponse.data : []);
    } catch (error) {
      setError(error.message || error.error);
    } finally {
      setLoading(false);
    }
  }, [role]);

  useEffect(() => {
    fetchData();
    setstart(true);
  }, [role, setstart, fetchData]);

  const currentTeams = useMemo(() => {
    const indexOfLastTeam = currentPage * teamsPerPage;
    const indexOfFirstTeam = indexOfLastTeam - teamsPerPage;
    return teams.slice(indexOfFirstTeam, indexOfLastTeam);
  }, [teams, currentPage, teamsPerPage]);

  const saveTeam = async (e) => {
    e.preventDefault();
    if (!teamName.trim()) {
      setError("Team name is required.");
      return;
    }

    if (role !== 'Admin' && role !== 'superAdmin') {
      setError("Role undefined. You do not have permission to create or update teams.");
      return;
    }

    try {
      let response;
      const endpoint = `/api/projecthub/${role === 'Admin' ? 'admin' : 'superadmin'}`;

      if (editingTeam) {
        response = await axiosInstance.put(`${endpoint}/updates`, {
          teamId: editingTeam.team_id,
          teamName,
        });
        const { code, error } = response.data;
        if (code && error) {
          alert(error);
          return;
        }
        setTeams((prevTeams) =>
          prevTeams.map((team) =>
            team._id === editingTeam._id ? response.data.team : team
          )
        );
        setEditingTeam(null);
      } else {
        response = await axiosInstance.post(`${endpoint}/create-team`, {
          teamName,
        });
        fetchData();
        const { code, error } = response.data;
        if (code && error) {
          alert(error);
          return;
        }
        setTeams((prevTeams) => [...prevTeams, response.data.team]);
      }

      setTeamName("");
      setError("");
    } catch (error) {
      setError(error.message || error.error);
    }
  };

  const deleteTeam = async (teamId) => {
    try {
      if (role !== 'Admin' && role !== 'superAdmin') {
        setError("Role undefined. You do not have permission to delete teams.");
        return;
      }

      const endpoint = `/api/projecthub/${role === 'Admin' ? 'admin' : 'superadmin'}`;
      let response = await axiosInstance.post(`${endpoint}/delete-team`, { teamId });
      const { code, error } = response.data;
      if (code && error) {
        alert(error);
        return;
      }
      setTeams((prevTeams) => prevTeams.filter((team) => team._id !== teamId));
      fetchData();
    } catch (error) {
      setError(error.message || error.error);
    }
  };

  const startEditing = (team) => {
    setEditingTeam(team);
    setTeamName(team?.teamName || "");
  };

  const openModal = (team) => {
    setSelectedTeam(team);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedTeam(null);
  };

  return (
    <Container>
      {error && <Error>{error}</Error>}
      <Title>
        Teams {role}
        {role !== "User" && (
          <form onSubmit={saveTeam}>
            <Input
              type="text"
              placeholder="Enter team name"
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
            />
            <Button type="submit">{editingTeam ? "Update Team" : "Create Team"}</Button>
            {editingTeam && (
              <Button type="button" onClick={() => {
                setEditingTeam(null);
                setTeamName("");
              }}>
                Cancel
              </Button>
            )}
          </form>
        )}
      </Title>

      {loading ? (
        <p>Loading teams...</p>
      ) : (
        <>
          <Table>
            <TableHeader>
              <tr>
                <TableCell>#</TableCell>
                <TableCell>Team Name</TableCell>
                {/* <TableCell>Tasks</TableCell> */}
                <TableCell>Projects</TableCell>
                <TableCell>Members</TableCell>
                <TableCell>Created At</TableCell>
                <TableCell>Actions</TableCell>
              </tr>
            </TableHeader>
            <tbody>
              {currentTeams.length > 0 ? (
                currentTeams.map((team, idx) => (
                  <TableRow key={team?.team_id || "unknown"}>
                    <TableCell>{currentPage * teamsPerPage - teamsPerPage + idx + 1}</TableCell>
                    <TableCell>
                      <Button onClick={() => openModal(team)}>{team?.teamName || "Unnamed Team"}</Button>
                    </TableCell>
                    {/* <TableCell>
                      <select
                        onChange={(e) => {
                          const taskId = e.target.value;
                          if (taskId) {
                            const selectedTask = tasks.find((task) => task.task_id === taskId);
                            if (selectedTask) {
                              const taskName = selectedTask.taskName;
                              axiosInstance
                                .put(`/api/projecthub/${role === 'Admin' ? 'admin' : 'superadmin'}/updates`, {
                                  teamId: team?.team_id,
                                  taskId,
                                  taskName,
                                  teamName: team?.teamName,
                                })
                                .then(() => fetchData())
                                .catch((err) => alert("Error assigning task:", err));
                            }
                          }
                        }}
                      >
                        <option value="">Select Task</option>
                        {tasks.map((task) => (
                          <option key={task.task_id} value={task.task_id}>{task.taskName}</option>
                        ))}
                      </select>
                    </TableCell> */}
                    <TableCell>
                      <select
                        onChange={(e) => {
                          const projectId = e.target.value;
                          const selectedProject = projects.find((project) => project.project_id === projectId);
                          const projectName = selectedProject?.projectName;
                          if (projectId && projectName) {
                            axiosInstance
                              .put(`/api/projecthub/${role === 'Admin' ? 'admin' : 'superadmin'}/updates`, {
                                teamId: team?.team_id,
                                projectId,
                                projectName,
                                teamName: team?.teamName,
                              })
                              .then(() => fetchData())
                              .catch((err) => alert("Error assigning project:", err));
                          }
                        }}
                      >
                        <option value="">Select Project</option>
                        {projects.map((project) => (
                          <option key={project.project_id} value={project.project_id}>{project.projectName}</option>
                        ))}
                      </select>
                    </TableCell>
                    <TableCell>
                      <select
                        onChange={(e) => {
                          const memberId = e.target.value;
                          const selectedMember = members.find((member) => member.user_id === memberId);
                          const memberName = selectedMember?.name;
                          if (memberId && memberName) {
                            axiosInstance
                              .put(`/api/projecthub/${role === 'Admin' ? 'admin' : 'superadmin'}/updates`, {
                                teamId: team?.team_id,
                                userId: memberId,
                                memberName,
                                teamName: team?.teamName,
                              })
                              .then(() => fetchData())
                              .catch((err) => alert("Error assigning member:", err));
                          }
                        }}
                      >
                        <option value="">Select Member</option>
                        {members.map((member) => (
                          <option key={member.user_id} value={member.user_id}>{member.name}</option>
                        ))}
                      </select>
                    </TableCell>
                    <TableCell>
                      {team?.createdAt ? new Date(team.createdAt).toLocaleDateString() : "Unknown"}
                    </TableCell>
                    <TableCell>
                      <Button onClick={() => startEditing(team)}>Edit</Button>
                      <Button onClick={() => deleteTeam(team?.team_id)}>Delete</Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan="7">No teams found.</TableCell>
                </TableRow>
              )}
            </tbody>
          </Table>

          {showModal && selectedTeam && (
            <ModalOverlay>
              <ModalContainer>
                <ModalHeader>
                  <ModalTitle>Team Details</ModalTitle>
                  <ModalCloseButton onClick={closeModal}>X</ModalCloseButton>
                </ModalHeader>
                <ModalBody>
                  <Table>
                    <TableHeader>
                      <tr>
                        <TableCell>Team Name</TableCell>
                        <TableCell>Tasks</TableCell>
                        <TableCell>Projects</TableCell>
                        <TableCell>Members</TableCell>
                      </tr>
                    </TableHeader>
                    <tbody>
                      <TableRow>
                        <TableCell>{selectedTeam.teamName}</TableCell>
                        <TableCell>
                          {selectedTeam.tasks.length > 0
                            ? selectedTeam.tasks.map((task) => <p key={task.task_id}>{task.taskName}</p>)
                            : <p>No tasks assigned</p>}
                        </TableCell>
                        <TableCell>
                          {selectedTeam.projects.length > 0
                            ? selectedTeam.projects.map((project) => <p key={project.project_id}>{project.projectName}</p>)
                            : <p>No projects assigned</p>}
                        </TableCell>
                        <TableCell>
                          {selectedTeam.members.length > 0
                            ? selectedTeam.members.map((member) => <p key={member.member_id}>{member.name}</p>)
                            : <p>No members</p>}
                        </TableCell>
                      </TableRow>
                    </tbody>
                  </Table>
                </ModalBody>
              </ModalContainer>
            </ModalOverlay>
          )}
        </>
      )}
    </Container>
  );
};

export default Teams;
