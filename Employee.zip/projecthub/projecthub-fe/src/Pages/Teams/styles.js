// styles.js

import styled from "styled-components";

export const Container = styled.div`
  max-width: 1200px;
  padding: 1rem 2rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 0 auto;
  position: relative;
`;

export const Title = styled.h1`
  text-align: center;
  color: #1d3557;
  font-size: 1.5rem; /* Reduced font size */
  margin-bottom: 2rem;
  font-weight: bold;
`;

export const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 2rem;
`;

export const TableHeader = styled.thead`
  background-color: #457b9d;
  color: white;
`;

export const TableRow = styled.tr`
  background-color: #f9f9f9;
  &:hover {
    background-color: #e0f7fa;
  }
`;

export const TableCell = styled.td`
  padding: 1rem;
  border: 1px solid #dce4ef;
  text-align: center;
`;

export const Button = styled.button`
  padding: 0.5rem 1rem; /* Reduced button size */
  background-color: #457b9d;
  color: #ffffff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.875rem; /* Smaller font size */
  transition: background-color 0.3s, transform 0.2s;

  &:hover {
    background-color: #1d3557;
    transform: scale(1.05);
  }

  &:not(:last-child) {
    margin-right: 0.5rem;
  }
`;

export const Input = styled.input`
  padding: 0.75rem;
  margin-bottom: 1rem;
  border: 1px solid #dce4ef;
  border-radius: 8px;
  font-size: 0.875rem; /* Reduced font size */
  width: 250px;

  &:focus {
    outline: none;
    border-color: #457b9d;
    box-shadow: 0 0 0 2px rgba(69, 123, 157, 0.3);
  }
`;

export const Error = styled.div`
  color: #e63946;
  margin-bottom: 1rem;
  text-align: center;
  font-size: 0.875rem;
`;

export const Pagination = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 2rem;
`;

export const PaginationButton = styled.button`
  padding: 0.5rem 1rem;
  margin: 0 0.5rem;
  background-color: #457b9d;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.875rem;

  &:hover {
    background-color: #1d3557;
  }

  &:disabled {
    background-color: #ccc;
    cursor: not-allowed;
  }
`;
export const Select = styled.select`
  padding: 0.75rem; /* Adjust padding for better appearance */
  margin: 0.5rem 0; /* Add spacing around select */
  border: 1px solid #dce4ef; /* Light border to match the theme */
  border-radius: 8px; /* Rounded corners for consistency */
  font-size: 0.875rem; /* Match the font size of other components */
  width: 100%; /* Full width for responsive design */
  background-color: #ffffff; /* White background */
  color: #1d3557; /* Text color to match theme */
  cursor: pointer;
  transition: border-color 0.3s, box-shadow 0.3s;

  &:focus {
    outline: none;
    border-color: #457b9d; /* Highlighted border color on focus */
    box-shadow: 0 0 0 2px rgba(69, 123, 157, 0.3); /* Subtle shadow effect */
  }

  &:hover {
    border-color: #457b9d; /* Change border color on hover */
  }

  & option {
    color: #1d3557; /* Text color for options */
    background-color: #ffffff; /* White background for options */
  }
`;

export const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
`;

export const ModalContainer = styled.div`
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  max-width: 600px;
  width: 100%;
`;

export const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

export const ModalTitle = styled.h2`
  margin: 0;
`;

export const ModalCloseButton = styled.button`
  background-color: transparent;
  border: none;
  font-size: 18px;
  cursor: pointer;
  padding: 0;
`;

export const ModalBody = styled.div`
  margin-top: 20px;
`;
