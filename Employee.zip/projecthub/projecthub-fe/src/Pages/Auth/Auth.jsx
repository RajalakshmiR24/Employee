import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axiosInstance from '../../utils/axiosInstance';

const Auth = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const urlParams = new URLSearchParams(location.search);
  const code = urlParams.get('code');
  const state = urlParams.get('state');
  const iss = urlParams.get('iss');

  const [, setRole] = useState(null);

  const handleNavigate = useCallback((role) => {
    try {
      switch (role) {
        case 'superAdmin':
          navigate('/projecthub/superAdmin');
          break;
        case 'Admin':
          navigate('/projecthub/admin');
          break;
        case 'User':
          navigate('/projecthub/user');
          break;
        case 'Client':
          navigate('/projecthub/client');
          break;
        default:
          navigate('/projecthub');
          break;
      }
    } catch (error) {
      alert(error.message || error.error)
    }
  }, [navigate]);

  const callRef = useRef(0);
  useEffect(() => {
    if (!code || !state || !iss) {
      navigate('/ProjectHub');
      return;
    }

    const formData = new URLSearchParams();
    formData.append('code', code);
    formData.append('state', state);
    formData.append('iss', iss);

    if (callRef.current === 0 && !localStorage.projecthubtoken) {
      axiosInstance
        .post('/api/projecthub/auth/projecthub-verify', formData, {
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          withCredentials: true
        })
        .then((response) => {
          const { projecthubtoken, message, role } = response.data;
          if (message) {
            if (window.confirm(message)) {
              // Handle message response if needed
            }
            return;
          }
          if (projecthubtoken) {
            localStorage.setItem('projecthubtoken', projecthubtoken);
          }
          if (role) {
            setRole(role); // Set the role in state instead of localStorage
            handleNavigate(role); // Navigate based on role
          } else {
            navigate('/projecthub');
          }
        })
        .catch((error) => {
          console.error('Error during authentication:', error.response ? error.response.data : error.message);
        });
    }
    callRef.current = 1;
  }, [code, state, iss, navigate, handleNavigate]);

  return (
    <div>
      <div style={{ textAlign: 'center', padding: '20px' }}>
        <div style={{ marginTop: '40px' }}>
          {/* <span>{role}</span> Optionally display the role if needed */}
        </div>
      </div>
    </div>
  );
};

export default Auth;
