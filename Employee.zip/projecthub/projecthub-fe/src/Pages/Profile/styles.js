import styled from "styled-components";

// Styled Components
export const ProfileContainer = styled.div`
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 8px;
  max-width: 900px;
  margin: 0 auto;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
`;

export const Title = styled.h2`
  font-size: 24px;
  color: #333;
  margin-bottom: 20px;
`;

export const ProfileItem = styled.p`
  font-size: 12px;
  color: #555;
  margin: 10px 0;
`;

export const Strong = styled.strong`
  font-weight: bold;
  color: #333;
`;

export const Input = styled.input`
  font-size: 12px;
  padding: 8px;
  width: 100%;
  margin-top: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
`;

export const Select = styled.select`
  font-size: 12px;
  padding: 8px;
  width: 100%;
  margin-top: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
`;

export const LoadingText = styled.p`
  font-size: 18px;
  color: #888;
`;

export const ErrorText = styled.p`
  font-size: 18px;
  color: red;
`;

// Form Section Layout
export const FormSection = styled.div`
  display: flex;
  gap: 40px; /* Adjust spacing between left and right sections */
`;

export const LeftSection = styled.div`
  flex: 1;
  min-width: 300px;
`;

export const RightSection = styled.div`
  flex: 1;
  min-width: 300px;
`;
