import { useState, useEffect, useContext } from "react";
import { RoleContext } from "../../Context/RoleContext";
import axiosInstance from "../../utils/axiosInstance";
import {
  ProfileContainer,
  Title,
  ProfileItem,
  Strong,
  LoadingText,
  ErrorText,
  Input,
  Select,
  FormSection,
  LeftSection,
  RightSection,
} from "./styles";

const Profile = () => {
  const { role, setstart } = useContext(RoleContext);
  const [profileData, setProfileData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [updatedProfile, setUpdatedProfile] = useState(null);

  useEffect(() => {
    const fetchProfileData = async () => {
      if (role) {
        try {
          setLoading(true);
          setError(null);

          const response = await axiosInstance.post(`/api/projecthub/${role}/profile`);
          const {code,error} = response.data;

          if (code && error) {
            alert(error);
            return;
          }
    
          setProfileData(response.data.data);
          setUpdatedProfile(response.data.data);
        } catch (error) {
          setProfileData(null);
          setError(error.message || error.error);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchProfileData();
    setstart(true);

  }, [role, setstart]);

  const handleSelectChange = async (e) => {
    const newPositionAccepted = e.target.value === "true";

    setUpdatedProfile({
      ...updatedProfile,
      position_accepted: newPositionAccepted,
    });

    try {
      const response = await axiosInstance.post("/api/projecthub/user/accept-position", {
        userId: updatedProfile.user_id, 
        accept: newPositionAccepted,
      });
      const {code,error} = response.data;

      if (code && error) {
        alert(error);
        return;
      }


      if (response.status === 200) {
        console.log(response.data.message); 
      } else {
        setError("There was an error updating the position acceptance.");
      }
    } catch (err) {
      console.error("Error accepting position:", err);
      setError("There was an error updating the position acceptance.");
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdatedProfile({
      ...updatedProfile,
      [name]: value,
    });
  };

  if (loading) {
    return <LoadingText>Loading your profile...</LoadingText>;
  }

  if (error) {
    return <ErrorText>{error}</ErrorText>;
  }

  if (!profileData) {
    return <LoadingText>No profile data available. Make sure you're logged in as a valid user.</LoadingText>;
  }

  const renderLeftFields = (data) => {
    const leftFields = ['name', 'phone_number', 'role'];

    return leftFields.map((key) => {
      const fieldData = data[key] || "No data available";

      return (
        <ProfileItem key={key}>
          <Strong>{key.charAt(0).toUpperCase() + key.slice(1)}:</Strong>
          <Input
            type="text"
            name={key}
            value={fieldData || ""}
            onChange={handleInputChange}
          />
        </ProfileItem>
      );
    });
  };

  const renderRightFields = (data) => {
    if (role === "superAdmin") {
      return (
        <>
          <ProfileItem>
            <Strong>Super Admin ID:</Strong>
            <Input
              type="text"
              name="superAdmin_id"
              value={data.superAdmin_id || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Created At:</Strong>
            <Input
              type="text"
              name="createdAt"
              value={data.createdAt ? new Date(data.createdAt).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Updated At:</Strong>
            <Input
              type="text"
              name="updatedAt"
              value={data.updatedAt ? new Date(data.updatedAt).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
        </>
      );
    }
  
    if (role === "Admin") {
      return (
        <>
          <ProfileItem>
            <Strong>Admin ID:</Strong>
            <Input
              type="text"
              name="admin_id"
              value={data.admin_id || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Created At:</Strong>
            <Input
              type="text"
              name="createdAt"
              value={data.createdAt ? new Date(data.createdAt).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Updated At:</Strong>
            <Input
              type="text"
              name="updatedAt"
              value={data.updatedAt ? new Date(data.updatedAt).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
  
          {/* Organization fields */}
          <ProfileItem>
            <Strong>Organization Name:</Strong>
            <Input
              type="text"
              name="organization_name"
              value={data.organization?.organization_name || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Organization Address:</Strong>
            <Input
              type="text"
              name="organization_address"
              value={data.organization?.organization_address || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Organization Website:</Strong>
            <Input
              type="text"
              name="organization_website"
              value={data.organization?.organization_website || "No data available"}
              disabled
            />
          </ProfileItem>
        </>
      );
    }
  
    if (role === "User") {
      return (
        <>
          <ProfileItem>
            <Strong>User ID:</Strong>
            <Input
              type="text"
              name="user_id"
              value={data.user_id || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Created At:</Strong>
            <Input
              type="text"
              name="createdAt"
              value={data.createdAt ? new Date(data.createdAt).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Updated At:</Strong>
            <Input
              type="text"
              name="updatedAt"
              value={data.updatedAt ? new Date(data.updatedAt).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
  
          {/* Position fields for User */}
          <ProfileItem>
            <Strong>Position Name:</Strong>
            <Input
              type="text"
              name="position_name"
              value={data.position?.position_name || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Assigned By:</Strong>
            <Input
              type="text"
              name="assigned_by"
              value={data.position?.assigned_by || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Assigned Date:</Strong>
            <Input
              type="text"
              name="assigned_date"
              value={data.position?.assigned_date ? new Date(data.position.assigned_date).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Position Accepted:</Strong>
            <Select
              name="position_accepted"
              value={data.position_accepted}
              onChange={handleSelectChange}
            >
              <option value={true}>Accepted</option>
              <option value={false}>Not Accepted</option>
            </Select>
          </ProfileItem>
        </>
      );
    }
  
    if (role === "client") {
      return (
        <>
          <ProfileItem>
            <Strong>Name:</Strong>
            <Input
              type="text"
              name="name"
              value={data.name || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Phone Number:</Strong>
            <Input
              type="text"
              name="phone_number"
              value={data.phone_number || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Role:</Strong>
            <Input
              type="text"
              name="role"
              value={data.role || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Client ID:</Strong>
            <Input
              type="text"
              name="client_id"
              value={data.client_id || "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Created At:</Strong>
            <Input
              type="text"
              name="createdAt"
              value={data.createdAt ? new Date(data.createdAt).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
  
          <ProfileItem>
            <Strong>Updated At:</Strong>
            <Input
              type="text"
              name="updatedAt"
              value={data.updatedAt ? new Date(data.updatedAt).toLocaleString() : "No data available"}
              disabled
            />
          </ProfileItem>
        </>
      );
    }
  
    return (
      <>
        <ProfileItem>
          <Strong>User ID:</Strong>
          <Input
            type="text"
            name="user_id"
            value={data.user_id || "No data available"}
            disabled
          />
        </ProfileItem>
  
        <ProfileItem>
          <Strong>Created At:</Strong>
          <Input
            type="text"
            name="createdAt"
            value={data.createdAt ? new Date(data.createdAt).toLocaleString() : "No data available"}
            disabled
          />
        </ProfileItem>
  
        <ProfileItem>
          <Strong>Updated At:</Strong>
          <Input
            type="text"
            name="updatedAt"
            value={data.updatedAt ? new Date(data.updatedAt).toLocaleString() : "No data available"}
            disabled
          />
        </ProfileItem>
      </>
    );
  };
  
  return (
    <ProfileContainer>
      <Title>Profile</Title>
      <FormSection>
        <LeftSection>
          {renderLeftFields(updatedProfile)} {/* Render left side fields */}
        </LeftSection>
        <RightSection>
          {renderRightFields(updatedProfile)} {/* Render right side fields */}
        </RightSection>
      </FormSection>
    </ProfileContainer>
  );
};

export default Profile;
