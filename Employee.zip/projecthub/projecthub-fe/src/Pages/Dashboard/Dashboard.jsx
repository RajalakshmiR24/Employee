import React, { useEffect, useState, useContext, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  DashboardContainer,
  Header,
  Title,
  MainContent,
  Card,
  CardTitle,
} from "./styles";
import { RoleContext } from "../../Context/RoleContext";
import axiosInstance from "../../utils/axiosInstance";

const Dashboard = () => {
  const { role, setstart } = useContext(RoleContext);
  const [dashboardData, setDashboardData] = useState({
    totalUsers: 0,
    projectsInProgress: 0,
    tasksCompletedToday: 0,
  });
  const [errorMessage, setErrorMessage] = useState(""); 
  const fetchRef = useRef(false); 
  const navigate = useNavigate(); 

  useEffect(() => {
    if (role !== "Admin" && role !== "superAdmin") {
      setErrorMessage("No valid role"); 
      return;
    }
    setErrorMessage(""); 
    if (role !== "Admin" && role !== "superAdmin") {
      navigate("/projecthub");
    }
  }, [role, navigate]);

  const fetchDashboardCounts = useCallback(async () => {
    try {
      
      let endpoint = "";
      if (role === "Admin") {
        endpoint = "/api/projecthub/admin/dashboard";
      } else if (role === "superAdmin") {
        endpoint = "/api/projecthub/superadmin/dashboard";
      } else {
        setErrorMessage("No valid role");
        return;
      }

      const response = await axiosInstance.post(endpoint);
      const { code, error } = response.data;

      if (code && error) {
        alert(error);
        return;
      }

      if (response.data.success) {
        setDashboardData(response.data.data);
      } else {
        console.error("Failed to fetch dashboard counts:", response.data.message);
      }
    } catch (error) {
      alert(error.message || error.error)
    }
  }, [role]);

  useEffect(() => {
    if (!fetchRef.current) {
      fetchDashboardCounts();
      fetchRef.current = true;
    }
    setstart(true);
  }, [fetchDashboardCounts, setstart]);

  return (
    <DashboardContainer>
      <Header>
        <Title>{role === 'superAdmin' ? 'Super Admin' : 'Admin'} Dashboard</Title>
      </Header>

      {errorMessage && <p>{errorMessage}</p>} {/* Display the error message if there is one */}

      <MainContent>
        <Card>
          <CardTitle>Total Users</CardTitle>
          <h2>{dashboardData.totalUsers}</h2>
        </Card>

        <Card>
          <CardTitle>Projects In Progress</CardTitle>
          <h2>{dashboardData.projectsInProgress}</h2>
        </Card>

        <Card>
          <CardTitle>Tasks Completed Today</CardTitle>
          <h2>{dashboardData.tasksCompletedToday}</h2>
        </Card>
      </MainContent>
    </DashboardContainer>
  );
};

export default Dashboard;
