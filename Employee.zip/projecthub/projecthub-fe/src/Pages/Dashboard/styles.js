import styled from "styled-components";

export const DashboardContainer = styled.div`
  padding: 20px;
  top:0;
`;

export const Header = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 30px;
  background-color: #ffffff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  margin-bottom: 20px;
`;

export const Title = styled.h1`
  font-size: 1.8rem;
  font-weight: 600;
  color: #333;
`;

export const SearchInput = styled.input`
  padding: 6px 10px;
  font-size: 0.9rem;
  border: 1px solid #ccc;
  border-radius: 10px;
  outline: none;

  &:focus {
    border-color: #4f46e5;
    box-shadow: 0 0 3px #4f46e5;
  }
`;

export const MainContent = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
`;

export const Card = styled.div`
  flex: 1;
  min-width: 250px;
  max-width: 350px;
  background-color: #ffffff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

export const CardTitle = styled.h2`
  font-size: 1.2rem;
  font-weight: 600;
  color: #333;
  margin-bottom: 10px;
`;

export const UploadContainer = styled.div`
  border: 2px dashed #ccc;
  padding: 20px;
  text-align: center;
  border-radius: 8px;
  font-size: 0.9rem;

  &:hover {
    border-color: #4f46e5;
  }
`;

export const ClientAccessContainer = styled.div`
  margin-top: 10px;
`;
