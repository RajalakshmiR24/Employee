import React, { useState, useEffect, useContext } from "react";
import { useParams, useLocation } from "react-router-dom";
import {
  Container,
  Title,
  TaskDetail,
  NotAssigned,
  CommentSection,
  CommentInput,
  CommentList,
  CommentItem,
  Button,
} from "./styles";
import { RoleContext } from "../../Context/RoleContext";
import axiosInstance from "../../utils/axiosInstance";

const TaskDetails = () => {
  const { taskName } = useParams();
  const location = useLocation();
  const { data, id } = location.state || {}; // Destructure data and id
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState(data?.comments || []);

  const { role, setstart } = useContext(RoleContext);

  useEffect(() => {
    const fetchComments = async () => {
      try {
        const response = await axiosInstance.post(
          `/api/projecthub/${role}/allcomments`,
          {
            task_id: id, // Use id from state
          }
        );
        const {code,error} = response.data;

        if (code && error) {
          alert(error);
          return;
        }
  

        if (response.status === 200) {
          setComments(response.data.comments);
        }
      } catch (error) {
        alert(error.message || error.error)
      }
    };

    if (id) {
      fetchComments();
      setstart(true);

    }
  }, [id,setstart, role]);

  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };

  const handleAddComment = async () => {
    if (comment.trim()) {
      try {
        const response = await axiosInstance.post(
          `/api/projecthub/${role}/add-comment`,
          {
            task_id: id, // Use id from state
            message: comment,
          }
        );
        const {code,error} = response.data;

      if (code && error) {
        alert(error);
        return;
      }

        if (response.status === 201) {
          setComments([...comments, response.data.comment]);
          setComment("");
        }
      } catch (error) {
        alert(error.message || error.error)
      }
    }
  };

  if (!data) {
    return (
      <Container>
        <Title>Task Details</Title>
        <TaskDetail>Task Name: {decodeURIComponent(taskName)}</TaskDetail>
        <TaskDetail>No additional details available.</TaskDetail>
      </Container>
    );
  }

  const {
    start,
    due,
    description,
    status,
    style,
    assigned_to,
    team,
    project,
  } = data;

  return (
    <Container>
      <div style={{ display: "flex", gap: "20px" }}>
        {/* Comment Section */}
        <CommentSection>
          <Title>Comments</Title>
          <CommentInput
            type="text"
            value={comment}
            onChange={handleCommentChange}
            placeholder="Add a comment"
          />
          <Button onClick={handleAddComment}>Add Comment</Button>
          <CommentList>
            {comments.length > 0 ? (
              comments.map((comment) => (
                <CommentItem key={comment.comment_id}>
                  <div>
                    <strong>{comment.name}</strong> ({comment.role})
                  </div>
                  <div>{comment.message}</div>
                  {comment.user_id === data.added_by && <Button>Edit</Button>}
                </CommentItem>
              ))
            ) : (
              <NotAssigned>No comments yet</NotAssigned>
            )}
          </CommentList>
        </CommentSection>

        {/* Task Details Section */}
        <div style={{ flex: 1 }}>
          <Title>Task Details</Title>
          <TaskDetail>
            <strong>Task Name:</strong> {decodeURIComponent(taskName)}
          </TaskDetail>
          <TaskDetail>
            <strong>Start Date:</strong>{" "}
            {new Date(start).toLocaleString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </TaskDetail>
          <TaskDetail>
            <strong>End Date:</strong>{" "}
            {new Date(due).toLocaleString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </TaskDetail>
          <TaskDetail>
            <strong>Description:</strong> {description}
          </TaskDetail>
          {assigned_to && assigned_to.length > 0 ? (
            <TaskDetail>
              <strong>Assigned to:</strong> {assigned_to[0].name}
            </TaskDetail>
          ) : (
            <NotAssigned>
              <strong>Assigned to:</strong> Not assigned
            </NotAssigned>
          )}
          <TaskDetail>
            <strong>Status:</strong> {status}
          </TaskDetail>
          <TaskDetail>
            <strong>Priority:</strong> {style}
          </TaskDetail>
          {team && team.length > 0 ? (
            <TaskDetail>
              <strong>Team:</strong> {team.map((member) => member.teamName).join(", ")}
            </TaskDetail>
          ) : (
            <NotAssigned>
              <strong>Team:</strong> No team assigned
            </NotAssigned>
          )}
          {project && project.length > 0 ? (
            <TaskDetail>
              <strong>Project Name:</strong> {project[0].projectName}
            </TaskDetail>
          ) : (
            <NotAssigned>
              <strong>Project Name:</strong> No Project yet
            </NotAssigned>
          )}
        </div>
      </div>
    </Container>
  );
};

export default TaskDetails;
