import styled from 'styled-components';

export const Container = styled.div`
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
`;

export const Title = styled.h1`
  font-size: 24px;
  margin-bottom: 16px;
  color: #333;
`;

export const TaskDetail = styled.p`
  font-size: 18px;
  margin: 8px 0;
  color: #555;

  strong {
    color: #333;
  }
`;

export const NotAssigned = styled(TaskDetail)`
  font-style: italic;
  color: #999;
`;
export const CommentSection = styled.div`
  width: 300px;
  padding: 20px;
  border: 1px solid #ddd;
  background-color: #f9f9f9;
`;

export const CommentInput = styled.input`
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #ddd;
`;

export const Button = styled.button`
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  cursor: pointer;
  &:hover {
    background-color: #0056b3;
  }
`;

export const CommentList = styled.div`
  margin-top: 20px;
`;

export const CommentItem = styled.div`
  background-color: #f1f1f1;
  padding: 10px;
  margin-bottom: 10px;
  border-radius: 5px;
`;

export const EditButton = styled.button`
  padding: 5px 10px;
  background-color: #ffc107;
  color: white;
  border: none;
  cursor: pointer;
  margin-left: 10px;
  
  &:hover {
    background-color: #e0a800;
  }
`;
