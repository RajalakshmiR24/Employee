import React, { useEffect, useState, useCallback, useRef } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import { Container, Title, Table, TableHeader, TableRow, TableCell, Button } from './styles';

const Organizations = () => {
  const [organizations, setOrganizations] = useState([]); 
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState("");

  const fetchRef = useRef(false); // Added useRef to track fetch status

  const fetchOrganizations = useCallback(async () => {
    try {
      const response = await axiosInstance.post('/api/projecthub/superadmin/all-org');
      setOrganizations(response.data.data || []);
      setMessage(response.data.message || "");
    } catch (err) {
      setError(err.message || 'Failed to fetch organizations');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!fetchRef.current) {
      fetchOrganizations();
      fetchRef.current = true; // Mark that the data has been fetched
    }
  }, [fetchOrganizations]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  const formatWebsiteURL = (url) => {
    if (!url) return '';
    if (!/^https?:\/\//i.test(url)) {
      return `https://${url}`;
    }
    return url;
  };

  return (
    <Container>
      <Title>Organizations</Title>
      <Table>
        {message && <div>{message}</div>}

        <TableHeader>
          <tr>
            <TableCell>#</TableCell>
            <TableCell>Organization Name</TableCell>
            <TableCell>Admin Name</TableCell>
            <TableCell>Phone</TableCell>
            <TableCell>Address</TableCell>
            <TableCell>Website</TableCell>
          </tr>
        </TableHeader>
        <tbody>
          {organizations.map((org, index) => (
            <TableRow key={org.organization.organization_id}>
              <TableCell>{index + 1}</TableCell>
              <TableCell>{org.organization.organization_name}</TableCell>
              <TableCell>{org.name}</TableCell>
              <TableCell>{org.phone_number}</TableCell>
              <TableCell>{org.organization.organization_address}</TableCell>
              <TableCell>
                <Button as="a" href={formatWebsiteURL(org.organization.organization_website)} target="_blank" rel="noopener noreferrer">
                  Visit Website
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </tbody>
      </Table>
    </Container>
  );
};

export default Organizations;
