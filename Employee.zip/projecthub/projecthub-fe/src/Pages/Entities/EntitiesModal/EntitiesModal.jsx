import React, { useState, useEffect } from 'react';
import UserAdminClientForm from '../../../Components/Form/UserAdminClientForm';
import Datas from '../../../Components/Data/Datas';
import { ModalContainer, ButtonGroup, Button, ContentContainer, CloseButton } from './styles';

const EntitiesModal = ({ onClose, entityType, currentEntity }) => {
  const [activeTab, setActiveTab] = useState('form');
  const [isOpen, setIsOpen] = useState(true);
  const [formData, setFormData] = useState(null);

  const handleClose = () => {
    setIsOpen(false);
    onClose();
  };

  // Always call useEffect unconditionally
  useEffect(() => {
    if (currentEntity) {
      setFormData(currentEntity);
    } else {
      setFormData({});
    }
  }, [currentEntity]);

  const handleSubmit = (updatedData) => {
    console.log('Updated Data:', updatedData);
    onClose();
  };

  // Early return for closing modal
  if (!isOpen) return null;

  return (
    <ModalContainer>
      <ButtonGroup>
        <Button active={activeTab === 'form'} onClick={() => setActiveTab('form')}>
          Form
        </Button>
        <Button active={activeTab === 'excel'} onClick={() => setActiveTab('excel')}>
          Excel
        </Button>
      </ButtonGroup>

      <ContentContainer>
        {activeTab === 'form' && (
          <UserAdminClientForm
            entityType={entityType}
            formData={formData}
            onSubmit={handleSubmit}
          />
        )}
        {activeTab === 'excel' && (
          <Datas />
        )}
      </ContentContainer>

      <CloseButton onClick={handleClose}>X</CloseButton>
    </ModalContainer>
  );
};

export default EntitiesModal;
