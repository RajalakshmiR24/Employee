import styled from "styled-components";

export const AssignPositionsContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  border-radius: 8px;
`;

export const Title = styled.h2`
  color: #333;
  margin-bottom: 20px;
`;

export const Form = styled.form`
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 400px;
`;

export const Label = styled.label`
  color: #555;
  margin-bottom: 8px;
  font-size: 12px;
`;

export const Input = styled.input`
  padding: 10px;
  margin-bottom: 16px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 12px;
`;

export const Button = styled.button`
  padding: 12px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  &:hover {
    background-color: #0056b3;
  }
`;

export const Message = styled.div`
  margin-top: 20px;
  font-size: 12px;
  color: ${(props) => (props.error ? "red" : "green")};
  position: relative;
  padding-right: 30px; /* Space for the close button */
`;

export const CloseButton = styled.button`
  position: relative;
  top: 0;
  right: 0;
  background: none;
  border: none;
  font-size: 18px;
  color: ${(props) => (props.error ? "red" : "green")};
  cursor: pointer;
  padding: 0;
  margin: 0;
  &:hover {
    opacity: 0.7;
  }
`;
