import { useState, useContext } from "react";
import axiosInstance from "../../../utils/axiosInstance";
import { RoleContext } from "../../../Context/RoleContext";
import { AssignPositionsContainer, Form, Input, Button, CloseButton } from "./styles";
import { fetchPositions } from "../../../api/fetchEntities";

const AssignPositions = ({ onClose }) => {
  const { role, setstart } = useContext(RoleContext); 
  const [position, setPosition] = useState(""); 
  const [, setMessage] = useState(""); 
  const [, setIsError] = useState(false);

  const handleCreatePosition = async (e) => {
    e.preventDefault();
    setMessage(""); 
    setIsError(false);
  
    try {
      if (role === "Client" || role === "User") {
        setMessage("You do not have permission to create positions.");
        setIsError(true);
        return;
      }
  
      const apiUrl = `/api/projecthub/${role}/create-position`;
  
      const response = await axiosInstance.post(apiUrl, {
        position,
      });
  
      const { code, error, message } = response.data;
  
      if (code && error) {
        setMessage(error); 
        setIsError(true);
        return;
      }
  
      if (message) {
        setMessage(message); 
      }
  
      setPosition(""); 

      fetchPositions();
      setstart(true);  
    } catch (error) {
      setMessage(error.message || error.error);
      setIsError(true);
    }
  };
  

  const handleClose = () => {
    setMessage("");  
    onClose();  
  };

  return (
    <AssignPositionsContainer>
      <Form onSubmit={handleCreatePosition}>
        <Input
          id="position"
          value={position}
          onChange={(e) => setPosition(e.target.value)}
          placeholder="Enter position"
          required
        />
        <Button type="submit">Create Position</Button>
        <CloseButton onClick={handleClose}>close</CloseButton>
      </Form>

    </AssignPositionsContainer>
  );
};

export default AssignPositions;
