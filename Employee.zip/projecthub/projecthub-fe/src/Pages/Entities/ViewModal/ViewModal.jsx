import React from 'react';
import { Button, Card, CardHeader, CardBody, CardFooter, ModalContainer } from './styles';
import { format } from 'date-fns'; 

const ViewModal = ({ onClose, entity }) => {
  
  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    if (isNaN(date)) {
      return 'Invalid Date'; // fallback in case the date is invalid
    }
    return format(date, "dd MMM yyyy, HH:mm:ss"); // updated format
  };

  const renderEntityDetails = (entity) => {
    
    return Object.keys(entity).map((key) => {
      
      if (key === 'position' && entity.position && (entity.position.position_name || entity.position.assigned_by || entity.position.assigned_date)) {
        return (
          <div key={key}>
            <strong>Position:</strong>
            {entity.position.position_name && <p><strong>Position Name:</strong> {entity.position.position_name}</p>}
            {entity.position.assigned_by && <p><strong>Assigned By:</strong> {entity.position.assigned_by}</p>}
            {entity.position.assigned_date && <p><strong>Assigned Date:</strong> {formatDate(entity.position.assigned_date)}</p>}
          </div>
        );
      }
      
      if (key === 'organization' && entity.organization && (entity.organization.organization_name || entity.organization.organization_address || entity.organization.organization_website)) {
        return (
          <div key={key}>
            <strong>Organization:</strong>
            {entity.organization.organization_name && <p><strong>Organization Name:</strong> {entity.organization.organization_name}</p>}
            {entity.organization.organization_address && <p><strong>Organization Address:</strong> {entity.organization.organization_address}</p>}
            {entity.organization.organization_website && <p><strong>Organization Website:</strong> {entity.organization.organization_website}</p>}
          </div>
        );
      }
      
      if (key === 'CREATEDAT' || key === 'UPDATEDAT') {
        return (
          <div key={key}>
            <strong>{key.replace('_', ' ').toUpperCase()}:</strong> {formatDate(entity[key])}
          </div>
        );
      }
      
      if (entity[key] && typeof entity[key] !== 'object') {
        return (
          <div key={key}>
            <strong>{key.replace('_', ' ').toUpperCase()}:</strong> {entity[key]}
          </div>
        );
      }
      return null;
    });
  };

  return (
    <ModalContainer>
      <Card>
        <CardHeader>
          <h2>{entity.name}</h2>
        </CardHeader>
        <CardBody>
          {renderEntityDetails(entity)}
        </CardBody>
        <CardFooter>
          <Button onClick={onClose}>Close</Button>
        </CardFooter>
      </Card>
    </ModalContainer>
  );
};

export default ViewModal;
