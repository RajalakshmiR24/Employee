
import styled from 'styled-components';
export const ModalContainer = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;


export const Card = styled.div`
  background-color: #fff;
  padding: 20px;
  border-radius: 15px; 
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  width: 450px; 
  margin: 0 10px;
`;

export const CardHeader = styled.div`
  font-size: 1.6rem;
  font-weight: 600;
  margin-bottom: 15px;
  color: #333; 
  text-align: center; 
`;

export const CardBody = styled.div`
  padding: 15px 10px;
  font-size: 1.1rem;
  color: #555; 
`;

export const CardFooter = styled.div`
  padding: 10px 10px;
  text-align: center; 
`;

export const Button = styled.button`
  background-color: #007bff;
  color: white;
  padding: 12px 24px; 
  border: none;
  border-radius: 8px; 
  cursor: pointer;
  font-size: 1rem;
  transition: background-color 0.3s ease; 
  
  &:hover {
    background-color: #0056b3;
  }
`;
