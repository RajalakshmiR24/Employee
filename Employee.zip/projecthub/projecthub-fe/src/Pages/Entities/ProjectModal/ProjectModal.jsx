import React from 'react'

const ProjectModal = () => {
  return (
    <div>
      ProjectModal
      ProjectModal
    </div>
  )
}

export default ProjectModal
