import React, { useState, useEffect, useContext } from "react";
import axiosInstance from "../../../utils/axiosInstance";
import { RoleContext } from "../../../Context/RoleContext";
import {
  Button,
  ButtonGroup,
  Table,
  TableHeader,
  TableCell,
  TableContainer,
  Select,
  Option,
} from "./styles";
import {
  assignPosition,
  fetchEntities,
  fetchPositions,
} from "../../../api/fetchEntities";
import ViewModal from "../ViewModal/ViewModal";
import EntitiesModal from "../EntitiesModal/EntitiesModal";
import AssignPosition from "../AssignPositions/CreatePositions";

const MemberEntity = () => {
  const { role, setstart } = useContext(RoleContext);
  const [entities, setEntities] = useState({
    users: [],
    admins: [],
    clients: [],
  });
  const [entityType, setEntityType] = useState("users");
  const [selectedEntity, setSelectedEntity] = useState(null);
  const [modals, setModals] = useState({
    view: false,
    addMember: false,
    assignPosition: false,
  });
  const [selectedPositions, setSelectedPositions] = useState({});
  const [positions, setPositions] = useState([]);
  const [projects, setProjects] = useState([]);
  const [activeButton, setActiveButton] = useState("users");

  const fetchData = async (role, entityType) => {
    try {
      const [entityResponse, positionsResponse, projectsResponse] =
        await Promise.all([
          fetchEntities(role),
          fetchPositions(role),
          axiosInstance.post(`/api/projecthub/${role}/project-name`),
        ]);

      const { error } =
        entityResponse.data ||
        positionsResponse.data ||
        projectsResponse.data;

      if (error) {
        alert(error);
        return;
      }

      setEntities({
        users: Array.isArray(entityResponse.users) ? entityResponse.users : [],
        admins: Array.isArray(entityResponse.admins) ? entityResponse.admins : [],
        clients: Array.isArray(entityResponse.clients) ? entityResponse.clients : [],
      });
      setPositions(positionsResponse.positions || []);
      setProjects(Array.isArray(projectsResponse.data) ? projectsResponse.data : []);
    } catch (error) {
      alert(error.message || error.error)
    }
  };

  useEffect(() => {
    if (!role) return;

    setstart(true);
    fetchData(role, entityType);
  }, [role, entityType, setstart]);

  const handleModalToggle = (modalType, state) => {
    setModals((prev) => ({ ...prev, [modalType]: state }));
    if (!state) {
      setSelectedEntity(null);
      setSelectedPositions({});
    }
  };

  const handleEntityTypeChange = (type) => {
    setEntityType(type);
    setActiveButton(type);
  };

  const handleViewClick = (entity) => {
    const { hash, added_by_admin_id, _id, ...filteredEntity } = entity;
    setSelectedEntity(filteredEntity);
    handleModalToggle("view", true);
  };

  const handleAssignPositionClick = async () => {
    if (!selectedPositions[selectedEntity?.user_id] || !selectedEntity?.user_id) {
      alert("Please select a position and user.");
      return;
    }

    try {
      // Pass single user_id instead of an array
      const response = await assignPosition(
        role,
        selectedEntity.user_id,
        selectedPositions[selectedEntity.user_id]
      );
      const {  error } = response.data;

      if (error) {
        return error;
      }
      handleModalToggle("assignPosition", false);
    } catch (error) {
      alert(error.message || error.error)
    }
  };

  const handlePositionChange = async (e, entityId) => {
    const newPosition = e.target.value;

    setSelectedPositions((prevPositions) => ({
      ...prevPositions,
      [entityId]: newPosition,
    }));

    try {
      // Pass single user_id instead of an array
      const response = await assignPosition(role, entityId, newPosition);
      const { error } = response.data;

      if (error) {
        alert(error);
        return;
      }
    } catch (error) {
      alert(error.message || error.error)
    }
  };

  const handleProjectAccess = async (clientId, projectId) => {
    try {
      const response = await axiosInstance.post(
        `/api/projecthub/${role}/accessProject`,
        {
          client_id: clientId,
          project_id: projectId,
        }
      );
      const { error, message } = response.data;

      if (error && message) {
        alert(error || message);
        return;
      }


    } catch (error) {
      alert(error.message || error.error, ">?>?>>?>?>?>?>?>>?");
    }
  };

  const renderTable = (filteredEntities) => {
    if (!Array.isArray(filteredEntities)) {
      return (
        <tr>
          <td colSpan={5} style={{ textAlign: "center" }}>
            Invalid Data
          </td>
        </tr>
      );
    }

    return (
      <Table>
        <thead>
          <tr>
            <TableHeader>Index</TableHeader>
            <TableHeader>Name</TableHeader>
            <TableHeader>Phone Number</TableHeader>
            {entityType === "users" && <TableHeader>Assign Position</TableHeader>}
            {entityType === "clients" && <TableHeader>Project Access</TableHeader>}
            <TableHeader>Actions</TableHeader>
          </tr>
        </thead>
        <tbody>
          {filteredEntities.length === 0 ? (
            <tr>
              <td colSpan={5} style={{ textAlign: "center" }}>
                No Data Available
              </td>
            </tr>
          ) : (
            filteredEntities.map((entity, index) => (
              <tr key={entity.user_id}>
                <TableCell>{index + 1}</TableCell>
                <TableCell>{entity.name}</TableCell>
                <TableCell>{entity.phone_number}</TableCell>
                {entityType === "users" && (
                  <TableCell>
                    <Select
                      value={
                        selectedPositions[entity.user_id] ||
                        entity.assigned_position ||
                        ""
                      }
                      onChange={(e) => handlePositionChange(e, entity.user_id)}
                    >
                      <Option value="" disabled>
                        Select One
                      </Option>
                      {positions.length > 0 ? (
                        positions.map((pos) => (
                          <Option key={pos.position} value={pos.position}>
                            {pos.position}
                          </Option>
                        ))
                      ) : (
                        <Option value="" disabled>
                          No position available
                        </Option>
                      )}
                    </Select>
                  </TableCell>
                )}
                {entityType === "clients" && (
                  <TableCell>
                    <Select
                      value={entity.project_access || ""}
                      onChange={(e) =>
                        handleProjectAccess(entity.client_id, e.target.value)
                      }
                    >
                      <Option value="" disabled>
                        Select Project
                      </Option>
                      {projects.length === 0 ? (
                        <Option value="">No Projects Available</Option>
                      ) : (
                        projects.map((project) => (
                          <Option key={project.project_id} value={project.project_id}>
                            {project.projectName}
                          </Option>
                        ))
                      )}
                    </Select>
                  </TableCell>
                )}
                <TableCell>
                  <Button onClick={() => handleViewClick(entity)}>View</Button>
                </TableCell>
              </tr>
            ))
          )}
        </tbody>
      </Table>
    );
  };

  return (
    <div>
      <ButtonGroup>
        <Button
          onClick={() => handleEntityTypeChange("users")}
          style={{
            backgroundColor: activeButton === "users" ? "darkblue" : "",
            color: activeButton === "users" ? "white" : "",
          }}
        >
          Users
        </Button>
        {role === "superAdmin" && (
          <Button
            onClick={() => handleEntityTypeChange("admins")}
            style={{
              backgroundColor: activeButton === "admins" ? "darkblue" : "",
              color: activeButton === "admins" ? "white" : "",
            }}
          >
            Admins
          </Button>
        )}
        <Button
          onClick={() => handleEntityTypeChange("clients")}
          style={{
            backgroundColor: activeButton === "clients" ? "darkblue" : "",
            color: activeButton === "clients" ? "white" : "",
          }}
        >
          Clients
        </Button>
        <Button onClick={() => handleModalToggle("addMember", true)}>
          Add Member
        </Button>
        {(role === "superAdmin" || role === "Admin") && (
          <Button onClick={() => handleModalToggle("assignPosition", true)}>
            Create Position
          </Button>
        )}
      </ButtonGroup>

      {!Object.values(modals).some(Boolean) && (
        <TableContainer>
          {renderTable(entities[entityType] || [])}
        </TableContainer>
      )}

      {modals.view && selectedEntity && (
        <ViewModal
          onClose={() => handleModalToggle("view", false)}
          entity={selectedEntity}
        />
      )}

      {modals.addMember && (
        <EntitiesModal
          onClose={() => handleModalToggle("addMember", false)}
          entityType="Member"
        />
      )}

      {modals.assignPosition && (
        <AssignPosition
          onClose={() => handleModalToggle("assignPosition", false)}
          onAssign={handleAssignPositionClick}
        />
      )}
    </div>
  );
};

export default MemberEntity;
