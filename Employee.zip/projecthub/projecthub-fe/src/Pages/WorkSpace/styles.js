import styled from "styled-components";
export const WorkSpaceWrapper = styled.div`
  width: calc(100vw - 373px);
  height: calc(100vh - 80px);
  position: fixed;
  right: 0;
  top: 80px;
`;
