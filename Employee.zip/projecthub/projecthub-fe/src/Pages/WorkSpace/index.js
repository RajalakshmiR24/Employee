import React, { useContext, useState } from "react";
import AddStatus from "../../Components/AddStatus/index";
import { WorkSpaceWrapper } from "./styles";
import Board from "../../Components/board";
import { RoleContext } from "../../Context/RoleContext";

const WorkSpace = () => {
  const { role, setStart } = useContext(RoleContext);
  const [isWorkspaceStarted, setIsWorkspaceStarted] = useState(false);

  
  const handleStartWorkspace = () => {
    setStart(true); 
    setIsWorkspaceStarted(true); 
  };

  return (
    <WorkSpaceWrapper>
      <Board />
      {role === "Admin" && (
        <>
          <AddStatus />
          <div>
            <button onClick={handleStartWorkspace} disabled={isWorkspaceStarted}>
              {isWorkspaceStarted ? "Workspace Started" : "Start Workspace"}
            </button>
          </div>
        </>
      )}
    </WorkSpaceWrapper>
  );
};

export default WorkSpace;
