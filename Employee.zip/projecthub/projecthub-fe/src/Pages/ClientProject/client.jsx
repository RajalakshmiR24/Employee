import React, { useCallback, useContext, useEffect, useState } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import { RoleContext } from "../../Context/RoleContext";
import {
  ProjectCardWrapper,
  ProjectTitle,
  ProjectDescription,
  ProjectCardContainer,
  StatusLabel,
  DateLabel,
  TeamLabel
} from './styles';

const getRandomLightColor = () => {
  const colors = ['#FFB6C1', '#D1E7DD', '#FFE4B5', '#B3E5FC', '#E1BEE7', '#FFFACD'];
  const randomIndex = Math.floor(Math.random() * colors.length);
  return colors[randomIndex];
};

const ClientProject = () => {
  const { role, setstart } = useContext(RoleContext);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const fetchProjects = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await axiosInstance.post(`/api/projecthub/client/client-projects`);

      if (response.data && Array.isArray(response.data.projects)) {
        const { code, error } = response.data;

        if (code && error) {
          alert(error);
          return;
        }

        setProjects(response.data.projects);
      } else {
        const { code, error } = response.data;

        if (code && error) {
          setError(error);
          return;
        }
      }
    } catch (err) {
      setError('Error fetching projects.');
    } finally {
      setLoading(false);
    }
  },[]);
  useEffect(() => {
    fetchProjects();
    setstart(true);
 
  }, [role,setstart, fetchProjects]);

  if (loading) return <div>Loading projects...</div>;
  if (error) return <div>{error}</div>;

  return (
    <ProjectCardContainer>
      {projects.length > 0 ? (
        projects.map((project) => (
          <ProjectCardWrapper key={project._id}>
            <ProjectTitle>{project.projectName}</ProjectTitle>
            <ProjectDescription>
              {project.project_description || 'No description available.'}
            </ProjectDescription>
            <DateLabel>
              <strong>Start Date:</strong> {new Date(project.start_date).toLocaleDateString()}
            </DateLabel>
            <DateLabel>
              <strong>End Date:</strong> {new Date(project.end_date).toLocaleDateString()}
            </DateLabel>
            <TeamLabel>
              <strong>Team:</strong> {project.teams.map((team) => team.teamName).join(', ') || 'N/A'}
            </TeamLabel>
            <StatusLabel color={getRandomLightColor()}>{project.project_status}</StatusLabel>
          </ProjectCardWrapper>
        ))
      ) : (
        <div>No projects available.</div>
      )}
    </ProjectCardContainer>
  );
};

export default ClientProject;
