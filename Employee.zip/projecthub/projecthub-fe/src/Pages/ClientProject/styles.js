// src/components/ProjectCardStyled.js
import styled from 'styled-components';

export const ProjectCardWrapper = styled.div`
  width: 300px;
  padding: 20px;
  margin: 15px;
  background-color: #f4f6f9;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

export const ProjectTitle = styled.h3`
  color: #333;
  font-size: 18px;
  margin-bottom: 10px;
`;

export const ProjectDescription = styled.p`
  color: #555;
  font-size: 12px;
`;

export const ProjectCardContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
`;

// New StatusLabel component
export const StatusLabel = styled.span`
  display: inline-block;
  padding: 5px 10px;
  margin-top: 10px;
  font-size: 12px;
  font-weight: bold;
  color: white;
  border-radius: 12px;
  background-color: ${(props) => props.color};
`;

export const DateLabel = styled.p`
  margin: 5px 0;
  font-size: 13px;
  color: #666;
`;

export const TeamLabel = styled.p`
  margin: 5px 0;
  font-size: 13px;
  color: #444;
`;