import React from "react";
import WorkSpace from "../WorkSpace";

const MainPage = () => {
  return (
    <React.Fragment>

      <WorkSpace />
    </React.Fragment>
  );
};

export default MainPage;
