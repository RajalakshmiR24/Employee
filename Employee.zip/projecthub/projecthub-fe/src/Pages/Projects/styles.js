// src/components/ProjectBoard.styles.js
import styled from 'styled-components';

export const ProjectBoardContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: flex-start;
  flex-wrap: wrap;
  margin-top: 30px;
`;

export const ProjectColumn = styled.div`
  background-color: #f4f7fa;
  padding: 20px;
  margin: 0 10px;
  border-radius: 8px;
  width: 300px;
  min-height: 400px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`;

export const ProjectCard = styled.div`
  background-color: white;
  border: 1px solid #ddd;
  padding: 15px;
  margin-bottom: 15px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

export const ProjectTitle = styled.h3`
  color: #333;
  font-size: 18px;
  margin-bottom: 10px;
`;

export const ProjectDescription = styled.p`
  font-size: 12px;
  color: #555;
`;

export const ProjectStatus = styled.div`
  font-size: 12px;
  font-weight: bold;
  color: ${({ status }) => (status === 'Completed' ? 'green' : status === 'In Progress' ? 'blue' : 'gray')};
  margin-top: 10px;
`;

export const LoadingText = styled.div`
  color: #888;
  font-size: 18px;
  text-align: center;
  margin-top: 20px;
`;
