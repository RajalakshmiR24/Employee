import React from 'react'
import ProjectTable from '../../Components/Project/ProjectTable'

const Projects = () => {
  return (
    <div>
      <ProjectTable/>
    </div>
  )
}

export default Projects
