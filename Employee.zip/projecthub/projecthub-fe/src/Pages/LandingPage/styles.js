import styled from "styled-components";

export const NavbarWrapper = styled.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 32px;
  background-color: #fff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  font-family: 'Roboto', sans-serif;
`;

export const LogoWrapper = styled.div`
  display: flex;
  align-items: center;

  img {
    height: 32px;
    width: 32px;
    margin-right: 8px;
  }

  span {
    font-size: 24px;
    font-weight: 700;
    color: #000;
  }
`;

export const NavButtons = styled.div`
  display: flex;
  gap: 12px;

  button {
    padding: 8px 16px;
    border: none;
    border-radius: 50px;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    transition: 0.3s ease-in-out;

    &:hover {
      opacity: 0.8;
    }
  }

  .demo-button {
    background-color: transparent;
    color: #333;
    text-decoration: underline;
  }

  .login-button {
    background-color: #fff;
    color: #333;
    border: 1px solid #ccc;
  }

  .signup-button {
    background-color: #007bff;
    color: #fff;
  }
`;

export const HeroSection = styled.div`
  text-align: center;
  padding: 80px 20px;
  font-family: 'Roboto', sans-serif;

  h1 {
    font-size: 36px;
    font-weight: 700;
    color: #000;
    margin-bottom: 16px;
    line-height: 1.2;
  }

  p {
    font-size: 12px;
    color: #666;
    margin-bottom: 32px;
  }

  .cta-button {
    padding: 12px 24px;
    background-color: #007bff;
    color: #fff;
    font-size: 12px;
    font-weight: 600;
    border-radius: 50px;
    border: none;
    cursor: pointer;
    transition: 0.3s ease-in-out;

    &:hover {
      background-color: #0056b3;
    }
  }

  .subtext {
    margin-top: 8px;
    font-size: 12px;
    color: #666;
  }
`;
