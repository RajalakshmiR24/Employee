// import React, { useContext } from "react";
import React from "react";

// import { RoleContext } from "../../Context/RoleContext"; 
import { NavbarWrapper, LogoWrapper, NavButtons, HeroSection } from "./styles"; 
import { useNavigate } from "react-router-dom";

const Landing = () => {
  const navigate = useNavigate();
  // const { role, setstart } = useContext(RoleContext); 

  const goToAuthStart = () => {
      // const apiUrl = process.env.REACT_APP_PROJECTHUB_SERVER || window.location.origin ;
      // window.open(`${apiUrl}/api/projecthub/auth/start`, "_self");     
    // navigate(`/projecthub/${role}`);
    navigate(`/projecthub/Admin`);

  };

  return (
    <div>
      <NavbarWrapper>
        <LogoWrapper>
          <span>ProjectHub.</span>
        </LogoWrapper>
        <NavButtons>
          <button className="login-button" onClick={goToAuthStart}>
            Log In
          </button>
          <button className="signup-button" onClick={goToAuthStart}>
            Sign Up
          </button>
        </NavButtons>
      </NavbarWrapper>

      {/* Hero Section */}
      <HeroSection>
        <h1>
          Work management platform for <br /> result-driven teams
        </h1>
        <p>ProjectHub helps teams to plan the work, track the progress, and get sh*t done.</p>
        <button className="cta-button" onClick={goToAuthStart}>
          Try ProjectHub for Free
        </button>
      </HeroSection>
    </div>
  );
};

export default Landing;
