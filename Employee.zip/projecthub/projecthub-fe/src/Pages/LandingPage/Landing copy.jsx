import React from "react";
import {
  NavbarWrapper,
  LogoWrapper,
  NavButtons,
  HeroSection,
} from "./styles";

const Landing = () => {

  const goToAuthStart = () => {
    const apiUrl = process.env.REACT_APP_PROJECTHUB_SERVER || window.location.origin ;
    window.open(`${apiUrl}/api/projecthub/auth/start`, "_self"); 
    
  }
 
  return (
    <div>
      <NavbarWrapper>
        <LogoWrapper>
          <span>ProjectHub.</span>
        </LogoWrapper>
        <NavButtons>
          <button className="login-button" onClick={goToAuthStart}>Log In</button>
          <button className="signup-button" onClick={goToAuthStart}>Sign Up</button>
        </NavButtons>
      </NavbarWrapper>

      {/* Hero Section */}
      <HeroSection>
        <h1>
          Work management platform for <br /> result-driven teams
        </h1>
        <p>ProjectHub helps teams to plan the work, track the progress, and get sh*t done.</p>
        <button className="cta-button" onClick={goToAuthStart}>Try ProjectHub for Free</button>
      </HeroSection>
    </div>
  );
};

export default Landing;
