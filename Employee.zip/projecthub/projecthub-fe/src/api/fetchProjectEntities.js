

import axiosInstance from '../utils/axiosInstance';  

export const fetchEntities = async (role) => {
  try {
    
    const url = `/api/projecthub/${role}/projects`;
    const response = await axiosInstance.post(url);  
    const {code,error} = response.data;

    if (code && error) {
      alert(error);
      return;
    }
    if (response.status === 200) {
      return response.data;  
    } else {
      console.error('Failed to fetch entities:', response.statusText);
      return null;
    }
  } catch (error) {
    alert(error.message || error.error)
  }
};
