import axiosInstance from '../utils/axiosInstance';


const getRoleApiBase = (role) => {
  if (role === 'Admin') {
    return '/api/projecthub/admin';
  } else if (role === 'superAdmin') {
    return '/api/projecthub/superAdmin';
  }
  throw new Error("Invalid role provided");
};

export const fetchEntities = async (role) => {
  try {
    const apiBase = getRoleApiBase(role);
    const response = await axiosInstance.post(`${apiBase}/all-entities`);

    
    if (response && response.data) {
      const {  error } = response.data;

      if ( error) {
        return error;
      }

      const { users, admins, clients } = response.data;
      if (role === 'Admin') {
        return { users, clients };
      } else if (role === 'superAdmin') {
        return { users, admins, clients };
      }
    } else {
      console.error('Invalid response structure:', response.data);
      alert("Invalid response from API");
      return { users: [], admins: [], clients: [] };
    }
  } catch (error) {
    alert(error.message || error.error || "An error occurred while fetching entities.");
    return { users: [], admins: [], clients: [] };
  }
};


export const fetchPositions = async (role) => {
  try {
    const apiBase = getRoleApiBase(role);
    const response = await axiosInstance.post(`${apiBase}/all-positions`);

    
    if (response && response.data) {
      const {  error } = response.data;

      if ( error) {
        return error;
      }
      return response.data;
    } else {
      console.error('Invalid response structure:', response.data);
      alert("Invalid response from API");
      return { positions: [] };
    }
  } catch (error) {
    alert(error.message || error.error || "An error occurred while fetching positions.");
    return { positions: [] };
  }
};



export const assignPosition = async (role, userIds, position) => {
  try {
    if (!userIds) {
      throw new Error("userId must be provided");
    }

    const apiBase = getRoleApiBase(role);
    const response = await axiosInstance.post(`${apiBase}/assign-position`, {
      position,
      userIds,  
    });

    
    if (response && response.data) {
      const {  error } = response.data;

      if ( error) {
        return error;
      }
      return response.data;
    } else {
      console.error('Invalid response structure:', response.data);
      alert("Invalid response from API");
    }
  } catch (error) {
    alert(error.message || error.error || "An error occurred while assigning position.");
  }
};
